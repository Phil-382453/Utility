﻿<#
.SYNOPSIS
    (Input tab) This will reset the domain credentials password stored in the control panel 'Credentials Manager'.
.ROLE
    Access
.FUNCTIONALITY  
    creds,credentials,reset,NoServersNeeded,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$CredManagerMaster = New-UIObject

$CredManagerMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$CredManagerMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$CredManagerMaster.CredsDomain  = "My.bank.corp"
$CredManagerMaster.CredsType    = "Server" # Server or User
$CredManagerMaster.CredsAccount = "ra382453" # the one I use
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$CredManagerMaster.Scripts = @{}
$CredManagerMaster.Scripts.CheckCreds = {
    
    if($CredManagerMaster.CredsType -like "Server"){$CredManagerMaster.CredsType = "Server"}

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CredManagerMaster.WorkingDirectory)\$($CredManagerMaster.ScriptName).xml" -InputObject @{
        CredsDomain  = $CredManagerMaster.CredsDomain.ToLower()
        CredsType    = $CredManagerMaster.CredsType
        CredsAccount = $CredManagerMaster.CredsAccount.ToLower()
    } #Export-Clixml

    $UIMaster.ConnectionType = "Local_NoSvrs"

    # prep variables to pass to $script
    $Domain  = $CredManagerMaster.CredsDomain.ToLower()
    $Type    = $CredManagerMaster.CredsType
    $Account = $CredManagerMaster.CredsAccount.ToLower()
    $ArgumentList = $Domain,$Type,$Account #send these to the param of the $script

    $script = Convert-ScriptOutputToText { # query
        Param([string]$Domain,[string]$Type,[string]$Account)

        $cred      = $null
        $creduserx = $null

        # retrieve the cred object
        $cred = Get-MCredential -Domain $Domain -Type $Type | where {$_.GetNetworkCredential().Username -eq "$Account"}

        ""
        if($cred){
            "Verification - The account was found:" ############ This will show the User Name from Credentials Manager
            $cred
            #"Password = $credpassx" #### This will show the password on that object in Credentials Manager
        }
        else {"The account was NOT FOUND: $($Account). Verification failed."}
        ""
    } #$script

    $SubScriptMessage = "$(($CredManagerMaster.ScriptName) -replace ".ps1") - Verify Creds" # create console subscript message
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage

}.GetNewClosure() # .ResetCreds
$CredManagerMaster.Scripts.RemoveCreds = {
    
    if($CredManagerMaster.CredsType -like "Server"){$CredManagerMaster.CredsType = "Server"}

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CredManagerMaster.WorkingDirectory)\$($CredManagerMaster.ScriptName).xml" -InputObject @{
        CredsDomain  = $CredManagerMaster.CredsDomain.ToLower()
        CredsType    = $CredManagerMaster.CredsType
        CredsAccount = $CredManagerMaster.CredsAccount.ToLower()
    } #Export-Clixml

    $UIMaster.ConnectionType = "Local_NoSvrs"

    # prep variables to pass to $script
    $Domain  = $CredManagerMaster.CredsDomain.ToLower()
    $Type    = $CredManagerMaster.CredsType
    $Account = $CredManagerMaster.CredsAccount.ToLower()
    $ArgumentList = $Domain,$Type,$Account #send these to the param of the $script

    $script = Convert-ScriptOutputToText { # query
        Param([string]$Domain,[string]$Type,[string]$Account)
        ######################################
        # Remove the object from Credentials Manager
        Remove-MCredential $Domain -Type $Type  # This will prompt you for the username and password to REMOVE.
        ""
        "The account $($Account), has been removed"
        ""
    } #$script

    $SubScriptMessage = "$(($CredManagerMaster.ScriptName) -replace ".ps1") - Remove creds" # create console subscript message
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage

}.GetNewClosure() # .ResetCreds
$CredManagerMaster.Scripts.AddCreds = {
    
    if($CredManagerMaster.CredsType -like "Server"){$CredManagerMaster.CredsType = "Server"}
    
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CredManagerMaster.WorkingDirectory)\$($CredManagerMaster.ScriptName).xml" -InputObject @{
        CredsDomain  = $CredManagerMaster.CredsDomain.ToLower()
        CredsType    = $CredManagerMaster.CredsType
        CredsAccount = $CredManagerMaster.CredsAccount.ToLower()
    } #Export-Clixml

   $UIMaster.ConnectionType = "Local_NoSvrs"

    # prep variables to pass to $script
    $Domain  = $CredManagerMaster.CredsDomain.ToLower()
    $Type    = $CredManagerMaster.CredsType
    $Account = $CredManagerMaster.CredsAccount.ToLower()
    $ArgumentList = $Domain,$Type,$Account #send these to the param of the $script

    $script = Convert-ScriptOutputToText { # query
        Param([string]$Domain,[string]$Type,[string]$Account)

        #############################################
        # Create the Credentials Object in Credentials Manager
        Set-MCredential -Domain $Domain -Type $Type  # This will prompt for the username and password (because Set-MCredential expects a creds object) 
        ""
        "Credentials have been added."
        
        $cred      = $null
        $creduserx = $null

        $cred = Get-MCredential -Domain $Domain -Type $Type | where {$_.GetNetworkCredential().Username -eq "$Account"}
        $creduserx = $cred.GetNetworkCredential().UserName
        #$credpassx = $cred.GetNetworkCredential().Password
        ""
        if($creduserx){
            "Verification - The account was found: $($creduserx)" ############ This will show the User Name from Credentials Manager
            #"Password = $credpassx" #### This will show the password on that object in Credentials Manager
        }
        else {"The account was NOT FOUND: $($Account). Verification failed."}
        ""
    } #$script

    $SubScriptMessage = "$(($CredManagerMaster.ScriptName) -replace ".ps1") - Add Creds" # create console subscript message
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage

}.GetNewClosure() # .ResetCreds
#endregion
#------------------------------------------------------
#region - UI Data Loading...
try {
    $SettingsClixml = Import-Clixml "$($CredManagerMaster.WorkingDirectory)\$($CredManagerMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'CredsDomain','CredsType','CredsAccount'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $CredManagerMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $CredManagerMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UIStackPanel -Margin 20,0,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,0,0,0 -FontWeight Bold
                New-UITextBlock "Purpose:" -FontWeight Bold -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "The 'Credentials Manager' (in your control panel) is used to securely store your credentials." -Margin 20,6,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "The Scripts_UI uses the 'Credentials Manager' when running scripts." -Margin 20,6,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "This script allows you to Reset or update these credentials." -Margin 20,6,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "This does not use or affect Active Directory."-Margin 20,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock ("*" * 100) -Margin 0,10,0,4 -FontWeight Bold
            } #StackPanel

            New-UIStackPanel -Margin 20,0,0,0 {
                New-UITextBlock "Action:" -FontWeight Bold -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "Enter the domain (My.bank.corp,My.bank.qa,My.bank.dev)" -Margin 20,10,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBox -BindTextTo CredsDomain -align TopLeft                     -Margin 20, 0,0,0 -AlsoSet @{FontSize=14} -Foreground Black -Width 150 -Height 25
                
                New-UITextBlock "Enter the account Type (Server,User,Workstation)" -Margin 20,20,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBox -BindTextTo CredsType -align TopLeft -Margin 20, 0,0,0 -AlsoSet @{FontSize=14} -Foreground Black -Width 110 -Height 25
                New-UITextBlock "`'Server`' is the type used by the Scripts_UI." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}

                New-UITextBlock "Enter the account name (a123456)"         -Margin 20,20,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBox -BindTextTo CredsAccount -align TopLeft -Margin 20, 0,0,0 -AlsoSet @{FontSize=14} -Foreground Black -Width 110 -Height 25

                New-UIStackPanel -Orientation Horizontal          -Margin 20,20,0,0 {
                    New-UIButton "Verify Creds" -Padding 10,6,10,6 -Margin  0, 0,0,0 -AddClick $CredManagerMaster.Scripts.CheckCreds -Foreground Red
                    New-UITextBlock "if Creds not found, you will be prompted to enter them." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel

                New-UIStackPanel -Orientation Horizontal          -Margin 20,20,0,0 {
                    New-UIButton "Remove Creds" -Padding 10,6,10,6 -Margin  0, 0,0,0 -AddClick $CredManagerMaster.Scripts.RemoveCreds -Foreground Red
                    New-UITextBlock "" -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UIStackPanel -Orientation Horizontal          -Margin 20,20,0,0 {
                    New-UIButton "Add Creds" -Padding 10,6,10,6 -Margin  0, 0,0,0 -AddClick $CredManagerMaster.Scripts.AddCreds
                    New-UITextBlock "" -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,4 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 

        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 