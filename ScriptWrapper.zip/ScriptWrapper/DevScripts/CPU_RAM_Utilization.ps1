<#
.SYNOPSIS
    Collects summary CPU utilization info on remote server(s)
.ROLE
    Utility
.FUNCTIONALITY
    process,pid,cpu,ram,memory,kernelmodetime,threadcount,cmdline
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    Text
#>
# Everything past this point is treated as a scriptblock .. and sent to your list of servers .. for remote execution.


$Start = Get-Date -format "DD-MM-YYYY HH:MM"
$CPU1 = Get-WmiObject win32_processor | Measure-Object -property LoadPercentage -Average
$CPU=$CPU1.Average
#----
$ComputerMemory = Get-WmiObject -Class Win32_OperatingSystem
$Memory = ((($ComputerMemory.TotalVisibleMemorySize - $ComputerMemory.FreePhysicalMemory)*100)/$ComputerMemory.TotalVisibleMemorySize)
$RoundMemory = [Math]::Round($Memory,2)
# Output ---------------
$obj = [ordered]@{}
$obj.HostName = $env:COMPUTERNAME

$obj.HostName = $env:USERNAME
$obj.'CPU Usage'    = "$CPU"
$obj.'Memory Usate' = "$($RoundMemory)%"
$obj.'Date Time'    = "$Start"
[pscustomobject]$obj #echo to console

<#
Get-Service | Select-Object -First 10 | Select-Object Name,ServiceName,Status,StartUtpe | Format-Table -AutoSize

# Create a custom PowerShell object (very useful when combining properties/columns from different objects into a single PSCustomObject)
#----------------------------------
$obj
$obj.HostName = $env:COMPUTERNAME
$obj.UserName = $env:USERNAME
$obj.Status   = "Good"
$obj.abc      = 'same'
[pscustomobject]$obj #echo to console

#----------------------------------
$WMI_DiskProps = @('DeviceID','Name','Model','Index','SerialNumber')
WMI_DiskDrives = Get-WmiObject -Class Win32_DiskDrive | select $WMI_DiskProps | Sort Index
#>


# Appendix of useful stuff
<#
#-------------------------------------------
$serverlist | foreach{$_.Trim() | where{$_}} # remove whitespace and blank lines
$serverlist |       %{$_.Trim() |     ?{$_}} # remove whitespace and blank lines

#-------------------------------------------
The following 3 data structures .. accomplish the same output

1: Add a custom property to your output
    $HostName1 = @{Name=HostNamex; Expression={$env:computername}}
    [array]$DriveObjectx = Get-WmiObject -Class Win32_DiskDrive | select $HostName1,DeviceID,Name,Model,Index,SerialNumber
    $DriveObjectx #...........echo to output

2: Select Properties as a collection ...
    $HostName1 = @{Name='HostNamex'; Expression={$env:computername}}
    $WMI_DiskProps = @($HostName1,'DeviceID','Name','Model','Index','SerialNumber')
    $WMI_DiskDrives = Get-WmiObject -Class Win32_DiskDrive | select $WMI_DiskProps | Sort Index
    $WMI_DiskDrives #......echo to output
#-------------------------------------------
3: PScustomObject - Create a custom object then add it to an array 
    Get-WmiObject -Class Win32_DiskDrive | %{
        [PSCustomObject]@{
            HostName1    = $env:computername
            DeviceID     = $_.DeviceID
            Name         = $_.Name    
            Model        = $_.Model   
            Index        = $_.Index
            SerialNumber = $_.SerialNumber
        }
    } #foreach

#-------------------------------------------
Lookup Table:
    $serviceNameToWmiHash = @{}
    Get-WmiObject -Class Win32_Service | %{ $serviceNameToWmiHash[$_.Name] = $_ } 
    $serviceNameToWmiHash        | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Keys   | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Values | Out-String | Out-Host #echo to console

#-------------------------------------------
Error Info:
    $error[0] 
    $error[0].Exception
    $error[0].InnerException
    $error[0].CategoryInfo
    $error[0].ErrorDetails
    $error[0].FullyQualifiedErrorId   #very useful .. the short version
    $error[0].InvocationInfo
    $error[0].TargetObject
    $error[0].PSMessageDetails
#>
