﻿<#
.SYNOPSIS
    (Input tab) Test IP Port (like telnet) from a server(s), to a target server(s), over the listed port(s).
.ROLE
    Network
.FUNCTIONALITY  
    Telnet,ports,connectivity,backup,netbackup,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$TelnetMaster = New-UIObject
$TelnetMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$TelnetMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$TelnetMaster.TargetServers = $null
$TelnetMaster.TargetPorts   = $null
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$TelnetMaster.Scripts = @{}
$TelnetMaster.Scripts.Query = {
    # verify the textbox input
    if(!($TelnetMaster.TargetServers)){Show-UIMessageBox "Please enter Target Servers list"; return}
    if(!($TelnetMaster.TargetPorts))  {Show-UIMessageBox "Please enter Target Ports list"  ; return}

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($TelnetMaster.WorkingDirectory)\$($TelnetMaster.ScriptName).xml" -InputObject @{
        TargetServers = $TelnetMaster.TargetServers
        TargetPorts   = $TelnetMaster.TargetPorts
    } #Export-Clixml

    # Create scriptblock to send to serverlist (source server)
    $script = {
        Param([string[]]$TargetServers,[string[]]$TargetPorts)
            ##################
            function Test-Port {
                Param($server,$port,$hostname)

                # This works regardless which form we get $host - hostname or ip address
                try { 
                    $ip = [System.Net.Dns]::GetHostAddresses($server) | select-object IPAddressToString -expandproperty IPAddressToString
                    if ($ip.GetType().Name -eq "Object[]") { $ip = $ip[0] } #...If multiple ip's...let's take first one
                } # end try 
                catch { 
                    $results2 = [ordered]@{}
                    $results2.SourceServer = $hostname
                    $results2.TargetServer = $server
                    $results2.Port         = $Port
                    $results2.Connection   = "Failed"
                    [pscustomobject]$results2 #echo
                } # end catch
            
                $t = New-Object Net.Sockets.TcpClient

                # If we can't connect, we use Try\Catch to remove exception info from console
                try { $t.Connect($ip,$port) } catch {}
            
                if($t.Connected) { 
                    $t.Close() # close the connection

                    $results2 = [ordered]@{}
                    $results2.SourceServer = $hostname
                    $results2.TargetServer = $server
                    $results2.Port         = $Port
                    $results2.Connection   = "Good"
                    [pscustomobject]$results2 #echo
                } else { 
                    $results2 = [ordered]@{}
                    $results2.SourceServer = $hostname
                    $results2.TargetServer = $server
                    $results2.Port         = $Port
                    $results2.Connection   = "Failed"
                    [pscustomobject]$results2 #echo
                } #else
            } #funct
            function TCP-Connection {
                Param($servers,$port,$hostname)

                Foreach ($server in $servers){ 
                    Test-Port $server $port $hostname #echo
                } # end for
            } #funct
            ##################
            $Servers = $TargetServers -split "`r`n" | ForEach Trim | Where { $_ } # cleanup and create an array
            $Ports   = $TargetPorts   -split "`r`n" | ForEach Trim | Where { $_ } # cleanup and create an array
            $Hostname = $env:computername # get the "Source server name"
            
            foreach($Port in $Ports){ TCP-Connection $servers $port $Hostname | select SourceServer,TargetServer,Port,Connection }  #final echo
            ##################
    } #script
    $ArgumentList = $TelnetMaster.TargetServers,$TelnetMaster.TargetPorts
    $SubScriptMessage = "** Connectivity test" # create console subscript message
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .RunQuery
#endregion
#------------------------------------------------------
#region - UI Data Loading

# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($TelnetMaster.WorkingDirectory)\$($TelnetMaster.ScriptName).xml" -ErrorAction Stop
    $list1 = 'TargetServers','TargetPorts'
    foreach ($setting in $list1) {
        if ($SettingsClixml.Contains($setting)) { $TelnetMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------    
#region - UI Layout / Show UI 
New-UIGrid -RowDefinition *, auto -DataContext $TelnetMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 14,10,0,0 -FontWeight Bold
            New-UITextBlock "Purpose:" -FontWeight Bold -AlsoSet @{FontSize=14} -Margin 14,6,4,0
            New-UITextBlock "To verify connectivity for one or more servers (listed on main tab)..." -Margin 14,6,4,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "To one or more Target servers (listed here)..." -Margin 18,6,4,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "Over one or more ports (listed here)..."        -Margin 22,6,4,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "Using the following commands:"                  -Margin 26,6,4,6 -AlsoSet @{FontSize=14}
            New-UITextBlock '$t = New-Object Net.Sockets.TcpClient'     -Margin 30,6,4,0 -Foreground Black -AlsoSet @{FontSize=14}
            New-UITextBlock '$t.Connect($ip,$port)'                     -Margin 30,6,4,0 -Foreground Black -AlsoSet @{FontSize=14}
            New-UITextBlock 'if ($t.Connected) { good } else { failed }' -Margin 30,6,4,0 -Foreground Black -AlsoSet @{FontSize=14}

            New-UIStackPanel -Margin 14,40,0,0 {
                New-UITextBlock "Target Servers (one per line)" -FontWeight Bold -Margin 4,6,4,0
                New-UITextBox  -VerticalScrollBarVisibility Auto -AcceptsReturn $true `
                    -BindTextTo TargetServers -Align TopLeft -Width 300 -Height 140 -Margin 4,10,4,0
                New-UITextBlock "" -Margin 20,6,4,0
            } #StackPanel

            New-UIStackPanel -Margin 14,0,0,0 {
                New-UITextBlock "Ports (one per line)" -FontWeight Bold -Margin 4,6,4,0
                New-UITextBox -VerticalScrollBarVisibility Auto -AcceptsReturn $true `
                    -BindTextTo TargetPorts -Align TopLeft -Width 300 -Height 140 -Margin 4,10,4,0
                New-UITextBlock "" -Margin 20,6,4,0
            } #StackPanel

            New-UIStackPanel -Orientation Horizontal -Margin 10,0,0,0 {
                New-UIButton "Run" -Margin 10,10,0,10 -Padding 14,4,14,6 -Foreground Red -Align TopLeft -AlsoSet @{FontSize=14}`
                    -AddClick $TelnetMaster.Scripts.Query
                New-UITextBlock "" -Margin 20,6,4,0
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 