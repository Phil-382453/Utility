﻿<#
.SYNOPSIS  
    Get Network Adapter - Status, Name, Teaming, Slot, MacAddress, LinkSpeed, VlanID, PhysicalMediaType, MtuSize
.ROLE
    Network
.FUNCTIONALITY
    nic,network,adapter,slot,speed,mac,MtuSize,VlanID,interface,hardware,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

#Get-NetAdapter | select *
$Hostname = $env:COMPUTERNAME

################
# Get-NetAdapter
$GetNetAdapter = Get-NetAdapter | select `
        State,
        Status,
        Name,
        MediaConnectState,
        InterfaceDescription,
        LinkSpeed,
        MacAddress,
        VlanID,
        InstanceID,
        FullDuplex,
        DriverFileName,
        DriverVersion,
        DriverProvider,
        MtuSize,
        InterfaceIndex,
        InterfaceName

############################
# Get-NetAdapterHardwareInfo
$GetNetAdapterHardwareInfo = Get-NetAdapterHardwareInfo | Select `
    Name,Description,CurrentSpeedAndMode,Bus,Device,Function,Slot,InstanceID

#######################
# get-netlbfoteammember
$NicTeaminInfo = get-netlbfoteammember | select am,InstanceID,InterfaceAlias

#########################################
#########################################
# Combine the results into a single table

foreach ($item1 in $GetNetAdapter){ 
    $obj = [ordered]@{} # A hash table, dictionary? or associative array?
    $obj.Hostname = $Hostname
    $obj.State    = $item1.State #
    if($item1.State -eq 0){ $obj.State = 'Unknown'  } #if
    if($item1.State -eq 1){ $obj.State = 'Present' } #if
    if($item1.State -eq 2){ $obj.State = 'Started'  } #if
    if($item1.State -eq 3){ $obj.State = 'Disabled' } #if
    if($item1.AdminStatus -eq 1){ $obj.TeamStatus = 'Up'  } #if
    if($item1.AdminStatus -eq 2){ $obj.TeamStatus = 'Down' } #if
    if($item1.MediaConnectState -eq 0){ $obj.ConnectionState = 'Unknown' }
    if($item1.MediaConnectState -eq 1){ $obj.ConnectionState = 'Connected' }
    if($item1.MediaConnectState -eq 2){ $obj.ConnectionState = 'Disconnected' }
    
    foreach($item3 in $GetNetAdapterHardwareInfo){
        if($item3.InstanceID -eq $item1.InstanceID){
            $obj.Slot = $item3.Slot
        } #if
    } #foreach

    $obj.Status     = $item1.Status
    $obj.Name       = $item1.Name 
    $obj.TeamStatus = '' # default - if no $NicTeaminInfo
    
    if($NicTeaminInfo){ # nic teaming found
        foreach ($item2 in $NicTeaminInfo){
            if($item2.InstanceID -eq $item1.InstanceID){ 
                if($item2.am -eq 0){ $obj.TeamStatus = 'Active'  } #if
                if($item2.am -eq 1){ $obj.TeamStatus = 'Standby' } #if
            } #if
        } #foreach
    } #if
    else { $obj.TeamStatus = "Not found" } # team member active/standby

    $obj.Description = $item1.InterfaceDescription #
    $obj.LinkSpeed   = $item1.LinkSpeed #
    $obj.FullDuplex  = $item1.FullDuplex
    $obj.MACAddress  = $item1.MACAddress #
    $obj.InstanceID  = $item1.InstanceID #
    $obj.MtuSize           = $item1.MtuSize #
    $obj.VlanID            = $item1.VlanID #
    $obj.DriverProvider    = $item1.DriverProvider #
    $obj.DriverFileName    = $item1.DriverFileName #
    $obj.DriverVersion     = $item1.DriverVersion #
    $obj.InterfaceIndex    = $item1.InterfaceIndex #
    $obj.InterfaceName     = $item1.InterfaceName #
    [array]$Results += [pscustomobject]$obj 
} #foreach
$Results | sort ConnectionState,Slot # echo to output
# script complete