﻿<#
.SYNOPSIS  
    (Input tab) EventLogs - choose advanced logs - Administrative, Operational, Analytic, Debug, and Trace
.ROLE
    Logs
.FUNCTIONALITY
    evt,logs,eventlogs,system,application,security,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$EvtLogsMaster = New-UIObject # generic object to allow properties and updating anywhere in the script
$EvtLogsMaster.ScriptName          = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$EvtLogsMaster.WorkingDirectory    = $UIMaster.WorkingDirectory
$EvtLogsMaster.CheckboxEmptyLogs   = $true    # create a property. Set starting value
$EvtLogsMaster.RadioDays2          = $true    # create a property. Set starting value
$EvtLogsMaster.RadioRange2         = $false   # create a property. Set starting value
$EvtLogsMaster.TextboxDays2        = "1"      # create a property. Set starting value
$EvtLogsMaster.Textboxafter2       = (Get-Date).AddDays(-($EvtLogsMaster.TextboxDays2))
$EvtLogsMaster.Textboxbefore2      = Get-Date # create a property. Set starting value
$EvtLogsMaster.TextboxOther        = "*wmi*"  # create a property. Set starting value
$EvtLogsMaster.TextboxResults      = ""       # create a property. Set starting value
$EvtLogsMaster.TextboxOLogName     = ""       # create a property. Set starting value
$EvtLogsMaster.PSsessionx          = ""       # create a property. Set starting value
$EvtLogsMaster.TextboxTrace        = "Microsoft-Windows-WMI-Activity/Trace" # default
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$EvtLogsMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$EvtLogsMaster.Scripts = @{}
$EvtLogsMaster.Scripts.GetLogNames     = {
    $Computers = $UIMaster.ServerText -split "`r`n" |
        ForEach-Object Trim | Where-Object { $_ -ne "" } | select -first 1
    $loglist       = $EvtLogsMaster.TextboxOther
    $CboxEmptyLogs = $EvtLogsMaster.CheckboxEmptyLogs
    $Args = $loglist,$CboxEmptyLogs
    
    #  Create a script to send to remote server
    $script = { Param($loglist,$CboxEmptyLogs)
        if($CboxEmptyLogs){ #only logs with records
            Get-WinEvent -ListLog $loglist -force | where{$_.RecordCount} | select RecordCount,LogName
        } #if
        else{ #all logs
            Get-WinEvent -ListLog $loglist -force | select RecordCount,LogName
        } #else
    } #Script

    # Execute the remote cmd
    foreach($Computer in $Computers){
        $EvtLogsMaster.TextboxResults += Invoke-Command -ComputerName $Computer -scriptblock $script -Args $Args `
            -Credential (Get-WFServerCredential -Server $Computer) | select * -ExcludeProperty RunspaceId | out-string
    } #foreach
    $EvtLogsMaster.TextboxResults += "`r`n`r`nComplete`r`n--------"

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        TextboxOLogName     = $EvtLogsMaster.TextboxOLogName   #LogsSearch
        CheckboxEmptyLogs   = $EvtLogsMaster.CheckboxEmptyLogs #FindLogs
        TextboxResults      = $EvtLogsMaster.TextboxResults    #LogsFound
        ###
        RadioDays2          = $EvtLogsMaster.RadioDays2     #Radio
        TextboxDays2        = $EvtLogsMaster.TextboxDays2   #Integer
        RadioRange2         = $EvtLogsMaster.RadioRange2    #Radio
        Textboxafter2       = $EvtLogsMaster.Textboxafter2  #Date
        Textboxbefore2      = $EvtLogsMaster.Textboxbefore2 #Date
        ###
        TextboxTrace        = $EvtLogsMaster.TextboxTrace   # Trace log
    } #Export-Clixml
}.GetNewClosure() # .GetLogNames
$EvtLogsMaster.Scripts.clsTextbox      = {
    $EvtLogsMaster.TextboxResults = ""
}.GetNewClosure() # .clsTextbox
$EvtLogsMaster.Scripts.CollectLogs     = {
################################################
####   HKLM\Software\Microsoft\WBEM\CIMOM   ####
################################################
    
    # Build the $ArgumentList
    $Logs       = "$($EvtLogsMaster.TextboxOLogName)" #
    $RadioDays  = [bool]$EvtLogsMaster.RadioDays2     # True/False
    
    if($RadioDays){
        $Days = [string]$EvtLogsMaster.TextboxDays2    # get the textbox contents
        if($Days -eq '*'){
            $After  = $null
            $Before = $null
        } #if
        else {
            [DateTime]$After  = (Get-Date).AddDays(-$Days) 
            [DateTime]$Before = Get-Date
        } #else
    } #if
    else {
        $before = [DateTime]$EvtLogsMaster.Textboxbefore2 # get the textbox contents
        $after  = [DateTime]$EvtLogsMaster.Textboxafter2  # get radiobutton (true/false)    
    } #else
    
    $ArgumentList = $Logs,$Before,$After # send these to the param of the $script
    $SubScriptMessage = "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Get" # create console subscript message

    $script = {
        Param([string]$Logs,$Before,$After)

        if($After){
            foreach($LogName in $Logs){
                $filter = {($_.TimeCreated -ge $After) -and ($_.TimeCreated -le $Before)}
                [array]$evtlogs += Get-WinEvent -Oldest -FilterHashTable @{LogName=$LogName} | Where $filter | 
                select * | sort TimeCreated -Descending #TimeCreated,LevelDisplayName,Message,ProcessId,ThreadId,Id,Level,LogName | sort TimeCreated -Descending

                $evtlogs #echo
            } #foreach
        } #if
        else{
            foreach($LogName in $Logs){
                [array]$evtlogs += Get-WinEvent -Oldest -FilterHashTable @{LogName=$LogName} | 
                select * | sort TimeCreated -Descending #TimeCreated,LevelDisplayName,Message,ProcessId,ThreadId,Id,Level,LogName | sort TimeCreated -Descending

                $evtlogs #echo
            } #foreach
        } #else
    } #script

    # The names must be identical to allow the Import-Clixml to work correctly ()
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        CheckboxApplication = $EvtLogsMaster.CheckboxApplication
        CheckboxSystem      = $EvtLogsMaster.CheckboxSystem
        CheckboxSecurity    = $EvtLogsMaster.CheckboxSecurity
        RadioDays1          = $EvtLogsMaster.RadioDays1     #Radio
        TextboxDays1        = $EvtLogsMaster.TextboxDays1   #Integer
        RadioRange1         = $EvtLogsMaster.RadioRange1    #Radio
        Textboxafter1       = $EvtLogsMaster.Textboxafter1  #Date
        Textboxbefore1      = $EvtLogsMaster.Textboxbefore1 #Date
        ###
        CheckboxEmptyLogs   = $EvtLogsMaster.CheckboxEmptyLogs   #FindLogs
        TextboxOLogName     = $EvtLogsMaster.TextboxOLogName #LogsSearch
        TextboxResults      = $EvtLogsMaster.TextboxResults #LogsFound
        ###
        RadioDays2          = $EvtLogsMaster.RadioDays2     #Radio
        TextboxDays2        = $EvtLogsMaster.TextboxDays2   #Integer
        RadioRange2         = $EvtLogsMaster.RadioRange2    #Radio
        Textboxafter2       = $EvtLogsMaster.Textboxafter2  #Date
        Textboxbefore2      = $EvtLogsMaster.Textboxbefore2 #Date
        ###
        TextboxTrace        = $EvtLogsMaster.TextboxTrace   # Trace log
    } #Export-Clixml

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage

}.GetNewClosure() # .CollectLogs
$EvtLogsMaster.Scripts.CreateSession   = {
    # Get 1st ComputerName in $UIMaster.ServerText (from Servers Textbox)
    $EvtLogsMaster.Server = $UIMaster.ServerText -split "`r`n" | Select -First 1 |
        ForEach-Object Trim | Where-Object { $_ -ne "" }
    $EvtLogsMaster.PSsessionx = New-PSSession -ComputerName ($EvtLogsMaster.Server) -Name ($EvtLogsMaster.Server) `
        -Credential (Get-WFServerCredential -Server ($EvtLogsMaster.Server))

    #####################
    Write-Host ""
    Write-Host -F Magenta "==============================="
    Write-Host -F Magenta "==============================="
    Write-Host ""
    Write-Host "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Start Session" -F Cyan
    Write-Host ''
    #$EvtLogsMaster.PSsessionx | Out-Host
    get-pssession | out-host
    Write-Host ''

}.GetNewClosure() # .CreateSession
$EvtLogsMaster.Scripts.Start           = {
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        TextboxOLogName     = $EvtLogsMaster.TextboxOLogName   #LogsSearch
        CheckboxEmptyLogs   = $EvtLogsMaster.CheckboxEmptyLogs #FindLogs
        TextboxResults      = $EvtLogsMaster.TextboxResults    #LogsFound
        ###
        RadioDays2          = $EvtLogsMaster.RadioDays2     #Radio
        TextboxDays2        = $EvtLogsMaster.TextboxDays2   #Integer
        RadioRange2         = $EvtLogsMaster.RadioRange2    #Radio
        Textboxafter2       = $EvtLogsMaster.Textboxafter2  #Date
        Textboxbefore2      = $EvtLogsMaster.Textboxbefore2 #Date
        ###
        TextboxTrace        = $EvtLogsMaster.TextboxTrace   # Trace log
    } #Export-Clixml

    #####################
    Write-Host ""
    Write-Host -F Magenta "==============================="
    Write-Host -F Magenta "==============================="
    Write-Host ""
    $SubScriptMessage = "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Start Trace log" # create console subscript message
    Write-Host $SubScriptMessage -F Cyan
    Write-Host ""
    
    $Args = ($EvtLogsMaster.TextboxTrace) -split "`r`n" |
        ForEach-Object Trim | Where-Object { $_ -ne "" }

    $script = {
        Param($EvtLogsTrace)
        #write-host "echo y | Wevtutil.exe sl $($EvtLogsTrace) /e:true" # | out-string -width 200
        write-host "Wevtutil.exe sl $($EvtLogsTrace) /e:true /Q"
        Wevtutil.exe sl $EvtLogsTrace /e:true /Q | out-host
    } #script

    # select 1st server in the list on main tab
    $Computers = $UIMaster.ServerText -split "`r`n" |
        ForEach-Object Trim | Where-Object { $_ -ne "" } | select -first 1

    # Execute the remote cmd
    foreach($Computer in $Computers){
        $results = Invoke-Command -ComputerName $Computer -scriptblock $script -Args $Args `
            -Credential (Get-WFServerCredential -Server $Computer) | select * -ExcludeProperty RunspaceId,PSComputerName
        Write-Host $results
    } #foreach

}.GetNewClosure() # .Start
$EvtLogsMaster.Scripts.Stop            = {
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        TextboxOLogName     = $EvtLogsMaster.TextboxOLogName   #LogsSearch
        CheckboxEmptyLogs   = $EvtLogsMaster.CheckboxEmptyLogs #FindLogs
        TextboxResults      = $EvtLogsMaster.TextboxResults    #LogsFound
        ###
        RadioDays2          = $EvtLogsMaster.RadioDays2     #Radio
        TextboxDays2        = $EvtLogsMaster.TextboxDays2   #Integer
        RadioRange2         = $EvtLogsMaster.RadioRange2    #Radio
        Textboxafter2       = $EvtLogsMaster.Textboxafter2  #Date
        Textboxbefore2      = $EvtLogsMaster.Textboxbefore2 #Date
        ###
        TextboxTrace        = $EvtLogsMaster.TextboxTrace   # Trace log
    } #Export-Clixml

    #####################
    Write-Host ""
    Write-Host -F Magenta "==============================="
    Write-Host -F Magenta "==============================="
    Write-Host ""
    $SubScriptMessage = "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Stop Trace log" # create console subscript message
    Write-Host $SubScriptMessage -F Cyan
    Write-Host ""
    
    $Args = ($EvtLogsMaster.TextboxTrace) -split "`r`n" | ForEach-Object Trim | Where-Object { $_ -ne "" }
    
    $script = {
        Param($EvtLogsTrace)
        write-host "Wevtutil.exe sl $EvtLogsTrace /e:false"  # | out-string -width 200
        Wevtutil.exe sl $EvtLogsTrace /e:false | out-host
    } #script
    
    # select 1st server in the list on main tab
    $Computers = $UIMaster.ServerText -split "`r`n" |
        ForEach-Object Trim | Where-Object { $_ -ne "" } | select -first 1

    # Execute the remote cmd
    foreach($Computer in $Computers){
        $results = Invoke-Command -ComputerName $Computer -scriptblock $script -Args $Args `
            -Credential (Get-WFServerCredential -Server $Computer) | select * -ExcludeProperty RunspaceId,PSComputerName
        $results | Out-String
    } #foreach

}.GetNewClosure() # .Stop
$EvtLogsMaster.Scripts.Cleanup         = {
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        TextboxOLogName     = $EvtLogsMaster.TextboxOLogName   #LogsSearch
        CheckboxEmptyLogs   = $EvtLogsMaster.CheckboxEmptyLogs #FindLogs
        TextboxResults      = $EvtLogsMaster.TextboxResults    #LogsFound
        ###
        RadioDays2          = $EvtLogsMaster.RadioDays2     #Radio
        TextboxDays2        = $EvtLogsMaster.TextboxDays2   #Integer
        RadioRange2         = $EvtLogsMaster.RadioRange2    #Radio
        Textboxafter2       = $EvtLogsMaster.Textboxafter2  #Date
        Textboxbefore2      = $EvtLogsMaster.Textboxbefore2 #Date
        ###
        TextboxTrace        = $EvtLogsMaster.TextboxTrace   # Trace log
    } #Export-Clixml

    #####################
    Write-Host ""
    Write-Host -F Magenta "==============================="
    Write-Host -F Magenta "==============================="
    Write-Host ""
    $SubScriptMessage = "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Delete Trace log" # create console subscript message
    Write-Host $SubScriptMessage -F Cyan
    Write-Host ""
    
    $Args = ($EvtLogsMaster.TextboxTrace) -split "`r`n" | ForEach-Object Trim | Where-Object { $_ -ne "" }
    
    $script = {
        Param($EvtLogsTrace)
        write-host "Wevtutil.exe cl $EvtLogsTrace"
        Wevtutil.exe cl $EvtLogsTrace | out-host
    } #script

    # select 1st server in the list on main tab
    $Computers = $UIMaster.ServerText -split "`r`n" |
        ForEach-Object Trim | Where-Object { $_ -ne "" } | select -first 1

    # Execute the remote cmd
    foreach($Computer in $Computers){
        Invoke-Command -ComputerName $Computer -scriptblock $script -Args $Args `
            -Credential (Get-WFServerCredential -Server $Computer) | 
            select * -ExcludeProperty RunspaceId,PSComputerName  | Out-String
    } #foreach

}.GetNewClosure() # .Cleanup
$EvtLogsMaster.Scripts.CloseSession    = {
    #####################
    Write-Host ""
    Write-Host -F Magenta "==============================="
    Write-Host -F Magenta "==============================="
    Write-Host ""
    Write-Host "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Close Session" -F Cyan
    Write-Host ''
    Get-Pssession | Remove-PSSession
    if(Get-Pssession){
        Write-Host "Error removing the PSSession" -f Red
        Get-Pssession | Out-Host
    } #if
    else{Write-Host "PSSession removed"}
}.GetNewClosure() # .CloseSession
#endregion
#------------------------------------------------------
#region - UI Data Loading
try { # Read in the script settings file and populate the GUI from last saved data.
    $SettingsClixml = Import-Clixml "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -ErrorAction Stop
    $list1 = 'TextboxOLogName','CheckboxEmptyLogs','TextboxResults','RadioDays2','TextboxDays2','RadioRange2','Textboxafter2','Textboxbefore2','TextboxTrace'
    foreach ($setting in $list1) {
        if ($SettingsClixml.Contains($setting)) { $EvtLogsMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
} #try
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $EvtLogsMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        # Heading start
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UIStackPanel -Orientation Vertical {
                New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
                New-UITextBlock "Collect Eventlogs (Advanced types), on the server(s) from the Main tab." `
                    -Margin 20,6,0,0 -FontWeight Bold -AlsoSet @{FontSize=14}
                New-UITextBlock "Advanced Log Types = Administrative, Operational, Analytic, Debug, and Trace." -Margin 20,4,0,0 -AlsoSet @{FontSize=14}
                New-UITextBlock ("*" * 126) -Margin 20,4,0,0 -FontWeight Bold
                New-UITextBlock "Enter logname, * to show all. " -Margin 20,4,0,0
                # (Get-WinEvent -ListLog
                New-UIStackPanel -Orientation Horizontal {
                    New-UITextBlock 'Get-WinEvent -ListLog ' -Margin 20,6,0,0
                    New-UITextBox -Width 120 -Height 20 -Margin 0,0,0,0 -BindTextTo TextboxOther -Foreground Green
                    New-UITextBlock ' -force | select RecordCount,LogName' -Margin 0,6,0,0
                    New-UIButton "Search" -Padding 6,4,6,6 -Margin 10,0,0,0 -align TopLeft -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $EvtLogsMaster.Scripts.GetLogNames
                    New-UIButton "cls textbox" -Padding 6,4,6,6 -Margin 10,0,0,0 -align TopLeft -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $EvtLogsMaster.Scripts.clsTextbox
                } #StackPanel
                New-UICheckbox "Only logs that contain Records"  -Margin 20,10,0,0 -BindIsCheckedTo CheckboxEmptyLogs
                
                # Textbox big
                New-UIStackPanel -Orientation Horizontal -Margin 20,4,0,0 {
                    New-UITextBox -Width 690 -Height 200 -Margin 0,10,0,0 `
                        -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible `
                        -BindTextTo TextboxResults -AlsoSet @{FontFamily='Consolas'}
                } #StackPanel
                # Textbox small
                New-UIStackPanel -Orientation Horizontal {
                    New-UITextBlock "Choose LogName from the above textbox" -Margin 20,10,0,0
                    New-UITextBox -Width 448 -Height 20 -Margin 20,8,0,4 -BindTextTo TextboxOLogName -Foreground Green
                } #StackPanel

                New-UIStackPanel -Orientation Horizontal {
                    # Days
                    New-UIStackPanel -Orientation Vertical {
                        New-UIRadioButton "Days:"  -Margin 20,12,0,0 -BindIsCheckedTo RadioDays2  -Foreground Black
                        New-UIRadioButton "Range:" -Margin 20,10,0,0 -BindIsCheckedTo RadioRange2 -Foreground Black
                    } #StackPanel
                    # Range
                    New-UIStackPanel -Orientation Vertical {
                        New-UIStackPanel -Orientation Horizontal {
                            New-UITextBlock "Enter the number of days:" -Margin 14,10,0,0 -Foreground Black
                            New-UITextBox -Width 30 -Height 20 -Align CenterLeft -Margin 12,10,0,0 -BindTextTo TextboxDays2 -Foreground Green
                            New-UITextBlock "* for all" -Margin 14,10,0,0 -Foreground Black
                        } #StackPanel
                        New-UIStackPanel -Orientation Horizontal {   
                            New-UITextBlock "Enter the starting Date:" -Margin 14,10,0,0 -Foreground Black
                            New-UITextBox -Width 150 -Height 20 -Align CenterLeft -Margin 28,10,0,0 -BindTextTo Textboxafter2 -Foreground Green
                        } #StackPanel
                        # Ending Date
                        New-UIStackPanel -Orientation Horizontal {
                            New-UITextBlock "Enter the ending Date:" -Margin 14,4,0,0 -Foreground Black
                            New-UITextBox -Width 150 -Height 20 -Align CenterLeft -Margin 30,4,0,0 -BindTextTo Textboxbefore2 -Foreground Green
                        } #StackPanel
                    } #StackPanel
                } #StackPanel

                # Run Button
                New-UIStackPanel -Orientation Horizontal -Margin 20,10,0,0 {
                    New-UIButton "Run" -Padding 8,2,8,4 -align CenterLeft -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $EvtLogsMaster.Scripts.CollectLogs
                    New-UITextBlock "Collect (Advanced) EventLogs" -Margin 20,4,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UITextBlock ("*" * 126) -Margin 20,4,0,0 -FontWeight Bold
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBlock "Enable/Disable Trace Logs:" -Margin 20,6,0,0 -FontWeight Bold -AlsoSet @{FontSize=14}
                    New-UIStackPanel -Orientation Vertical {
                        New-UITextBlock "1. Choose a logname (/Trace) from the large textbox above (uncheck the box - Trace logs will usually be empty)." -Margin 20,10,0,0 -Foreground Black
                        New-UIStackPanel -Orientation Horizontal {
                            New-UITextBlock "2. " -Margin 20,10,0,0 -Foreground Black
                            New-UITextBlock "Enter the logname into the textbox:" -Margin 0,10,0,0
                            New-UITextBox -Width 400 -Height 20 -Margin 20,10,0,0 -BindTextTo TextboxTrace -Foreground Green
                        } #StackPanel
                        New-UITextBlock "3. Start the Trace (Cmd = echo y | Wevtutil.exe sl `$wmiLog /e:true)" -Margin 20,10,0,0 -Foreground Black
                        New-UIStackPanel -Orientation Horizontal -Margin 30,10,0,0 {
                            New-UIButton "Start" -Padding 8,2,8,4 -align CenterLeft -Foreground Red -AlsoSet @{FontSize=14}`
                            -AddClick $EvtLogsMaster.Scripts.Start # enables logging
                        } #StackPanel
                        New-UITextBlock "4. Take actions to generate logs." -Margin 20,10,0,0 -Foreground Black
                        New-UITextBlock "5. Stop the Trace (echo y | Wevtutil.exe sl `$wmiLog /e:false)" -Margin 20,10,0,0 -Foreground Black
                        New-UIStackPanel -Orientation Horizontal -Margin 30,10,0,0 {
                            New-UIButton "Stop" -Padding 8,2,8,4 -align CenterLeft -Foreground Red -AlsoSet @{FontSize=14}`
                            -AddClick $EvtLogsMaster.Scripts.Stop # disables logging
                        } #StackPanel
                        New-UITextBlock "6. In the top section, use the Collect (Advanced) Eventlogs to retrieve your log." -Margin 20,10,0,0 -Foreground Black
                        New-UITextBlock "   Don't forget to enter your logname in the textbox (Choose LogName from the above textbox)." -Margin 20,0,0,0 -Foreground Black
                        New-UITextBlock "7. Delete the Trace logs." -Margin 20,10,0,0 -Foreground Black
                        New-UIStackPanel -Orientation Horizontal -Margin 30,10,0,0 {
                            New-UIButton "Cleanup" -Padding 8,2,8,4 -align CenterLeft -Foreground Red -AlsoSet @{FontSize=14}`
                            -AddClick $EvtLogsMaster.Scripts.Cleanup
                        } #StackPanel
                        New-UITextBlock ("*" * 200) -Margin 14,10,0,0 -FontWeight Bold} #StackPanel
                } #StackPanel
            } #StackPanel
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete