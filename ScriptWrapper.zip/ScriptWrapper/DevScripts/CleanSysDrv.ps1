﻿<#
.SYNOPSIS  
    (Input tab) - Clear space on the System drive...delete temp files, crash dumps, etc
.ROLE
    Utility
.FUNCTIONALITY
    Cleanup,space,drive,volume,delete,dir,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$CleanSysDrv = New-UIObject
$CleanSysDrv.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$CleanSysDrv.WorkingDirectory = $UIMaster.WorkingDirectory
$CleanSysDrv.SelectedCacheFolder = $UIMaster.SelectedCacheFolder
$CleanSysDrv.VerifyDir = "C:\temp\*.txt`r`nC:\Windows"
$CleanSysDrv.DeleteFileNamesx = ""
$CleanSysDrv.TextOutput = $true
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$CleanSysDrv.Scripts = @{}
$CleanSysDrv.Scripts.VerifyDisk = {
    # Validate input
    if ($UIMaster.RemoteScriptRun -and (-not($UIMaster.ServerText))){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -InputObject @{
        VerifyDir        = $CleanSysDrv.VerifyDir
        DeleteFileNamesx = $CleanSysDrv.DeleteFileNamesx
        TextOutput       = $CleanSysDrv.TextOutput
    } #Export-Clixml

    $SubScriptMessage = "verify drive space"
    if($CleanSysDrv.TextOutput){
        $Script = Convert-ScriptOutputToText{
            $objs = @()
            $logicalDisk = $null
            $logicaldiskx = Get-WmiObject Win32_logicaldisk -Filter "MediaType = 12" | Where-Object {$_.DeviceID -eq "C:"} | `
                Select DeviceID, 
                @{Name="Size(GB)";Expression={("{0:N2}" -f($_.size/1gb))}}, 
                @{Name="Free Space(GB)";Expression={("{0:N2}" -f($_.freespace/1gb))}}, 
                @{Name="Free (%)";Expression={"{0,6:P0}" -f(($_.freespace/1gb) / ($_.size/1gb))}}
            $obj = New-Object -TypeName PSObject
            $obj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value "$env:computername"
            $obj | Add-Member -MemberType NoteProperty -Name "DeviceID" -Value $logicaldiskx."DeviceID"
            $obj | Add-Member -MemberType NoteProperty -Name "Size(GB)" -Value $logicaldiskx."Size(GB)"
            $obj | Add-Member -MemberType NoteProperty -Name "Free Space(GB)" -Value $logicaldiskx."Free Space(GB)"
            $obj | Add-Member -MemberType NoteProperty -Name "Free (%)" -Value $logicaldiskx."Free (%)"
            $objs += $obj

            $logicalDisk = $null
            return, $objs
        } #script
    } #if
    else{
        $Script = {
            $objs = @()
            $logicalDisk = $null
            $logicaldiskx = Get-WmiObject Win32_logicaldisk -Filter "MediaType = 12" | Where-Object {$_.DeviceID -eq "C:"} | `
                Select DeviceID, 
                @{Name="Size(GB)";Expression={("{0:N2}" -f($_.size/1gb))}}, 
                @{Name="Free Space(GB)";Expression={("{0:N2}" -f($_.freespace/1gb))}}, 
                @{Name="Free (%)";Expression={"{0,6:P0}" -f(($_.freespace/1gb) / ($_.size/1gb))}}
            $obj = New-Object -TypeName PSObject
            $obj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value "$env:computername"
            $obj | Add-Member -MemberType NoteProperty -Name "DeviceID" -Value $logicaldiskx."DeviceID"
            $obj | Add-Member -MemberType NoteProperty -Name "Size(GB)" -Value $logicaldiskx."Size(GB)"
            $obj | Add-Member -MemberType NoteProperty -Name "Free Space(GB)" -Value $logicaldiskx."Free Space(GB)"
            $obj | Add-Member -MemberType NoteProperty -Name "Free (%)" -Value $logicaldiskx."Free (%)"
            $objs += $obj

            $logicalDisk = $null
            return, $objs
        } #script
    } #else
    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $Script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CleanSysDrv.Scripts.DelTemp    = {

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -InputObject @{
        VerifyDir        = $CleanSysDrv.VerifyDir
        DeleteFileNamesx = $CleanSysDrv.DeleteFileNamesx
        TextOutput       = $CleanSysDrv.TextOutput
    } #Export-Clixml

    $SubScriptMessage = "$(($CleanSysDrv.ScriptName) -replace ".ps1") - Del Temp files" # create console subscript message

    # Create the scriptblock
    $Script = Convert-ScriptOutputToText {
        ###################################################################################################
        ### Start section #################################################################################
        ###       Change this section to modify the command that is run on each remote server           ###
        ###################################################################################################
        ###################################################################################################
        [CmdletBinding()]
        Param()
        Begin {} #begin
        Process {
            #------------------------------------------------------------------
            #region - Functions
            function Cleanup-TempNdmpfiles{
                $NoMatch = $true # track if no files deleted
                $tempfolders = @( # create list of folders to clean-up
                    "C:\temp"
                    "C:\Windows\temp"
                    "C:\Logs\PowerShell"
                    "C:\Windows\LiveKernelReports"
                    "C:\Windows\System32\Config\SystemProfile\AppData\Local\CrashDumps"
                    #"C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp"
                )

                $limitx = (get-date).Addays(0) # set the number of days to keep (based on LastWriteTime)

                # Verify folders exist
                $tempfolders2 = @()
                foreach ($folder in $tempfolders){
                    If (Test-Path $folder) { $tempfolders2 += $folder} # folder exists
                    Else { "# Not found - $($folder)"} # $folder does not exist
                } # end foreach

                foreach ($folder in $tempfolders2){        
                    
                    ### Get all the matching files ###
                    $files = $null
                    $files = Get-ChildItem -Path "$($folder)" -Recurse -Force | Where-Object {!$_.PSIsContainer -and ($_.LastWriteTime -le $limit1x)}

                    ### Delete the matching files ###
                    foreach ($file in $files) {
                        if ($file.FullName.length -gt 0) {
                            Try { 
                                Remove-Item $file.FullName -Force –ErrorAction Stop -ErrorVariable customError # delete the file
                                "Delete successful - $($file.FullName)"
                                $NoMatch = $false
                            }
                            Catch { #$cstmError = $customError -split "`n"
                                " ##### Error = $($customError)"
                                $customError.clear()
                                $NoMatch = $false
                            }
                        } # end if
                    } # end foreach

                } # end foreach

                foreach($tempfolder in $tempfolders2){$tmp = "$tmp" + "$tempfolder, "}

                if($NoMatch){"No files found to delete - $(($tmp.Trim()).Trimend(','))"}

                #####################################################
                ###   add files and file types to delete - no recurse
                #####################################################
                $files = $null; $files = @()
                $file = $null
                $limit1x = (get-date) #.AddDays(0) #today
                $files += Get-ChildItem "C:\windows\system32\hs_err_pid*.mdmp"
                $files += Get-ChildItem "C:\windows\system32\hs_err_pid*.log"
                $files += Get-ChildItem "C:\windows\Minidump\*.dmp"
                $files += Get-ChildItem "C:\windows\Memory.dmp"

                foreach ($file in $files){
                    Try { 
                        # how to write output without a newline
                        Remove-Item $file.FullName -Force –ErrorAction Stop -ErrorVariable customError # delete the file
                        "Delete $($file.FullName)"
                        $NoMatch = $false
                    } #try
                    Catch { 
                        #$cstmError = $customError -split "`n"
                        " ##### Error = $(($error[0].Exception -split "`n")[0])"# adds error to same line
                        $error.clear()
                        $NoMatch = $false
                    } #catch
                } #for

                if($NoMatch){"No files found to delete - \hs_err_pid*.mdmp, \hs_err_pid*.log, \MiniDump\*.DMP, or Memory.DMP"}
        
            }#funct
            function Clean-UserCrashDmp{
                $NoMatch = $true
                $x = "c:\Users"
                $Users = (dir $x | Select-Object name).name

                foreach ($User in $Users){
                    $file = $files = $UserDump = $null; $files = @()
                    # Get User CrashDumps and delete
                    $UserDump = "$($x)\$User\AppData\Local\CrashDumps\*"
                    if ((Test-Path -Path "$($UserDump)") -eq $true){
                        $files = Get-ChildItem -Path "$($UserDump)" -Recurse -Force | Where-Object {!$_.PSIsContainer}                   
                        foreach($file in $files){
                            Try {
                                Remove-Item $file.FullName -Force –ErrorAction Stop -ErrorVariable customError # delete the file
                                "Delete $($file.FullName)"
                                $NoMatch = $false
                            } #try
                            Catch { #$cstmError = $customError -split "`n"
                                " ##### Error = $($customError)" # append error
                                $customError.clear()
                                $NoMatch = $false
                            } #catch
                        } #foreach
                    } #if
                } #foreach
                
                if($NoMatch){"No files found to delete - c:\Users\<UserName>\AppData\Local\CrashDumps\*"}
            
            } #funct
            #endregion - Functions
            #------------------------------------------------------------------
            ""
            "###############################################################################"
            "###############################################################################"
            "HostName = $($env:computername)"
            ""
            Cleanup-TempNdmpfiles # function call
            Clean-UserCrashDmp    # function call
            #------------------------------------------------------------------
        } #process
        End {
            # PowerShell Script ...END
        } #end
        ###################################################################################################
        ### End section ###################################################################################
        ###       Change this section to modify the command that is run on each remote server           ###
        ###################################################################################################
        ###################################################################################################
    } #scriptblock

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $Script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CleanSysDrv.Scripts.DelSWdistr = {
    # Validate input
    if ($UIMaster.RemoteScriptRun -and (-not($UIMaster.ServerText))){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -InputObject @{
        VerifyDir        = $CleanSysDrv.VerifyDir
        DeleteFileNamesx = $CleanSysDrv.DeleteFileNamesx
        TextOutput       = $CleanSysDrv.TextOutput
    } #Export-Clixml

    $SubScriptMessage = "$(($CleanSysDrv.ScriptName) -replace ".ps1") - del Softwaredistribution"

    $Script = Convert-ScriptOutputToText {           
        ""
        "###############################################################################"
        "###############################################################################"
        "HostName = $($env:computername)"
        ""
        $NoMatch = $true
        $tempfolder = @("C:\Windows\Softwaredistribution") # folders to clean-up
                
        If (-not(Test-Path $tempfolder)){
            "# Not found - $($tempfolder)" # $folder does not exist
            return
        } #if

        # verify Softwaredistribution size
        $colItems = Get-ChildItem $tempfolder | Where-Object {$_.PSIsContainer -eq $true} | Sort-Object
        foreach ($i in $colItems){
            $subFolderItems = Get-ChildItem $i.FullName -recurse -force -EA SilentlyContinue | 
                Where-Object {$_.PSIsContainer -eq $false} | Measure-Object -property Length -sum | 
                Select-Object Sum
            $FolderItems = $FolderItems + $subFolderItems.Sum
        } #%
        
        #$FolderSize = [math]::round($FolderItems,0)
        #if($FolderSize -le 1GB){ # No files found
            "# Folder size < 1GB - $($tempfolder)" # $folder has no files (with data)
        #    return 
        #} #if
        
        # continue if folder exists and size > 0 bytes
        
        # stop services - required to delete Softwaredistribution files
        Stop-Service -Name 'wuauserv' -Passthru
        Stop-Service -Name 'bits'     -Passthru
        Stop-Service -Name 'trustedinstaller' -Passthru

        ### Get all the matching files ###
        $files = $null
        $files = Get-ChildItem -Path "$($tempfolder)" -Recurse -Force | Where-Object {!$_.PSIsContainer -and ($_.LastWriteTime -le $limit1x)}

        ### Delete the matching files ###
        foreach ($file in $files) {
            if ($file.FullName.length -gt 0) {
                Try { 
                    Remove-Item $file.FullName -Force –ErrorAction Stop -ErrorVariable customError # delete the file
                    "Delete $($file.FullName)"
                    $NoMatch = $false
                }
                Catch { #$cstmError = $customError -split "`n"
                    " ##### Error = $($customError)"
                    $customError.clear()
                    $NoMatch = $false
                }
            } #if
        } #%
        if($NoMatch){"No files found to delete - $($tempfolder)"}

        # Start services
        Start-Service -Name 'wuauserv' -Passthru
        Start-Service -Name 'bits'     -Passthru
        Start-Service -Name 'trustedinstaller' -Passthru
    } # script

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $Script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # 
$CleanSysDrv.Scripts.VerifyDir  = {
    # Validate input
    if ($UIMaster.RemoteScriptRun -and (-not($UIMaster.ServerText))){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($CleanSysDrv.VerifyDir -eq ""){Show-UIMessageBox "      No FolderPath Entered!";return} #if

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -InputObject @{
        VerifyDir        = $CleanSysDrv.VerifyDir
        DeleteFileNamesx = $CleanSysDrv.DeleteFileNamesx
        TextOutput       = $CleanSysDrv.TextOutput
    } #Export-Clixml

    $SubScriptMessage = "$(($CleanSysDrv.ScriptName) -replace ".ps1") - Verify dir"
    $ArgumentList     = $CleanSysDrv.VerifyDir
    $Script = {
        Param($VerifyDir)

        # Filter
        Filter ConvertTo-KMG {
                    $bytecount = $_
                    switch ([math]::truncate([math]::log($bytecount,1024))) {
                        0 {"$bytecount Bytes"}
                        1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                        2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                        3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                        4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                        5 {"{0:n2} PB" -f ($bytecount / 1pb)}
                    } #switch
            } #filter
            
        $temp = $VerifyDir -split "`r`n" | ForEach Trim | Where {$_}  # trim & remove empty rows
        Foreach($item in $temp){ 
            #dir $item | select Mode,FullName,@{Name='Size';Expression={$_.Length | ConvertTo-KMG}},LastWriteTime
            dir $item | select Mode,FullName,@{Name="Size(MB)";Expression={"{0:n2}" -f ($_.Length / 1mb)}},LastWriteTime
        } #for
    } #$script

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CleanSysDrv.Scripts.DelTextbox = {
    # Validate input
    if ($UIMaster.RemoteScriptRun -and (-not($UIMaster.ServerText))){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($CleanSysDrv.Delete  -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return} 
    
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -InputObject @{
        VerifyDir        = $CleanSysDrv.VerifyDir
        DeleteFileNamesx = $CleanSysDrv.DeleteFileNamesx
        TextOutput       = $CleanSysDrv.TextOutput
    } #Export-Clixml
    
    $SubScriptMessage = "$(($CleanSysDrv.ScriptName) -replace ".ps1") - Custom delete"
    $ArgumentList     = $CleanSysDrv.DeleteFileNamesx
    $Script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string[]]$DeleteFileNamesx
        )
        Begin{
            ""
            "###############################################################################"
            "###############################################################################"
            "HostName = $($env:computername)"
            ""
        }
        Process{
            $Deletelist = $DeleteFileNamesx.Split("`n").Trim() | Where {$_.trim() -ne ""} # trim & remove empty rows
            foreach ($item in $Deletelist){ 
                if(Test-Path "$($item)"){ 
                    remove-item "$($item)" -force -recurse -ErrorAction SilentlyContinue
                    if(Test-Path "$item"){"Delete Fail - $($item)"}
                    else {"Delete Success - $($item)"}
                }
                else {"Not found - $($item)"}
            } #for        
        }
        End{""}
    } #$script
    
    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
#endregion
#------------------------------------------------------
#region - UI Data Loading...
# Read in the script settings file and populate the textbox.
try {
    $SettingsClixml = Import-Clixml "$($CleanSysDrv.WorkingDirectory)\$($CleanSysDrv.SelectedCacheFolder)\$($CleanSysDrv.ScriptName).xml" -ErrorAction Stop
    $list = 'VerifyDir','DeleteFileNamesx','TextOutput'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $CleanSysDrv.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *,auto -DataContext $CleanSysDrv {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
        #region - Gridrow 0
            New-UIStackPanel -Orientation Vertical {

                # CleanSysDrv:
                New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -Foreground Blue -FontWeight Bold
                New-UITextBlock "CleanSysDrv:" -Margin 20,0,0,0 -AlsoSet @{FontSize=18} -FontWeight Bold
                New-UITextBlock "This will attempt to free space on the System drive by deleting temp files, crash dump files, etc." -Margin 20,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "The actions below provide several tools to assist." -Margin 20,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock ("*" * 90) -Margin 20,10,0,0 -Foreground Blue -FontWeight Bold
                
                # Get drive space
                New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 { # needed for indent
                    New-UITextBlock "Verify drive space:" -Margin 0,0,10,0 -AlsoSet @{FontSize=14} -FontWeight Bold
                    New-UITextBlock "This will collect drive letter, capacity, freespace." -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UIStackPanel -Orientation Horizontal -Margin 0,10,0,0 {
                        New-UIButton "Verify" -Padding 10,6,10,6 -Align TopLeft -Foreground Green `
                             -AddClick $CleanSysDrv.Scripts.VerifyDisk
                        New-UITextBlock "Initiate the verify" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} -Foreground Green
                    } #StackPanel
                    New-UITextBlock ("*" * 90) -Margin 1,15,0,0 -Foreground Blue -FontWeight Bold
                } #StackPanel

                # Delete Temp:
                New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 {
                    New-UITextBlock "Delete files:" -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -FontWeight Bold
                    New-UITextBlock "...\Temp\*" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\windows\Temp\*" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\windows\system32\hs_err_pid*.mdmp" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\windows\system32\hs_err_pid*.log" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\windows\Minidump\*.dmp" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\windows\Memory.dmp" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "...\Users\<username>\AppData\Local\CrashDumps\*" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UIStackPanel -Orientation Horizontal -Margin 0,10,0,0 {
                        New-UIButton "Run" -Padding 10,4,10,6 -Align TopLeft -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $CleanSysDrv.Scripts.DelTemp
                        New-UITextBlock "Initiate the delete" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} -Foreground Red
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 90) -Margin 20,10,0,0 -Foreground Blue -FontWeight Bold
                
                # Stop Services:
                New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 {
                    New-UITextBlock "This will verify C:\Windows\Softwaredistribution > 1GB before continuing" -Margin 0,0,0,10 -AlsoSet @{FontSize=14} -Foreground Green -FontWeight Bold
                    
                    New-UITextBlock "Stop Services:" -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -FontWeight Bold
                    New-UITextBlock "wuauserv`tWindows Update Service" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "bits`t`tBackground Intelligent Transfer" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "trustedinstaller`tWindows Modules Installer Service (trustedinstaller)" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "Delete files:" -Margin 0,6,0,0 -AlsoSet @{FontSize=14} -FontWeight Bold
                    New-UITextBlock "...\Windows\Softwaredistribution\*" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "Start Services:" -Margin 0,6,0,0 -AlsoSet @{FontSize=14} -FontWeight Bold
                    New-UITextBlock "wuauserv`tWindows Update Service" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "bits`t`tBackground Intelligent Transfer" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UITextBlock "trustedinstaller`tWindows Modules Installer Service (trustedinstaller)" -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                    New-UIStackPanel -Orientation Horizontal -Margin 0,10,0,0 {
                        New-UIButton "Run" -Padding 10,4,10,6 -Align TopLeft -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $CleanSysDrv.Scripts.DelSWdistr
                        New-UITextBlock "Initiate the delete" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} -Foreground Red
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 90) -Margin 20,10,0,0 -Foreground Blue -FontWeight Bold
            } #StackPanel

            # Verify Folder Contents
            New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 {
                New-UITextBlock "Verify Multi File/Folder:" -AlsoSet @{FontSize=14} -FontWeight Bold
                New-UITextBlock "Table output: (dir or file), FullName, Size (n/a for folder), LastWriteTime" -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "Enter a Folder fullpath, a file Fullpath, or both." -Margin 0,0,0,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBlock "Wildcards and mixed drives are allowed." -Margin 0,0,0,10 -AlsoSet @{FontSize=14} -Foreground Black
                        
                New-UITextBox -Width 666 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo VerifyDir
                New-UIStackPanel -Orientation Horizontal -Margin 0,10,0,0 { # needed for proper indent
                    New-UIButton "Verify" -Padding 10,6,10,6 -Align TopLeft -Foreground Green `
                        -AddClick $CleanSysDrv.Scripts.VerifyDir
                    New-UITextBlock "Initiate the verify" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} -Foreground Green
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 0,10,0,80 -FontWeight Bold
            } #StackPanel

            # Delete Textbox
            <#
            New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 { # needed for indent
                New-UITextBlock "Delete:" -Foreground Red -AlsoSet @{FontSize=14} -FontWeight Bold
                New-UITextBlock "This will delete files (of your choosing) on server(s) from the main tab." -Margin 0,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBlock "Enter the local path and filename to delete. Multiple files allowed...full path for each." -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBlock "Example:`t`tc:\temp\file1.txt" -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBlock "`t`td:\folder1\file1.txt" -Margin 0,0,0,10 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBox -Width 666 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo DeleteFileNamesx -Foreground Red
                New-UIStackPanel -Orientation Horizontal -Margin 0,10,0,0 {
                    New-UIButton "Run" -Padding 10,6,10,6 -Align TopLeft `
                         -AddClick $CleanSysDrv.Scripts.DelTextbox -Foreground Red
                    New-UITextBlock "Initiate the delete" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} -Foreground Red
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 1,10,0,80 -Foreground Blue -FontWeight Bold
            } #StackPanel
            #>
        #endregion - Gridrow 0
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel

} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 