﻿<#
.SYNOPSIS  
    (Input tab) - Allows creating a pssession to execute cmds from textbox. Only 1st server in the list is used.
.ROLE
    Utility
.FUNCTIONALITY
    Scratchpad,pssession,session,custom,scriptblock,cmd,command,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$ScratchpadSessionMaster = New-UIObject
$ScratchpadSessionMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$ScratchpadSessionMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$ScratchpadSessionMaster.PSsessionx = $null
$ScratchpadSessionMaster.TextboxCmds = "ipconfig"
$ScratchpadSessionMaster.TextboxOutput = $null
$ScratchpadSessionMaster.Server = $null
$ScratchpadSessionMaster.Scripts = @{}
$ScratchpadSessionMaster.Scripts.CreateSession = {
    # Get 1st ComputerName in $UIMaster.ServerText (from Servers Textbox)
    $ScratchpadSessionMaster.Server = $UIMaster.ServerText -split "`r`n" | Select -First 1 |
        ForEach-Object Trim | Where-Object { $_ -ne "" }
    $PSsessionx = New-PSSession -ComputerName ($ScratchpadSessionMaster.Server) -Name ($ScratchpadSessionMaster.Server) `
        -Credential (Get-WFServerCredential -Server ($ScratchpadSessionMaster.Server))
    #$PSsessionx | out-host
    $ScratchpadSessionMaster.PSsessionx = $PSsessionx

    [string[]]$TextboxOutput += '##############################################################' | out-string 
    $TextboxOutput += ($ScratchpadSessionMaster.PSsessionx) | out-string
    $ScratchpadSessionMaster.TextboxOutput = $TextboxOutput | out-string
}.GetNewClosure() #.CreateSession
$ScratchpadSessionMaster.Scripts.Run           = {

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($ScratchpadSessionMaster.WorkingDirectory)\$($ScratchpadSessionMaster.ScriptName).xml" -InputObject @{
        TextboxCmds = $ScratchpadSessionMaster.TextboxCmds
    } #Export-Clixml

    $SubScriptMessage = "$(($ScratchpadSessionMaster.ScriptName) -replace ".ps1")" # create console subscript message

    # Convert textbox contents to scriptblock
    $remoteCommand = $ScratchpadSessionMaster.TextboxCmds
    $scriptBlock1 = [Scriptblock]::Create($remoteCommand)
    
    # Execute the session cmds
    $SessionResults = Invoke-Command -Session ($ScratchpadSessionMaster.PSsessionx) -scriptblock $scriptBlock1
    #$SessionResults | Out-Host # echo cmd results
    $TextboxOutput += $SessionResults | out-string 
    $ScratchpadSessionMaster.TextboxOutput += $TextboxOutput | out-string
}.GetNewClosure() # .Run1
$ScratchpadSessionMaster.Scripts.CloseSession  = {
    # Remove the session
    Get-Pssession | Remove-PSSession
    if(Get-PSSession){
        $TextboxOutput += 'Failed to remove PSSession' | out-string
        $TextboxOutput += '##############################################################' | out-string 
        $ScratchpadSessionMaster.TextboxOutput += $TextboxOutput
    }
    else {
        Write-Host 'PSSession removed' -foreground Cyan
        $TextboxOutput += "PSSession removed`r`n" | out-string
        $TextboxOutput += '##############################################################' | out-string 
        $ScratchpadSessionMaster.TextboxOutput += $TextboxOutput
    }
}.GetNewClosure() # .CloseSession
$ScratchpadSessionMaster.Scripts.Cls = {$ScratchpadSessionMaster.TextboxOutput = $null}.GetNewClosure() # .Cls

# Read in the script settings file and populate the textbox.
try {
    $SettingsClixml = Import-Clixml "$($ScratchpadSessionMaster.WorkingDirectory)\$($ScratchpadSessionMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'TextboxCmds'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $ScratchpadSessionMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

#endregion
#------------------------------------------------------
#region - UI Data Loading
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $ScratchpadSessionMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 210) -Margin 14,10,0,0 -FontWeight Bold
            New-UITextBlock "Scratch Pad:" -FontWeight Bold -Margin 14,10,0,0

            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBlock "This will run the commands, listed in the textbox below, on the server(s) from the Main tab." -Margin 20,20,0,0
                    New-UITextBox -Width 500 -Height 400 -Margin 20,30,0,0 -AcceptsReturn $true `
                        -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible `
                        -BindTextTo TextboxCmds
                } #StackPanel
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBlock "Output is listed here." -Margin 20,20,0,0
                    New-UITextBox -Width 600 -Height 400 -Margin 10,30,0,0 -AcceptsReturn $true `
                        -AlsoSet @{FontFamily='Consolas'} `
                        -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible `
                        -BindTextTo TextboxOutput
                } #StackPanel
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal {
                New-UIButton "Create Session" -Padding 14,4,14,6 -Margin 20,20,0,0 -Foreground Black -AlsoSet @{FontSize=14} `
                    -AddClick $ScratchpadSessionMaster.Scripts.CreateSession
                New-UIButton "Run" -Padding 14,4,14,6 -Margin 20,20,0,0 -Foreground Red -AlsoSet @{FontSize=14} `
                    -AddClick $ScratchpadSessionMaster.Scripts.Run
                New-UIButton "Remove Session" -Padding 14,4,14,6 -Margin 20,20,0,0 -Foreground Black -AlsoSet @{FontSize=14} `
                    -AddClick $ScratchpadSessionMaster.Scripts.CloseSession
                New-UIButton "Cls" -Padding 14,4,14,6 -Margin 20,20,0,0 -Foreground Black -AlsoSet @{FontSize=14} `
                    -AddClick $ScratchpadSessionMaster.Scripts.Cls
            } #StackPanel
            New-UITextBlock ("*" * 210) -Margin 20,10,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 