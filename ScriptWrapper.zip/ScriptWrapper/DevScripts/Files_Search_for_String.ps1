﻿<#
.SYNOPSIS  
    (Input tab) This will search files in folder/subfolders for string (and optionally replace string with new).
.ROLE
    Utility
.FUNCTIONALITY
    files,search,find,string,KeyWord,InputTab,NoServersNeeded
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$error.clear()
$RootPath = ""
#$RootPath = "C:\temp\ProdSupScripts\Scripts"
#$RootPath  = "H:\a382453\01-PowerShell"

$FileSearchMaster = New-UIObject
$FileSearchMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$FileSearchMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$FileSearchMaster.RootPath      = $RootPath # Textbox
$FileSearchMaster.Ext           = "ps1"     # Textbox
$FileSearchMaster.KeyWord       = '"include quotes if your string includes quotes"'  # Textbox
$FileSearchMaster.NewKeyWord    = '"include quotes if your string includes quotes"'  # Textbox
$FileSearchMaster.UNCpath       = $true     # radio button
$FileSearchMaster.DrivePath     = $false    # radio button
#endregion
#--------------------------------------------------
#region - UI Action Scripts
$FileSearchMaster.Scripts = @{}
$FileSearchMaster.Scripts.FindString = {
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($FileSearchMaster.WorkingDirectory)\$($FileSearchMaster.ScriptName).xml" -InputObject @{
        # The names must be identical to allow the Import-Clixml to work correctly ()
        # Ex: UNCpath = xyz.UNCpath
        UNCpath       = $FileSearchMaster.UNCpath
        DrivePath     = $FileSearchMaster.DrivePath
        RootPath      = $FileSearchMaster.RootPath
        Ext           = $FileSearchMaster.Ext
        KeyWord       = $FileSearchMaster.KeyWord
        NewKeyWord    = $FileSearchMaster.NewKeyWord
    } #Export-Clixml

    $RootPath      = $FileSearchMaster.RootPath # get the textbox contents
    $Ext           = $FileSearchMaster.Ext      # get the textbox contents
    $KeyWord       = $FileSearchMaster.KeyWord  # get the textbox contents
    $UNCpath       = $FileSearchMaster.UNCpath  # get radiobutton (true/false)
    $NewKeyWord    = $FileSearchMaster.NewKeyWord  # get the textbox contents

    $ArgumentList = $UNCpath,$RootPath,$Ext,$KeyWord,$NewKeyWord # send these to the param of the $script
    $SubScriptMessage = "$(($FileSearchMaster.ScriptName) -replace ".ps1") - Search files for string" # create console subscript message

    $script = Convert-ScriptOutputToText {
        Param([bool]$UNCpath,[string]$RootPath,[string]$Ext,[string]$KeyWord,[string]$NewKeyWord)

        # Searching files for a match
        #############
        if($UNCpath){
            # Check for typo
            if ($RootPath -notlike "*\\*"){
                Write-Host "Path does not contain \\, please try again." -f Red #echo to console
                "Path does not contain \\, please try again."                   #echo to Output
                write-host "Script Stopped" -foregroundcolor Cyan               #echo to console
                "Script Stopped"                                                #echo to Output
                return
            } #if
            
            # All good - get available drive
            $AvailDrive1 = ls function:[d-z]: -n | ?{ !(test-path $_) } | select -Last 1
            $AvailDrive2 = $AvailDrive1 -replace (':','')
            
            Try{
                # Connect New-PSDrive to Available drive
                New-PSDrive -Name $AvailDrive2 -Root $RootPath -PSProvider "FileSystem" -ErrorAction Stop | Out-Null

                cd $AvailDrive1
            
                # Get files then search their content - output file name
                Try{
                    # Get files then search their content - output file name
                    Get-ChildItem -filter "*.$($Ext)" -recurse -ErrorAction Stop |
                        ?{$_.psiscontainer -eq $false} | 
                        %{
                            write-host "checking file - $_" #echo to console - shows progress
                            $x = Get-Content $_.pspath -ErrorAction Stop | select-string -pattern $KeyWord
                            if($x){ "Match found = $($_ | select -expandproperty fullname)" }
                        } #%
                } #try
                Catch {
                    write-host "$error[0].Exception" -foregroundcolor Red
                    $error[0].Exception
                    write-host "Script Stopped" -foregroundcolor Cyan #echo to console
                    "Script Stopped" #echo to Output
                } #catch
                # Set location back to original: To allow removing the psdrive
                cd c:
                Remove-PSDrive -Name $AvailDrive2 -force
                
                write-host '' #echo to console
                write-host "Script Complete" -foregroundcolor Cyan #echo to console - progress complete
            }
            Catch {
                write-host "$error[0].Exception" -foregroundcolor Red
                $error[0].Exception
                write-host "Script Stopped" -foregroundcolor Cyan #echo to console
                "Script Stopped" #echo to Output
                return
            }

        } #if
        else {
            if ($RootPath -notlike "*:\*"){
                Write-Host "Path does not have [driveletter]:\, please try again." -f Red #echo to console
                "Path does not have [driveletter]:\, please try again."                   #echo to Output
                write-host "Script Stopped" -foregroundcolor Cyan                         #echo to console
                "Script Stopped"                                                          #echo to Output
                return
            } #if
            cd $RootPath # All good
            Try{
                # Get files then search their content - output file name
                Get-ChildItem -filter "*.$($Ext)" -recurse -ErrorAction Stop |
                    ?{$_.psiscontainer -eq $false} | 
                    %{
                        write-host "checking file - $_" #echo to console - shows progress
                        $x = Get-Content $_.pspath -ErrorAction Stop | select-string -pattern $KeyWord
                        if($x){ "Match found = $($_ | select -expandproperty fullname)" }
                    } #%
            } #try
            Catch {
                write-host "$error[0].Exception" -foregroundcolor Red
                $error[0].Exception
                write-host "Script Stopped" -foregroundcolor Cyan #echo to console
                "Script Stopped" #echo to Output
                return
            } #catch
        } #else
    } #script

    # set the script type for proper execution
    $UIMaster.ConnectionType = "Local_NoSvrs"
    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .FindString
$FileSearchMaster.Scripts.Replace = {
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($FileSearchMaster.WorkingDirectory)\$($FileSearchMaster.ScriptName).xml" -InputObject @{
        # The names must be identical to allow the Import-Clixml to work correctly ()
        # Ex: UNCpath = xyz.UNCpath
        UNCpath       = $FileSearchMaster.UNCpath
        DrivePath     = $FileSearchMaster.DrivePath
        RootPath      = $FileSearchMaster.RootPath
        Ext           = $FileSearchMaster.Ext
        KeyWord       = $FileSearchMaster.KeyWord
        NewKeyWord    = $FileSearchMaster.NewKeyWord
    } #Export-Clixml

    $RootPath      = $FileSearchMaster.RootPath # get the textbox contents
    $Ext           = $FileSearchMaster.Ext      # get the textbox contents
    $KeyWord       = $FileSearchMaster.KeyWord  # get the textbox contents
    $UNCpath       = $FileSearchMaster.UNCpath  # get radiobutton (true/false)
    $NewKeyWord    = $FileSearchMaster.NewKeyWord  # get the textbox contents

    $ArgumentList = $UNCpath,$RootPath,$Ext,$KeyWord,$NewKeyWord # send these to the param of the $script
    $SubScriptMessage = "$(($FileSearchMaster.ScriptName) -replace ".ps1") - Search files for string" # create console subscript message

    $script = Convert-ScriptOutputToText {
        Param([bool]$UNCpath,[string]$RootPath,[string]$Ext,[string]$KeyWord,[string]$NewKeyWord)

        # Searching files for a match
        #############
        if($UNCpath){
            # Check for typo
            if ($RootPath -notlike "*\\*"){
                Write-Host "Path does not contain \\, please try again." -f Red #echo to console
                "Path does not contain \\, please try again."                   #echo to Output
                write-host "Script Stopped" -foregroundcolor Cyan               #echo to console
                "Script Stopped"                                                #echo to Output
                return
            } #if
            
            # All good - get available drive
            $AvailDrive1 = ls function:[d-z]: -n | ?{ !(test-path $_) } | select -Last 1
            $AvailDrive2 = $AvailDrive1 -replace (':','')
            
            # Connect New-PSDrive to Available drive
            New-PSDrive -Name $AvailDrive2 -Root $RootPath -PSProvider "FileSystem" -ErrorAction Stop | Out-Null

            cd $AvailDrive1
            
            # Get files then search their content - output file name
            Try{
                # Get files then search their content - output file name
                Get-ChildItem -filter "*.$($Ext)" -recurse -ErrorAction Stop |
                    ?{$_.psiscontainer -eq $false} | 
                    %{
                        write-host "checking file - $_" #echo to console - shows progress
                        $x = Get-Content $_.pspath -ErrorAction Stop #| select-string -pattern $KeyWord
                        if($x | select-string -pattern $KeyWord){ 
                            "Updating file = $($_ | select -expandproperty fullname)"
                            $x -replace $KeyWord,$NewKeyWord | Set-Content $_.pspath -ErrorAction Stop
                        } #if
                    } #%
            } #try
            Catch {
                write-host "$error[0].Exception" -foregroundcolor Red
                $error[0].Exception
                write-host "Script Stopped" -foregroundcolor Cyan #echo to console
                "Script Stopped" #echo to Output
            } #catch
            # Set location back to original: To allow removing the psdrive
            cd c:
            Remove-PSDrive -Name $AvailDrive2 -force
                
            write-host '' #echo to console
            write-host "Script Complete" -foregroundcolor Cyan #echo to console - progress complete
        } #if
        else {
            if ($RootPath -notlike "*:\*"){
                Write-Host "Path does not have [driveletter]:\, please try again." -f Red #echo to console
                "Path does not have [driveletter]:\, please try again."                   #echo to Output
                write-host "Script Stopped" -foregroundcolor Cyan                         #echo to console
                "Script Stopped"                                                          #echo to Output
                return
            } #if
            cd $RootPath # All good
            Try{
                # Get files then search their content - output file name
                Get-ChildItem -filter "*.$($Ext)" -recurse -ErrorAction Stop |
                    ?{$_.psiscontainer -eq $false} | 
                    %{
                        write-host "checking file - $_" #echo to console - shows progress
                        $x = Get-Content $_.pspath -ErrorAction Stop #| select-string -pattern $KeyWord
                        if($x | select-string -pattern $KeyWord){ 
                            "Updating file = $($_ | select -expandproperty fullname)" 
                            $x -replace $KeyWord,$NewKeyWord | Set-Content $_.pspath -ErrorAction Stop
                        } #if
                    } #%
            } #try
            Catch {
                write-host "$error[0].Exception" -foregroundcolor Red
                $error[0].Exception
                write-host "Script Stopped" -foregroundcolor Cyan #echo to console
                "Script Stopped" #echo to Output
                return
            } #catch
        } #else
    } #script

    # set the script type for proper execution
    $UIMaster.ConnectionType = "Local_NoSvrs"
    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .ReplaceString
#endregion
#--------------------------------------------------
#region - UI Data Loading

# Read in the script settings file and populate the GUI.
try {
    $SettingsClixml = Import-Clixml "$($FileSearchMaster.WorkingDirectory)\$($FileSearchMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'UNCpath','DrivePath','RootPath','Ext','KeyWord','NewKeyWord'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $FileSearchMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $FileSearchMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock "$("*" * 200)" -Margin 20,10,0,0 -FontWeight Bold
            New-UITextBlock "Purpose:" -FontWeight Bold -Margin 20,0,0,0 -AlsoSet @{FontSize=18}
            New-UITextBlock "This will search files for a string." -Margin 20,0,0,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "Optional: replace with a new string." -Margin 20,0,0,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "Output: List of file names found/updated." -Margin 20,0,0,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "$("*" * 47)" -Margin 20,10,0,0 -FontWeight Bold
            New-UIStackPanel -Orientation Horizontal {
                New-UIRadioButton "Path is UNC" -Margin 20,10,4,0 -BindIsCheckedTo UNCpath -Foreground Red -AlsoSet @{FontSize=14}
                New-UIRadioButton "Path is Drive Letter" -Margin 20,10,4,0 -BindIsCheckedTo DrivePath -Foreground Red -AlsoSet @{FontSize=14}
            } #StackPanel
            
            New-UITextBlock "Path containing the files to search:" -Margin 20,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
            New-UITextBox -Width 580 -Height 20 -Align CenterLeft -Margin 20,4,0,0 -BindTextTo RootPath -Foreground Green -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Vertical {
                New-UITextBlock "File ext for search:" -Margin 20,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBox -Width 50 -Height 20 -Align CenterLeft -Margin 20,4,0,0 -BindTextTo Ext -Foreground Green -AlsoSet @{FontSize=14}
            } #StackPanel
            New-UIStackPanel -Orientation Vertical {
                New-UITextBlock "Search for String:" -Margin 20,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBox -Width 580 -Height 20 -Align CenterLeft -Margin 20,4,0,0 -BindTextTo KeyWord -Foreground Green -AlsoSet @{FontSize=14}
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal -Margin 20,4,0,0 {
                New-UIButton "Find" -Padding 14,4,14,6 -Foreground Blue -AlsoSet @{FontSize=14}`
                    -AddClick $FileSearchMaster.Scripts.FindString
            } #StackPanel
            #New-UITextBlock "$("*" * 200)" -Margin 20,10,0,0 -FontWeight Bold-AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Vertical {
                New-UITextBlock "New string:" -Margin 20,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBox -Width 580 -Height 20 -Align CenterLeft -Margin 20,4,0,0 -BindTextTo NewKeyWord -Foreground Green -AlsoSet @{FontSize=14}
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal -Margin 20,4,0,0 {
                New-UIButton "Replace" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                    -AddClick $FileSearchMaster.Scripts.Replace
            } #StackPanel
            New-UITextBlock "$("*" * 200)" -Margin 20,10,0,40 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 