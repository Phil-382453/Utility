﻿<#
.SYNOPSIS  
    Collect remote access card info for a several servers (Full text output)
.ROLE
    OOB
.FUNCTIONALITY
    OOB,Manufacturer,HP,Dell,ilo,drac,remote,access,Text
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Text
#>

# "test test" .... will write to the output tab of the Script_UI on your laptop
# "test test" | out-host ......out-host will write to the console on your laptop...not the output tab of the Script_U
# write-Host "test test" ....Write-host will write to the console on your laptop...not the output tab of the Script_U

$Manuf = (gwmi Win32_ComputerSystem).Manufacturer 
""
"#################################################################"
"Hostname = $env:COMPUTERNAME"
""
if ($Manuf -match "(HP|Hewlett Packard)"){

    $hponcfgPath =  "c:\progra~1\HP\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~1\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~2\hponcfg\hponcfg.exe",
                    "c:\windows\tools\hponcfg.exe",
                    "c:\temp\hponcfg.exe" | 
                    Where-Object { Test-Path $_ } | Select-Object -First 1
    if (!$hponcfgPath) { # "HPONCFG NOT FOUND" 
        "HPONCFG FILE NOT FOUND"
        ""
    } #if
    else {
        & $hponcfgPath /w "$($env:systemdrive)\temp\ILO.txt" # dump ilo config to text
        start-sleep -s 2 # sleep 2 seconds
        $iloFile = Get-Content "$($env:systemdrive)\temp\ILO.txt"
            
        if(!$iloFile){ # "HPONCFG NO OUTPUT" 
            "HPONCFG output file not found"
            ""
        }
        else{
            $iloFile # echo to output
            ""
        }
    }
} #if
elseif ($Manuf -match "Dell") {
    $reportText = $null
    $reportText = omreport.exe chassis remoteaccess
    if (!($reportText)) {
        $omreport =  "c:\progra~1\Dell\SysMgt\oma\bin\omreport.exe","" | Where-Object { Test-Path $_ } | Select-Object -First 1
    
        if ($omreport){ 
           $omreport =  $omreport -replace ("omreport.exe","")
            cd $omreport
            $reportText = .\omreport.exe chassis remoteaccess
        } #if
    } #if

    if (!$reportText) {
        "omreport.exe did not return output"
    } #if
    elseif ($reportText -like "*Error*") {
        foreach ($line in $reportText){
            if ($line -like "*Error*") { "omreport.exe: $($line.Trim())" } #if
        } #foreach
    }
    else{
        $reportText
        ""
    }
} #elseif
elseif ($Manuf -match "VMware"){
        "VMware"
        ""
} #elseif