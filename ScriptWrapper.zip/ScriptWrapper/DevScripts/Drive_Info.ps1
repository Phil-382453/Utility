﻿<#
.SYNOPSIS  
    Get Disk information - Name, Model, Partition, DiskSize, Space, PercentFree, SerialNumber, etc
.ROLE
    Drive
.FUNCTIONALITY
    storage,volume,disks,space,free,partition,san,hardware,Drive_Info,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

    # Filter
    Filter ConvertTo-KMG {
            <#
            Synopsis
            Converts bytes to Byte\KB\MB\GB\TB\PB format
            DESCRIPTION
            Accepts an [int64] byte count, and converts to Byte\KB\MB\GB\TB\PB format
            with decimal precision of 2
            EXAMPLE
            3000 | convertto-kmg
            #>

            $bytecount = $_
            switch ([math]::truncate([math]::log($bytecount,1024))) {
                0 {"$bytecount Bytes"}
                1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                Default {"{0:n2} PB" -f ($bytecount / 1pb)}
            } #switch
    } #filter

    # Disks - collect info
    $hostname = $env:COMPUTERNAME
    $DriveObjs = $null;$DriveObjs = @()
    $WMI_DiskkProps     = @('DeviceID','Name','Model','Index','SerialNumber')
    $wmi_diskdrives     = Get-WmiObject -Class Win32_DiskDrive | select $WMI_DiskkProps | sort Index

    $DiskElements = @('HostName','Disk','Model','Partition','Index','VolumeName','Drive','DiskSize',`
                        'FreeSpace','PercentFree','UsedSpace','SerialNumber')
    foreach ($drive in $wmi_diskdrives){
        $partitionquery = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID=`"$($drive.DeviceID.replace('\','\\'))`"} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
        $partitions = @(Get-WmiObject -Query $partitionquery)
        foreach ($partition in $partitions){
            $logicaldiskquery = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID=`"$($partition.DeviceID)`"} WHERE AssocClass = Win32_LogicalDiskToPartition"
            $logicaldisks = @(Get-WmiObject -Query $logicaldiskquery)
            foreach ($logicaldisk in $logicaldisks){
                    $PercentFree = [math]::round((($logicaldisk.FreeSpace/$logicaldisk.Size)*100))
                    $UsedSpace = ($logicaldisk.Size - $logicaldisk.FreeSpace)
                    $diskprops = @{
                        HostName     = $hostname # each collection will have its own worksheet. Computer name is needed
                        Disk         = $drive.Name
                        Model        = $drive.Model
                        Partition    = $partition.Name
                        Index        = $drive.index
                        #Description  = $partition.Description
                        #PrimaryPartition = $partition.PrimaryPartition
                        VolumeName   = $logicaldisk.VolumeName
                        Drive        = $logicaldisk.Name
                        DiskSize     = if ($RawDriveData) { $logicaldisk.Size } else { $logicaldisk.Size | ConvertTo-KMG }
                        FreeSpace    = if ($RawDriveData) { $logicaldisk.FreeSpace } else { $logicaldisk.FreeSpace | ConvertTo-KMG }
                        PercentFree  = $PercentFree
                        UsedSpace    = if ($RawDriveData) { $UsedSpace } else { $UsedSpace | ConvertTo-KMG }
                        #PercentUsed  = [math]::round((100 - $PercentFree),2)
                        #DiskType     = 'Partition'
                        SerialNumber = $drive.SerialNumber
                   }
                    $DriveObjs += (New-Object psobject -Property $diskprops | Select $DiskElements)
            }#for
        }#for
    }#for

    Return $DriveObjs