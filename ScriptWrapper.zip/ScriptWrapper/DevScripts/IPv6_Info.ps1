﻿<#
.SYNOPSIS  
    Collect info on IPv6 enabled Network cards
.ROLE
    Network
.FUNCTIONALITY
    IP,IPv6,NetworkAdapter,nic,dhcp,dns,wins,domain,ip,mac,subnet,gateway,windowsize,Text
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    text
#> 

#"IPv6:"
#$ipv6 = (gwmi Win32_NetworkAdapterConfiguration | Where {$_.IPEnabled -eq $True -and  $_.ipaddress -match ":"}) 
$ipv6 = (gwmi Win32_NetworkAdapterConfiguration | Where {$_.ipaddress -match ":"})
if ($ipv6) {
    "IPv6: Enabled"
    ###########################################
    # Collect NIC info on the IPv6 enabled NICs
    Get-CimInstance -Class Win32_NetworkAdapterConfiguration | Where {$_.ipaddress -match ":"} | `
        select * #Description,IPAddress,MACAddress
        # all Mac Addresses in this collection are unique...no duplicates
} 
else {"IPv6: Disabled"}