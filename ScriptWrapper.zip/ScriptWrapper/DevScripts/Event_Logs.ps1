﻿<#
.SYNOPSIS  
    (Input tab) EventLogs - choose from days or date range - choose logs system/application/security or custom log
.ROLE
    Logs
.FUNCTIONALITY
    evt,logs,eventlogs,system,application,security,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$EvtLogsMaster = New-UIObject # generic object to allow properties and updating anywhere in the script
$EvtLogsMaster.ScriptName          = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$EvtLogsMaster.WorkingDirectory    = $UIMaster.WorkingDirectory
$EvtLogsMaster.CheckboxApplication = $true    # create a property. Set startging value
$EvtLogsMaster.CheckboxSystem      = $true    # create a property. Set startging value
$EvtLogsMaster.CheckboxSecurity    = $false   # create a property. Set startging value
$EvtLogsMaster.CheckboxEmptyLogs   = $true    # create a property. Set startging value
$EvtLogsMaster.RadioDays1          = $true    # create a property. Set startging value
$EvtLogsMaster.RadioRange1         = $false   # create a property. Set startging value
$EvtLogsMaster.TextboxDays1        = "1"      # create a property. Set startging value
$EvtLogsMaster.Textboxafter1       = (Get-Date).AddDays(-($EvtLogsMaster.TextboxDays1))
$EvtLogsMaster.Textboxbefore1      = Get-Date # create a property. Set startging value
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$EvtLogsMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$EvtLogsMaster.Scripts = @{}
$EvtLogsMaster.Scripts.Run         = {
    # collect the log names selected
    $Logs = $null
    if($EvtLogsMaster.CheckboxApplication){[string[]]$Logs += 'Application'}
    if($EvtLogsMaster.CheckboxSystem)     {[string[]]$Logs += 'System'}
    if($EvtLogsMaster.CheckboxSecurity)   {[string[]]$Logs += 'Security'}

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -InputObject @{
        # The names must be identical to allow the Import-Clixml to work correctly ()
        CheckboxApplication = $EvtLogsMaster.CheckboxApplication
        CheckboxSystem      = $EvtLogsMaster.CheckboxSystem
        CheckboxSecurity    = $EvtLogsMaster.CheckboxSecurity
        RadioDays1          = $EvtLogsMaster.RadioDays1     #Radio
        TextboxDays1        = $EvtLogsMaster.TextboxDays1   #Integer
        RadioRange1         = $EvtLogsMaster.RadioRange1    #Radio
        Textboxafter1       = $EvtLogsMaster.Textboxafter1  #Date
        Textboxbefore1      = $EvtLogsMaster.Textboxbefore1 #Date
    } #Export-Clixml

    # Build the $ArgumentList
    $RadioDays  = $EvtLogsMaster.RadioDays1 # True/False
    if($RadioDays){
        $Days = [string]$EvtLogsMaster.TextboxDays1    # get the textbox contents
        if($Days -eq '*'){
            $After  = $null
            $Before = $null
        } #if
        else {
            [DateTime]$After  = (Get-Date).AddDays(-$Days) 
            [DateTime]$Before = Get-Date
        } #else
    } #if
    else{
        $before = [DateTime]$EvtLogsMaster.Textboxbefore1 # get the textbox contents
        $after  = [DateTime]$EvtLogsMaster.Textboxafter1  # get the textbox contents
    } #else
    $ArgumentList = $Logs,$Before,$After # send these to $script{ Param()
    $SubScriptMessage = "$(($EvtLogsMaster.ScriptName) -replace ".ps1") - Get" # create console subscript message

    $script = {
        Param([string[]]$Logs,$Before,$After)
        
        if($After){
            foreach($logName in $Logs){  
                [array]$evtlogs += Get-EventLog -LogName $LogName -After $After -Before $Before | `
                select MachineName,@{Name='LogName';Expression={$LogName}},`
                @{Name='EntryType';Expression={$_.EntryType.ToString() }},`
                TimeGenerated,Source,EventID,Message
            } #foreach
        } #if
        else{
            foreach($logName in $Logs){  
                [array]$evtlogs += Get-EventLog -LogName $LogName | `
                select MachineName,@{Name='LogName';Expression={$LogName}},`
                @{Name='EntryType';Expression={$_.EntryType.ToString() }},`
                TimeGenerated,Source,EventID,Message
            } #foreach
        } #else

        $evtlogs | sort TimeGenerated -Descending

    } #script

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .Run
$EvtLogsMaster.Scripts.clsTextbox  = {
    $EvtLogsMaster.TextboxResults = ""
}.GetNewClosure() # .clsTextbox
#endregion
#------------------------------------------------------
#region - UI Data Loading
try { # Read in the script settings file and populate the GUI from last saved data.
    $SettingsClixml = Import-Clixml "$($EvtLogsMaster.WorkingDirectory)\$($EvtLogsMaster.ScriptName).xml" -ErrorAction Stop
    $list1 = 'CheckboxApplication','CheckboxSystem','CheckboxSecurity','RadioDays1','TextboxDays1','RadioRange1' ,'Textboxafter1','Textboxbefore1'
    foreach ($setting in $list1) {
        if ($SettingsClixml.Contains($setting)) { $EvtLogsMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
} #try
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $EvtLogsMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UIStackPanel -Orientation Vertical {
                New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
                New-UITextBlock "Collect Eventlogs, on the server(s) from the Main tab." `
                    -Margin 20,6,0,0 -FontWeight Bold -AlsoSet @{FontSize=14}
                New-UITextBlock "...You might see a Scripts UI 'not responding' while data is being sent to output...Please be patient." -Margin 20,6,0,0
                # Standard Logs Section
                New-UITextBlock ("*" * 94) -Margin 20,4,0,0 -FontWeight Bold
                # Checkbox
                New-UIStackPanel -Orientation Horizontal {
                    New-UITextBlock "Choose:" -Margin 20,4,0,0
                    New-UICheckbox "Application" -Margin 30,4,0,0 -BindIsCheckedTo CheckboxApplication
                    New-UICheckbox "System"      -Margin 20,4,0,0 -BindIsCheckedTo CheckboxSystem
                    New-UICheckbox "Security"    -Margin 20,4,0,0 -BindIsCheckedTo CheckboxSecurity
                } #StackPanel
                New-UIStackPanel -Orientation Horizontal {
                    # Days
                    New-UIStackPanel -Orientation Vertical {
                        New-UIRadioButton "Days:" -Margin 20,10,0,0 -BindIsCheckedTo RadioDays1 -Foreground Black
                        New-UIRadioButton "Range:" -Margin 20,4,4,0 -BindIsCheckedTo RadioRange1 -Foreground Black
                    } #StackPanel
                    # Range
                    New-UIStackPanel -Orientation Vertical {
                        New-UIStackPanel -Orientation Horizontal {
                            New-UITextBlock "Enter the number of days:" -Margin 14,10,0,0 -Foreground Black
                            New-UITextBox -Width 30 -Height 20 -Align CenterLeft -Margin 12,10,0,0 -BindTextTo TextboxDays1 -Foreground Green
                            New-UITextBlock "* for all" -Margin 14,10,0,0 -Foreground Black
                        } #StackPanel
                        New-UIStackPanel -Orientation Horizontal {   
                            New-UITextBlock "Enter the starting Date:" -Margin 14,4,0,0 -Foreground Black
                            New-UITextBox -Width 150 -Height 20 -Align CenterLeft -Margin 28,4,0,0 -BindTextTo Textboxafter1 -Foreground Green
                        } #StackPanel
                        # Ending Date
                        New-UIStackPanel -Orientation Horizontal {
                            New-UITextBlock "Enter the ending Date:" -Margin 14,4,0,0 -Foreground Black
                            New-UITextBox -Width 150 -Height 20 -Align CenterLeft -Margin 30,4,0,0 -BindTextTo Textboxbefore1 -Foreground Green
                        } #StackPanel
                    } #StackPanel
                } #StackPanel
                # Run Button
                New-UIStackPanel -Orientation Horizontal -Margin 20,4,0,0 {
                    New-UIButton "Run" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $EvtLogsMaster.Scripts.Run
                    New-UITextBlock "Collect (standard) EventLogs" -Margin 20,4,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 14,10,0,0 -FontWeight Bold
            } #StackPanel
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 