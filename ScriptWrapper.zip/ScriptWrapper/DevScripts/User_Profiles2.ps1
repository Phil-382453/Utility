﻿<#
.SYNOPSIS 
    Get User Profile Info - UserName, Last Modified, Size
.ROLE
    Users
.FUNCTIONALITY
    Profiles,username,account,space,access,User_Profiles_1,space,disk,drive,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$dir = dir "$($env:systemdrive)\users" # this will return ALL profile folders.
foreach($Userx in $dir){
    # get the last write time for this profile based on Ntuser.dat lastwritetime
    $LastModified = (Get-Item -force "$($env:systemdrive)\users\$($Userx.Name)\*ntuser.dat").lastwritetime
            
    # get the user (profile folder) size - this recurse takes a while to complete.
    $size1=(dir $Userx.FullName -recurse -force -ea silentlycontinue | Measure-Object 'length' -sum -Maximum).sum
            
    # convert to GB and set decimal places to 3
    $size = "$(($size1/1GB).tostring("#.###"))"
    if($size -eq ""){$size = ".000 GB"} else {$size = "$($size) GB"}
            
    # record final output
    $obj = New-Object PSObject
    $obj | Add-Member -MemberType NoteProperty -Name "HostName"      -Value "$($env:computername)"
    $obj | Add-Member -MemberType NoteProperty -Name "UserName"      -Value $Userx.Name
    $obj | Add-Member -MemberType NoteProperty -Name "Size"          -Value $size
    $obj | Add-Member -MemberType NoteProperty -Name "Last Modified" -Value $LastModified
    $obj
} #foreach