﻿<#
.SYNOPSIS  
    Collect remote access card...AD Groups info...for a list of servers (table/csv output)
.ROLE
    OOB
.FUNCTIONALITY
    OOB,AD,Active,Manufacturer,HP,Dell,ilo,drac,remote,access,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$Win32_CompSys = (gwmi Win32_ComputerSystem)

if ($Win32_CompSys.Manufacturer -match "(HP|Hewlett Packard)"){
    # find hponcfg.exe | select the 1st match
    $hponcfgPath =  "c:\progra~1\HP\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~1\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~2\hponcfg\hponcfg.exe",
                    "c:\windows\tools\hponcfg.exe",
                    "c:\temp\hponcfg.exe" | 
                    Where-Object { Test-Path $_ } | Select-Object -First 1
    if (!$hponcfgPath) { # "HPONCFG NOT FOUND" 
        $retobj                      = [ordered]@{}
        $retobj.HostName         = $env:COMPUTERNAME
        $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
        $retobj.Output               = "hponcfg.exe Not Found"
        $retobj.ADRoleGroupIndex     = ""
        $retobj.ADRoleGroupName      = ""
        $retobj.ADRoleGroupDomain    = ""
        $retobj.ADRoleGroupPrivilege = ""
        [Array]$Returns+=([pscustomobject]$retobj)
    } #if
    else {
        $nada = & $hponcfgPath /w "c:\temp\ILO.txt" # dump ilo config to text
        $file = Get-Content "c:\temp\ILO.txt" # read the file back in
        if(!$file){ # "HPONCFG NO OUTPUT" 
            $retobj                      = [ordered]@{}
            $retobj.HostName         = $env:COMPUTERNAME
            $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
            $retobj.Output               = "c:\temp\ILO.txt Not Found"
            $retobj.ADRoleGroupIndex     = ""
            $retobj.ADRoleGroupName      = ""
            $retobj.ADRoleGroupDomain    = ""
            $retobj.ADRoleGroupPrivilege = ""
            [Array]$Returns+=([pscustomobject]$retobj)
        } #if
        else{
            for ($i=0; ($i -lt ($file.Length)); $i++) {
                if ($file[$i] -like "*DIR_USER_CONTEXT_*"){ # <DIR_USER_CONTEXT_1 VALUE = "CN=PRV_DSE_SA_SRV_OOB_REPORTING,OU=LocalServerAdmins,OU=Groups,OU=PRV,OU=ENT,DC=ent,DC=wfb,DC=bank,DC=corp"/>
                    $foundit = $true #......................................found the section requested
                    # parse the line for GroupName,Domain
                    $ADRoleGroupIndex   = ((($file[$i]) -split "VALUE")[0]).Trim().TrimStart("<") # DIR_USER_CONTEXT_1
                    $DIR_USER_CONTEXT   = (((($file[$i]) -split "VALUE")[1]) -split "`"")[1] # CN=PRV_DSE_SA_SRV_OOB_REPORTING,OU=LocalServerAdmins,OU=Groups,OU=PRV,OU=ENT,DC=ent,DC=wfb,DC=bank,DC=corp
                    $DIR_USER_CONTEXTa = $DIR_USER_CONTEXT -split "," # create [string[]]
                    $ADRoleGroupName    = (($DIR_USER_CONTEXTa | ?{$_ -like "*CN=*"}) -split '=')[1] # PRV_DSE_SA_SRV_OOB_REPORTING
                    $ADRoleGroupPrivilege  = "$($DIR_USER_CONTEXTa | ?{$_ -like "*OU=*"})" #.....................OU=LocalServerAdmins,OU=Groups,OU=PRV,OU=ENT
                    $ADRoleGroupDomain  = (("$($DIR_USER_CONTEXTa | ?{$_ -like "*DC=*"})" -replace ",DC=",".") -replace "DC=","") # DC=ent,DC=wfb,DC=bank,DC=corp
                    
                    $retobj = [ordered]@{}
                    $retobj.HostName         = "$($env:COMPUTERNAME)"
                    $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
                    $retobj.ADRoleGroupIndex     = $ADRoleGroupIndex
                    $retobj.ADRoleGroupName      = $ADRoleGroupName
                    $retobj.ADRoleGroupDomain    = $ADRoleGroupDomain
                    $retobj.ADRoleGroupPrivilege = $ADRoleGroupPrivilege
                    # dont keep empty items
                    if($ADRoleGroupName){ [Array]$Returns += ([pscustomobject]$retobj) } #if 
                } #if
            } #for


        } #else
    } #else
    [pscustomobject]$Returns += $Return
} #if
elseif ($Win32_CompSys.Manufacturer -match "Dell") {
    <##############################################################################################
    # list of all items available with racadm getconfig...this script uses only "cfgStandardSchema"
    # ---------------------------------------------------------------------------------------------
    # "Collect ALL","idRacInfo","cfgRemoteHosts","cfgUserAdmin","cfgEmailAlert",
    # "cfgSessionManagement","cfgSerial","cfgOobSnmp","cfgRacTuning","ifcRacManagedNodeOs",
    # "cfgRacSecurity","cfgRacVirtual","cfgActiveDirectory","cfgLDAP","cfgLdapRoleGroup","cfgLogging",
    # "cfgIpmiSerial","cfgIpmiSol","cfgIpmiLan","cfgIpmiPef","cfgServerPower","cfgServerPowerSupply",
    # "cfgUserDomain","cfgSmartCard","cfgServerInfo","cfgLanNetworking","cfgStaticLanNetworking",
    # "cfgNetTuning","cfgIPv6LanNetworking","cfgIPv6StaticLanNetworking","cfgIPv6URL"
    #>

    $choice = "cfgStandardSchema" # racadm getconfig -select cfgStandardSchema

    if(test-path "c:\temp\Drac.txt"){ Remove-Item "c:\temp\Drac.txt" -EA SilentlyContinue } #...delete old file if found
    $reportText = racadm getconfig -f "c:\temp\Drac.txt" > $null #.......write output to file and suppress echo
    if(test-path "c:\temp\Drac.txt"){ 
        $file = get-content ("c:\temp\Drac.txt")
        if($choice -like "*Collect ALL*"){ 
            $foundit = $true #..............................................found the section requested
            $Returns = $file #.....................................collect return data = entire file
        } #if
        else {
            for ($i=0; ($i -lt ($file.Length)); $i++) {
                if ($file[$i] -like "*$($choice)*"){ #......................found the section requested
                    $foundit = $true #......................................found the section requested
                    $retobj = [ordered]@{}
                    $retobj.HostName = "$($env:COMPUTERNAME)"
                    $retobj.Manufacturer = $Win32_CompSys.Manufacturer
                    while (!(($file[$i+1]) -like "``[*")) { #..............while next line not like "["
                        switch -wildcard ($file[$i+1]){
                            "*ADRoleGroupIndex*"     { 
                                $retobj.ADRoleGroupIndex = ((($file[$i+1]) -split "=")[1])
                                Break
                            }
                            "*ADRoleGroupName*"      {
                                $ADRoleGroupName = ((($file[$i+1]) -split "=")[1])
                                $retobj.ADRoleGroupName = $ADRoleGroupName
                                Break
                            }
                            "*ADRoleGroupDomain*"    {
                                $retobj.ADRoleGroupDomain = ((($file[$i+1]) -split "=")[1])
                                Break
                            }
                            "*ADRoleGroupPrivilege*" {
                                $retobj.ADRoleGroupPrivilege = ((($file[$i+1]) -split "=")[1])
                                # dont keep empty items
                                if($ADRoleGroupName){ [Array]$Returns += ([pscustomobject]$retobj) } #if 
                                $ADRoleGroupName = $null
                                Break
                            }
                            Default {}
                        }
                        $i++ #...............................................increment the line counter
                    } #while
                } #if
            } #for
        } #else
        if (!($foundit)){
            $retobj                      = [ordered]@{}
            $retobj.HostName         = $env:COMPUTERNAME
            $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
            $retobj.Output               = "$($choice) not found in output"
            $retobj.ADRoleGroupIndex     = ""
            $retobj.ADRoleGroupName      = ""
            $retobj.ADRoleGroupDomain    = ""
            $retobj.ADRoleGroupPrivilege = ""
            [Array]$Returns =([pscustomobject]$retobj)
        } #..........if choice not found
    } # if
    else {
            $retobj                      = [ordered]@{}
            $retobj.HostName         = $env:COMPUTERNAME
            $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
            $retobj.Output               = "Output File Not Found"
            $retobj.ADRoleGroupIndex     = ""
            $retobj.ADRoleGroupName      = ""
            $retobj.ADRoleGroupDomain    = ""
            $retobj.ADRoleGroupPrivilege = ""
            [Array]$Returns+=([pscustomobject]$retobj)
    } #if
} #elseif
elseif ($Win32_CompSys.Manufacturer -match "VMware"){
    $retobj                      = [ordered]@{}
    $retobj.HostName         = $env:COMPUTERNAME
    $retobj.Manufacturer         = $Win32_CompSys.Manufacturer
    $retobj.Output               = "N/A for VMware"
    $retobj.ADRoleGroupIndex     = ""
    $retobj.ADRoleGroupName      = ""
    $retobj.ADRoleGroupDomain    = ""
    $retobj.ADRoleGroupPrivilege = ""
    [Array]$Returns = $retobj
} #elseif

# return the output
return $Returns