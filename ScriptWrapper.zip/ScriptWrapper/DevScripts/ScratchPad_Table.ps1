﻿<#
.SYNOPSIS  
    (Input tab) Table Output - This will allow entering custom commands into a textbox, to execute on the server(s) from the Main tab.
.ROLE
    Utility
.FUNCTIONALITY
    Scratchpad,custom,scriptblock,cmd,command,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$ScratchpadtblMaster = New-UIObject
$ScratchpadtblMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$ScratchpadtblMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$ScratchpadtblMaster.Textbox = "ipconfig"

$ScratchpadtblMaster.Scripts = @{}
$ScratchpadtblMaster.Scripts.Run = {

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($ScratchpadtxtMaster.WorkingDirectory)\$($ScratchpadtblMaster.ScriptName).xml" -InputObject @{
        Textbox = $ScratchpadtblMaster.Textbox
    } #Export-Clixml

    $SubScriptMessage = "$(($ScratchpadtblMaster.ScriptName) -replace ".ps1")" # create console subscript message
    $remoteCommand = $ScratchpadtblMaster.Textbox # get the textbox contents
    $scriptBlock1 = [Scriptblock]::Create($remoteCommand) # convert the text to scriptblock
    #$scriptBlock = Convert-ScriptOutputToText $scriptBlock1 # convert output to text
    $script = $scriptBlock1 # Output will be table

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .Run1

# Read in the script settings file and populate the textbox.
try {
    $SettingsClixml = Import-Clixml "$($ScratchpadtxtMaster.WorkingDirectory)\$($ScratchpadtblMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'Textbox'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $ScratchpadtblMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

#endregion
#------------------------------------------------------
#region - UI Data Loading
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $ScratchpadtblMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 14,10,0,0 -FontWeight Bold
            New-UITextBlock "Scratch Pad:" -FontWeight Bold -Margin 14,10,0,0
            New-UITextBlock "This will run the commands, listed in the textbox below, on the server(s) from the Main tab." -Margin 20,20,0,0
            New-UIStackPanel -Orientation Horizontal {
                New-UITextBox -Width 1000 -Height 400 -Margin 20,30,0,0 -AcceptsReturn $true `
                    -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible `
                    -BindTextTo Textbox
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal -Margin 20,30,0,0 {
                New-UIButton "Run" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                    -AddClick $ScratchpadtblMaster.Scripts.Run
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 