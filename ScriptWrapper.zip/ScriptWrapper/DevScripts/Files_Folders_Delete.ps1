﻿<#
.SYNOPSIS
    (Input tab) Verify files or folders, Optional - Delete files or folders.
.ROLE
    Utility
.FUNCTIONALITY
        files,filePath,folders,folderpath,dir,unc,delete,remove,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
######################
# initialize $DirFolder
$DirFolder = New-UIObject 
$DirFolder.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$DirFolder.WorkingDirectory = $UIMaster.WorkingDirectory
$DirFolder.VerifyFolderContents = "c:\temp"
$DirFolder.DeleteFileNames = "c:\temp\deleteme.txt"
#endregion>
#------------------------------------------------------
#region - UI Action Scripts ... Launch different script types: standalone,input-required,simple scriptblock, output tab and buttons.
$DirFolder.Scripts = @{} # Initialize
$DirFolder.Scripts.RunListFolderContents = {

    # Validate input
    if ($UIMaster.ServerText                  -eq ""){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($DirFolder.VerifyFolderContents -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return}

    $SubScriptMessage = "$(($DirFolder.ScriptName) -replace ".ps1") - Get info (dir)"

    Write-Verbose "$($DirFolder.WorkingDirectory)\$($DirFolder.ScriptName).xml"
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($DirFolder.WorkingDirectory)\$($DirFolder.ScriptName).xml" -InputObject @{
        VerifyFolderContents = $DirFolder.VerifyFolderContents
           DeleteFileNames      = $DirFolder.DeleteFileNames
    } #Export-Clixml
    # Collect variables to send to the Scriptblock as Arguments
    $ArgumentList = $DirFolder.VerifyFolderContents

    #######################################
    # Launch this script section
    $script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            $VerifyFolderContents
        )
        Begin{
            "HostName = $($env:computername)"
            ""
        }
        Process{ 
            $temp = $VerifyFolderContents -split "`r`n" | ForEach Trim | Where { $_ }  # trim & remove empty rows
            Foreach($folder in $temp){ 
                $folder = $folder.Trim()
                dir $folder
            }
        }
        End{}
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$DirFolder.Scripts.RunDelete = {
    $messagex = "Deleting items ... Continue?"
    $ShowUIMsgBox = Show-UIMessageBox -Message $messagex -Caption 'WARNING'  -button YesNo
    if($ShowUIMsgBox -eq 'No'){return} # if YES...continue
    # Validate input
    if ($UIMaster.ServerText             -eq ""){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($DirFolder.DeleteFileNames -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return} 
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($DirFolder.WorkingDirectory)\$($DirFolder.ScriptName).xml" -InputObject @{
        VerifyFolderContents = $DirFolder.VerifyFolderContents
           DeleteFileNames      = $DirFolder.DeleteFileNames
    } #Export-Clixml
    
    $SubScriptMessage = "$(($DirFolder.ScriptName) -replace ".ps1") - Delete File/Folder on server(s)"
    
    Write-Verbose "$($DirFolder.WorkingDirectory)\$($DirFolder.ScriptName).xml"
    # Collect variables to send to the Scriptblock as Arguments
    $DeleteFileNames = $DirFolder.DeleteFileNames 
    $ArgumentList = $DeleteFileNames
    Write-Verbose ""
    Write-Verbose $ArgumentList

    ###########################################
    ### Execute File Delete on remote server(s)
    ###########################################
    # Launch this script section
    $script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string[]]$DeleteFileNames
        )
        Begin{
            "HostName = $($env:computername)"
            ""
        }
        Process{
            $DFiles = $DeleteFileNames.Split("`n").Trim() | Where {$_.trim() -ne ""} # trim & remove empty rows
            foreach ($item in $DFiles){ 
                Write-Verbose "1";Write-Verbose "$($item)";Write-Verbose "2"

                if(Test-Path "$($item)"){ 
                    remove-item "$($item)" -force -recurse -ErrorAction SilentlyContinue
                    if(Test-Path "$item"){"Delete Fail - $($item)"}
                    else {"Delete Success - $($item)"}
                }
                else {"Not found - $($item)"}
            } #for        
        }
        End{}
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
##############################################################################
# Close the tab
$DirFolder.Scripts.Cancel = {
    $tabItem = Find-UIParent -Type TabItem
    $tabItem.Parent.Items.Remove($tabItem)
}.GetNewClosure() # close script tabs
#endregion>
#------------------------------------------------------
#region - UI Data Loading ... list of scripts, Synopsis, Functionality, ScriptText, Outputs, IsFavorite, Color
Write-Host "Loading Cache.....please wait"

# Get Server List from cache file if it exists.
# $DirFolder.ServerText = (Get-Content -Path "$($DirFolder.ServerListFilePath)" -ErrorAction Ignore) -join "`r`n"

# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($DirFolder.WorkingDirectory)\$($DirFolder.ScriptName).xml" -ErrorAction Stop
    $list = 'VerifyFolderContents','DeleteFileNames'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $DirFolder.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

Write-Host "Complete" 
Write-Host "===============================" -f Green
Write-Host ""

#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -DataContext $DirFolder -RowDefinition *,auto -ColDefinition * {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIGrid -RowDefinition auto,auto,auto -ColDefinition * {
            $PSDefaultParameterValues["New-UIGrid:ShowGridLines"] = $false

            # GridRow 1  - Verify, Unzip, Delete
            New-UIStackPanel -GridRow 0 -Orientation Vertical -Margin 25,5,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,10,0,0 -Foreground Blue -FontWeight Bold 

                # Verify Folder Contents
                New-UIStackPanel -Orientation Vertical -Margin 0,5,0,10 {
                    New-UITextBlock "Verify Files and Folder Contents (WildCards allowed):" -Margin 0,0,10,10 -Foreground Blue -AlsoSet @{FontSize=18} -FontWeight Bold
                    New-UITextBlock "Enter a folder path to see folder contents`tExample: c:\temp" -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "Enter a file path to confirm if file(s) present`tExample: c:\windows\a*" -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "You can enter multiple items (one per line)" -Margin 0,0,0,6 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo VerifyFolderContents
                    New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 { # needed for proper indent
                        New-UIButton "Verify" -Padding 10,6,10,6 -Align TopLeft -AddClick $DirFolder.Scripts.RunListFolderContents -Foreground Red
                        New-UITextBlock "Initiate the verify" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} 
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 123) -Margin 0,20,0,0 -Foreground Blue -FontWeight Bold
                New-UITextBlock "Double check for correct path and typo's before deleting." -Margin 0,0,0,0 -Foreground Green -AlsoSet @{FontSize=18} -FontWeight Bold
                New-UITextBlock "There is no Undelete option once its gone." -Margin 0,0,0,0 -Foreground Green -AlsoSet @{FontSize=18} -FontWeight Bold
                New-UITextBlock ("*" * 123) -Margin 0,0,0,0 -Foreground Blue -FontWeight Bold
                # Delete
                New-UIStackPanel -Orientation Vertical -Margin 0,5,0,0 { # needed for indent
                    New-UITextBlock "Delete:" -Margin 0,0,0,0 -Foreground Blue -AlsoSet @{FontSize=18} -FontWeight Bold
                    New-UITextBlock "This will delete file(s) and/or folder(s) on the server(s)" -Margin 0,10,0,0 -Foreground Red -AlsoSet @{FontSize=14}
                    New-UITextBlock "Enter the local path and filename to delete. Multiple files allowed...full path for each." -Margin 0,0,0,0 -Foreground Red -AlsoSet @{FontSize=14}
                    New-UITextBlock "Example:`t`tc:\temp\folder1" -Margin 0,0,0,0 -Foreground Red -AlsoSet @{FontSize=14}
                    New-UITextBlock "`t`td:\folder1\file1.txt" -Margin 0,0,0,10 -Foreground Red -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo DeleteFileNames
                    New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 {
                        New-UIButton "Delete" -Padding 10,6,10,6 -Align TopLeft -AddClick $DirFolder.Scripts.RunDelete -Foreground Red
                        New-UITextBlock "Initiate the delete" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} 
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 1,15,0,40 -Foreground Blue -FontWeight Bold
            } #stackpanel
        } #New-UIGrid
    } #New-UIScrollViewer
    
    # Grid Row 2 
    New-UIStackPanel -GridRow 2 -Orientation Horizontal -Margin 0,5,0,0 {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return}
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #New-UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 