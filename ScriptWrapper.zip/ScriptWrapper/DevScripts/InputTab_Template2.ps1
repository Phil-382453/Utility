<#
.SYNOPSIS
    (InputTab) one line description of what this script does...
.ROLE
    Utility
.FUNCTIONALITY
    Template,Test,InputTab,NewScript,Phil
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    InputTab Local
#>

<#
hit ctrl+m - this will toggle all the collapsable areas below.

#------------------------------------------------------------------
You should be familiar with both my Text and Table Template scripts

When i write InputTab scripts, I always have these 4 #region
  - Initial, Action, Data loading, Show Window

Q - Where is our scriptblock ... the code that will be sent to your server list (or run locally)
A - its inside the action sections.

My last section is the "show window" its the code that draws the gui window.
This section has text, buttons, checkboxes, textboxes, etc.
I map a button click ... to one of the action items (in the Action #region)
When you click the button ... the Action code runs
You can see the easily but searching my input tab script for ... AddClick
  - Example: New-UIButton "Ping" -Margin 6,0,0,0 -Padding 4,2,4,4 -Align BottomLeft -AlsoSet @{FontSize=14} -AddClick $UIMaster.Scripts.Ping
Now search up for "$UIMaster.Scripts.Ping" 
  - You will find this in the Action #region along with the code that runs.
The code that runs does several tasks ... the last task sends your scriptblock to the Script_UI.ps1 - #region 6
  - #region 6 - Action - Main Engine - Called from the region above ... or from one of several buttons, on an InputTab. 

In Summary: just like you call the (matching) action section on your InputTab script ... from a button click
            This action section (last task) is to call the Scripts_UI.ps1 (#region 6 - Action - Main Engine) and pass the Scriptblock for further processing.
#------------------------------------------------------------------------------------------------------------
#>

#--------------------------------------------
#region 1 - Initial Settings
$Masterx = New-UIObject
$Masterx.ScriptName          = (($MyInvocation.MyCommand.Name).Split('.'))[0] # This ScriptName
$Masterx.WorkingDirectory    = $UIMaster.WorkingDirectory 
$Masterx.SelectedCacheFolder = $UIMaster.SelectedCacheFolder
$Masterx.ServerText          = "$($Masterx.WorkingDirectory)\Servers.txt"
$Masterx.Textbox1 = $null
$Masterx.Textbox2 = $null

#endregion 1
#--------------------------------------------
#region 2 - Action 
$Masterx.Scripts = @{}
$Masterx.Scripts.Runtextbox = {
# This works and is simple because we are not trying to send data to an output tab... just echo to console.
# Send local data to output tab - prefered method:
#   Use the items 1 thru 6 (and set item 2. $UIMaster.ConnectionType = "local"
#         $UIMaster.ConnectionType = "local"
#         $SubScriptMessage = "...helps logging identify the action taken"
#         $Script = {...your local code...}
#         & $UIMaster.Scripts.RunScriptBlock $Script...

#1. Export settings for the next time the UI is loadid (to pre populate the textboxes).
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($Masterx.WorkingDirectory)\$($Masterx.SelectedCacheFolder)\$($Masterx.ScriptName).xml" -InputObject @{
        Textbox1        = $Masterx.Textbox1
    } #Export-Clixml

#2. Enable a ConnectionType - we are not using $Script = {}
#3. Create the Console Message for this action buttonk - we are not using $Script = {}
#4. $ArgumentList - we are not using $Script = {}
#5. $Script - this is what gets run on the remote server (if AsJob) ... or locally

    # This is running local so we dont need to use $Script={}
    $Masterx.Textbox1 | out-string | out-host # echo to Console

#6. Call the UIMaster.Scripts.RunScriptBlock - we are not using $Script = {}
}.GetNewClosure() #.Run1
$Masterx.Scripts.RunServices = {

#1. Export settings for the next time the UI is loadid (to pre populate the textboxes).
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($Masterx.WorkingDirectory)\$($Masterx.SelectedCacheFolder)\$($Masterx.ScriptName).xml" -InputObject @{
        Textbox1        = $Masterx.Textbox1
    } #Export-Clixml

#2. Enable a ConnectionType
    $UIMaster.ConnectionType = "AsJob"

#3. Create the Console Message for this action button
    $SubScriptMessage = ""

#4. $ArgumentList - Only needed if you pass variables inside the scriptblock .. $Script = {}
    $ArgumentList = $Masterx.Textbox1,$Masterx.Textbox2,$Masterx.5

#5. $Script - this is what gets run on the remote server (if AsJob) ... or locally
    $Script = { #Convert-ScriptOutputToText #This is required for Text output - it goes before the curly brace '{'
        Param([string[]]$Textbox1,[array]$Textbox2,[string]$Some5)

        Get-Service | Select -First 10 | Select *
    } #Script

#6. Call the UIMaster.Scripts.RunScriptBlock (Scripts_UI #region 6 - Action - Main Engine)
    & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #.Run1
$Masterx.Scripts.Something2 = {}.GetNewClosure()
$Masterx.Scripts.aFewmore2  = {}.GetNewClosure()
#endregion 2
#--------------------------------------------
#region 3 - Data Loading
#  Read in the script cache file (settings file) and populate the textboxes.
try {
    $SettingsClixml = Import-Clixml "$($MasterX.WorkingDirectory)\$($MasterX.SelectedCacheFolder)\$($MasterX.ScriptName).xml" -ErrorAction Stop
    $list = 'Textbox1'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $MasterX.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }


#endregion 3
#--------------------------------------------
#region 4 - Window
New-UIGrid -RowDefinition *, auto -DataContext $Masterx {
    New-UIScrollViewer {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 14)                   -Margin  0,10,0,0 -Foreground Blue -FontWeight Bold
            New-UITextBlock "Title:"                     -Margin 20,10,0,0 -Foreground Blue -FontWeight Bold -AlsoSet @{FontSize=18}
            New-UITextBlock "comments1"                  -Margin 20,10,0,0                                   -AlsoSet @{FontSize=16}
            New-UITextBlock "Enter something in textbox" -Margin 20,10,0,0                                   -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal {
                New-UITextBox -BindTextTo Textbox1 -AcceptsReturn $true -MinWidth 225 -MinHeight 60 -Margin 20,20,0,0
                # -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible
            } #stackpanel
            New-UIStackPanel -Orientation Horizontal -Margin 20,30,0,0 {
                New-UIButton "Run" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14} -AddClick $MasterX.Scripts.Runtextbox
                New-UITextBlock "clicking this button will echo the textbox to output" -Margin 20,10,0,0
            } #stackpanel
            New-UIStackPanel -Orientation Horizontal -Margin 20,30,0,0 {
                New-UIButton "Run" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14} -AddClick $MasterX.Scripts.RunServices
                New-UITextBlock "clicking this button will run Get-Service | Select -First 10" -Margin 20,10,0,0
            } #stackpanel
        } #stackpanel
    } #scroll
    New-UIStackPanel -GridRow 1          -Margin 0,5,0,0  -Orientation Horizontal  {
        New-UIButton "Close"             -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab}
        New-UIButton "cls"               -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {cls;return}
        New-UIButton "Reset to Defaults" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.ResetToDefaults}
    } #stackpanel
} #Grid
#endregion 4
#--------------------------------------------
# PowerShell script complete

# Appendix of useful stuff
<#
#-------------------------------------------
$serverlist | foreach{$_.Trim() | where{$_}} # remove whitespace and blank lines
$serverlist |       %{$_.Trim() |     ?{$_}} # remove whitespace and blank lines

#-------------------------------------------
The following 3 data structures .. accomplish the same output

1: Add a custom property to your output
    $HostName1 = @{Name=HostNamex; Expression={$env:computername}}
    [array]$DriveObjectx = Get-WmiObject -Class Win32_DiskDrive | select $HostName1,DeviceID,Name,Model,Index,SerialNumber
    $DriveObjectx #...........echo to output

2: Select Properties as a collection ...
    $HostName1 = @{Name='HostNamex'; Expression={$env:computername}}
    $WMI_DiskProps = @($HostName1,'DeviceID','Name','Model','Index','SerialNumber')
    $WMI_DiskDrives = Get-WmiObject -Class Win32_DiskDrive | select $WMI_DiskProps | Sort Index
    $WMI_DiskDrives #......echo to output

3: PScustomObject - Create a custom object then add it to an array (My favorite .. and easy to read code)
    ForEach($thing in WMI_DiskDrives)
        $obj              = [ordered]@{}
        $obj.HostName1    = $env:computername #custom object
        $obj.DeviceID     = $thing.DeviceID
        $obj.Name         = $thing.Name    
        $obj.Model        = $thing.Model   
        $obj.Index        = $thing.Index
        $obj.SerialNumber = $thing.SerialNumber
        [array]$Objs += [PSCustomObject]$obj #add the object to your PSCustomObject collection
    } #foreach
    $Objs #...................echo to output

#-------------------------------------------
Lookup Table:
    $serviceNameToWmiHash = @{}
    Get-WmiObject -Class Win32_Service | %{ $serviceNameToWmiHash[$_.Name] = $_ } 
    $serviceNameToWmiHash        | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Keys   | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Values | Out-String | Out-Host #echo to console

#-------------------------------------------
Error Info:
    $error[0] 
    $error[0].Exception
    $error[0].InnerException
    $error[0].CategoryInfo
    $error[0].ErrorDetails
    $error[0].FullyQualifiedErrorId   #very useful .. the short version
    $error[0].InvocationInfo
    $error[0].TargetObject
    $error[0].PSMessageDetails
#>