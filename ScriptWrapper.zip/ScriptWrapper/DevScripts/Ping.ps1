<#
.SYNOPSIS
    This script provides a multi-threaded ping for very fast results.
.ROLE
    Utility
.FUNCTIONALITY
    Ping,InputTab,local
.NOTES
    Author - Philip.Bellanca@OutLook.com
.OUTPUTS
    InputTab, Local
#>

#-------------------------------------------------------------------
#region - Initialize
$allheaders1 = $null
$hostNameCol = $null
$result      = $null

$PingPlus = New-UIObject
$PingPlus.ScriptName          = ("$($UIMaster.SelectedScript.Scriptname)" -replace '.ps1').Trim() # "this" scriptname
$PingPlus.WorkingDirectory    = $UIMaster.WorkingDirectory
$PingPlus.SelectedCacheFolder = $UIMaster.SelectedCacheFolder
###############################################################
$PingPlus.SaveFile = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($PingPlus.ScriptName)"
$PingPlus.ckbPing  = $true
$PingPlus.ckbTcon  = $false
$PingPlus.ckbWMan  = $false
##############
$error.clear()
$i = 0
$j = 0

$PingPlus.Progress = New-UIObject
$PingPlus.Progress.Count     = 0
$PingPlus.Progress.Completed = 0
$PingPlus.Progress.Elapsed   = ''
$PingPlus.ThreadCount        = 10

#--------------------------------------------
$PingPlus.ServerList = @{}
$PingPlus.ServerList = $UIMaster.ServerText # Textbox defined in ScriptWrapper.ps1
#--------------------------------------------

$PingPlus.EnableUI = $true
$PingPlus.ResultList = New-UIObjectCollection

#endregion
#-------------------------------------------------------------------
#region - Action Scriptblocks
#----------------------
$PingPlus.Scripts = @{}
$PingPlus.Scripts.TestNetCon = {

#1. #Export settings for the next time the uui is loaded (to pre populate the textvoxes).
    Export-Clixml -Path "$($PingPlus.WorkingDirectory)\$($PingPlus.SelectedCacheFolder)\$($PingPlus.ScriptName).xml" -InputObject @{
        ckbPing = $PingPlus.ckbPing
        ckbTCon = $PingPlus.ckbTCon
        ckbWMan = $PingPlus.ckbWMan
    } #Export-Clixml

    ################################
    # modify the script here
    # and modify the matching column headers in ... region - UI Window
    # 
    # Note: the only variable passed into $PingPlus.Script is the Server "$($_)" ... fromf serverlist
    # I have not yet found a way to use a variable for the port
    # currently it is hardcoded to 5985
    # ...Choose from the following based on checkbox selection
    if($PingPlus.ckbPing -and $PingPlus.ckbTCon -and $PingPlus.ckbWMan){
        $PingPlus.Script = [string]{
            $Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = Test-Connection $_ -Quiet -Count 1
            $result.RemoteAddress = $Tnet.RemoteAddress
            $result.RemotePort    = $Tnet.RemotePort
            $result.TestPort      = $Tnet.TcpTestSucceeded
            $result.WsMan         = Test-WSMan $_ | select -Expand ProductVersion
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbPing -and $PingPlus.ckbTCon){
        $PingPlus.Script = [string]{
            $Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = Test-Connection $_ -Quiet -Count 1
            $result.RemoteAddress = $Tnet.RemoteAddress
            $result.RemotePort    = $Tnet.RemotePort
            $result.TestPort      = $Tnet.TcpTestSucceeded
            $result.WsMan         = ""
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbPing -and $PingPlus.ckbWMan){
        $PingPlus.Script = [string]{
            #$Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = Test-Connection $_ -Quiet -Count 1
            $result.RemoteAddress = ""
            $result.RemotePort    = ""
            $result.TestPort      = ""
            $result.WsMan         = Test-WSMan $_ | select -Expand ProductVersion
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbTCon -and $PingPlus.ckbWMan){
        $PingPlus.Script = [string]{
            $Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = ""
            $result.RemoteAddress = $Tnet.RemoteAddress
            $result.RemotePort    = $Tnet.RemotePort
            $result.TestPort      = $Tnet.TcpTestSucceeded
            $result.WsMan         = Test-WSMan $_ | select -Expand ProductVersion
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbPing){
        $PingPlus.Script = [string]{
            #$Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = Test-Connection $_ -Quiet -Count 1
            $result.RemoteAddress = ""
            $result.RemotePort    = ""
            $result.TestPort      = ""
            $result.WsMan         = ""
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbTCon){
        $PingPlus.Script = [string]{
            $Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = ""
            $result.RemoteAddress = $Tnet.RemoteAddress
            $result.RemotePort    = $Tnet.RemotePort
            $result.TestPort      = $Tnet.TcpTestSucceeded
            $result.WsMan         = ""
            [pscustomobject]$result
        } #script
    } #if
    elseif($PingPlus.ckbWMan){
        $PingPlus.Script = [string]{
            #$Tnet = Test-NetConnection -ComputerName "$($_)" -Port 5985
            $result = [ordered]@{}
            $result.Name          = "$($_)"
            $result.Ping          = ""
            $result.RemoteAddress = ""
            $result.RemotePort    = ""
            $result.TestPort      = ""
            $result.WsMan         = Test-WSMan $_ | select -Expand ProductVersion
            [pscustomobject]$result
        } #script
    } #if
    ##############################


    #------------------------------------------
    $PingPlus.ServerList = $UIMaster.ServerText # Textbox defined in scriptwrapper.ps1
    $PingPlus.EnableUI   = $false
    $PingPlus.ResultList.Clear()

    $powershell = New-UIPowerShell
    $powershell.Runspace.SessionStateProxy.SetVariable('PingPlus',$PingPlus)
    $powershell.Runspace.SessionStateProxy.SetVariable('Window',(Find-UIParent -Type Window))

    $elapsedThred = New-UIPowerShell
    $elapsedThred.Runspace.SessionStateProxy.SetVariable('PingPlus',$PingPlus)

    $elapsedThred.AddScript({
        $now = [DateTime]::Now
        while(!$PingPlus.EnableUI){
            $span = [DateTime]::Now -$now
            $PingPlus.Progress.Elapsed = $span.ToString("'Elapsed: 'm' min 's' sec'")
            Start-Sleep -Milliseconds 100
        }
    }).BeginInvoke()

    [void]$powershell.AddScript({

        trap { $PingPlus.Error = $_ ; $PingPlus.Error | out-string | out-host }

        $Script = [ScriptBlock]::Create($PingPlus.Script)

        Function Invoke-PipelineThreading{
            Param(
                [Parameter(ValueFromPipeline=$true)] [object()]$InputObject,
                [Parameter(Position=0, Mandatory=$true)] [scriptblock] $Script,
                [Parameter()] [int] $Threads = 10,
                [Parameter()] [int] $ChunkSize = 1,
                [Parameter()] [switch] $AutoChukSize,
                [Parameter()] [scriptblock] $StartupScript = { },
                [Parameter()] [string[]] $ImportVariables,
                [Parameter()] [object] $WriteCountAndCompletedTo
            )
            Begin{
                $inputOjbectList = New-Object System.Collections.Generic.List[object]
            }
            Process{
                foreach ($inputOjbectItem in $InputOjbect){ $inputOjbectList.Add($inputOjbectItem) }
            }
            End{
                $objectCount = $inputObjectList.Count
                if ($WriteCountAndCompletedTo) { $WriteCountAndCompletedTo.count = $objectCount; $WriteCountAndCompletedTo.Completed = 0 }
                if (!$objectCount) { return }
                if ($AutoChukSize) { $ChunkSize = [Math]::Ceiling( $objectCount / $Threads) }

                $finalThreadCount   = [Math]::Min([Math]::Ceiling(($objectCount / $ChunkSize), $Threads))
                
                $threadList = @(for ($i = 1; $i -le $finalThreadCount; $i++){
                    $thread = [ordered]@{}
                    $thread.Thread = $i
                    $thread.Round = 1
                    $thread.PowerShell = [PowerShell]::Create()
                    $thread.PowerShell.Runspace.SessionStateProxy.SetVariable('Thread', $i)
                    $thread.Invocation = $nul
                    $thread.HasScript = $false
                    foreach($variable in $ImportVariables){
                        $var = $PSCmdlet.SessionState.PSVariable.Get($variable)
                        $thread.PowerShell.Runspace.SessionStateProxy.SetVariable($var.Name, $var.Value)
                        <#
                        $component                   = [ordered]@{}
                        $component.Hostname          = 
                        $component.NSlookupStatus = $var.Value
                        [array]$Csv += [pscustomobject]$component  #echo to output
                        #>
                    } #for
                    if($StartupScript){$thread.Invocation = $thread.PowerShell.AddScript($StartupScript).BeginInvoke()}

                    [pscustomobject]$thread
                })
            
                $index = 0
                $completed = 0
                
                while ($completed -lt $objectCount){
                    do{
                        $readyThreads = $threadList.Where({-not $_.Invocation -or $_.Invocation.IsCompleted})
                    } while (!$readyThreads)
                    
                    foreach($thread in $readyThreads){
                        if ($thread.Invocation){
                            $result = $thread.PowerShell.EndInvoke($thread.Invocation)
                            $result
                            $thread.Invocation = $null
                            if ($thread.HasScript){
                                $completed += $ChunkSize
                                if($WriteCountAndCompletedTo){ $WriteCountAndCompletedTo.Completed = $completed }
                            } #if
                        } #if
                        if ($index -ge $objectCount){ continue }
                        if (!$thread.HasScript){ 
                            $thread.PowerShell.Commands.Clear()
                            [void]$thread.PowerShell.AddScript($Script)
                            $thread.HasScript = $true
                         } #if
                         $incrementSize = [Math]::Min($ChunkSize, $objectCount-$index)
                         Write-Verbose "Executing script in thread $($thread.Thread) for items $index-$($index + $ChunkSize - 1)"
                         $nextItems = $inputObjectList.GetRange($index, $incrementSize)
                         $index += $incrementSize
                         if ($nextItems.Count -eq 1){$thread.PowerShell.Runspace.SessionStateProxy.SetVariable('_', $nextItems[0])}
                         else{$thread.PowerShell.Runspace.SessionStateProxy.SetVariable('_', $nextItems)}
                         $thread.PowerShell.Runspace.SessionStateProxy.SetVariable('Round', $thread.Round)
                         $thread.Invocation = $thread.PowerShell.BeginInvoke()
                         $thread.Round += 1
                    } #for
                } #while
            } #End
        } #funct

        $PingPlus.ServerList -split "`r`n" | foreach Trim | where { $_ } |
            Invoke-PipelineThreading -Threads $PingPlus.ThreadCount -WriteCountAndCompletedTo $PingPlus.Progress -Script $Script |
            Foreach { [ MyStuff.SystemsEngineering.Msui.MsuiObject]::new($_) } |
            Foreach { $PingPlus.ResultList.Add($_, $Window.Dispatcher) }
        $PingPlus.EnableUI = $true
        #UIMaster.ServerList | Set-Content -Path "$($env:APPDATA)\ScriptsWrapper\Servers.txt"
    }).BeginInvoke()

}.GetNewClosure() #.Run
$PingPlus.Scripts.Reset      = {
    $PingPlus.ResultList.Clear()
}.GetNewClosure() #.Reset
$PingPlus.Scripts.ToCsv      = {
    $CsvFile = "$($PingPlus.SaveFile).csv"
    if(Test-Path $CsvFile){Remove-Item -Path $CsvFile -Force}
    $PingPlus.ResultList | Export-csv -Path $CsvFile -NoTypeInformation -Force

    Write-Verbose "PingPlus.Scripts.ToCsv"
    Write-Host ""

    $tabItem = Find-UIParent -Type TabItem
    #tabItem | gm | out-string | out-host

    $Header = $tabItem.Header
    "Header = $($tabItem.Header)" | out-string | write-Verbose

    #"Header = $($Header)" | out-string | Write-Host
    $Header = $Header -replace ("__"),"_" # underscore getting dropped? use double underscored to fix.
    $Header = $Header -replace ".ps1"

    $TabFileName = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($Header).csv"
    "TabFileName = $($TabFileName)" | out-string | Write-Verbose

    #Get the filepath to excel.exe
    $ExcelPath = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\excel.exe" | select path).path
    if(!(Test-Path "$($ExcelPath)\excel.exe")){
        Show-UIMessageBox -Message "Excel not installed. `nUnable to open $($TabFileName)"
        $Excel = $false
    } #if
    else{ & "$($ExcelPath)\excel.exe" $csvFile } 

}.GetNewClosure() #.ToCsv
#endregion
#-------------------------------------------------------------------
#region - UI Data Loading
# read in the script settings file adn populate radio buttons, textboxes, etc.
try{
    $SettingsClixml = Import-Clixml "$($PingPlus.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($PingPlus.ScriptName).xml" -ErrorAction Stop
    $list1 = 'ckbPing','ckbTCon','ckbWMan'
    foreach($setting in $list1){
        if($SettingsClixml.Contains($setting)){ $PingPlus.$setting = $SettingsClixml.$setting } # update the ping script items.
    } #for
} #try
catch{}
#endregion
#-------------------------------------------------------------------
#region - UI Window
    New-UIGrid -RowDefinition auto, auto, auto, auto, *, auto -DataContext $PingPlus {
    
        #---   CheckBoxes   ------------------------------------------------
        New-UIStackPanel -Orientation Vertical -Margin 4,4,0,4 -GridRow 0 {
            New-UIStackPanel -Orientation Vertical -Align BottomLeft {
                New-UITextBlock "This script will test connectivity to a list of servers." -alsoset @{FontSize=16} -Foreground Blue

                # Checkboxes
                New-UIGrid -RowDefinition auto,* -ColDefinition auto,2* {
                    New-UIStackPanel -GridRow 0 -GridCol 0 {
                        New-UICheckBox "" -BindIsCheckedTo ckbPing -Margin 20,4,0,0 -alsoset @{FontSize=14} -Foreground Black
                        New-UICheckBox "" -BindIsCheckedTo ckbTcon -Margin 20,0,0,0 -alsoset @{FontSize=14} -Foreground Black
                        New-UICheckBox "" -BindIsCheckedTo ckbWMan -Margin 20,0,0,0 -alsoset @{FontSize=14} -Foreground Black
                    } #StackPanel
                    New-UIStackPanel -GridRow 0 -GridCol 1 {
                        New-UITextBlock "Ping = Test-Connection" -alsoset @{FontSize=14} -Margin 10,0,0,0 -Foreground Black
                        New-UITextBlock "Test-Port = Test-NetConnection -port 5985" -alsoset @{FontSize=14} -Margin 10,0,0,0 -Foreground Black
                        New-UIStackPanel -Orientation Horizontal -Align BottomLeft {
                            New-UITextBlock "WSMan = Test-WSMan | select -Expand ProductVersion" -alsoset @{FontSize=14} -Margin 10,0,0,0 -Foreground Black
                            New-UITextBlock "...this requires FQDN in your serverlist" -alsoset @{FontSize=14} -Margin 0,0,0,0 -Foreground Red
                        } #StackPanel
                    } #StackPanel
                } #Grid
            } #StackPanel
            New-UITextBlock ("*" * 112) -margin 0,4,0,0
            #New-UITextBlock "Progress is indicated by the green bar" -alsoset @{FontSize=14} -Margin 0,10,0,0
            New-UITextBlock "Expext a 30 second delay before results start to appear" -alsoset @{FontSize=14} -Margin 0,0,0,4
        } #StackPanel

        #---   Buttons   + Threads
        New-UIStackPanel -Orientation Horizontal -Align BottomLeft -GridRow 2 {
            New-UIButton "Run"    -Padding 16,0,16,3 -Margin 4 -AddClick $PingPlus.Scripts.TestNetCon -AlsoSet @{FontSize=14} -Foreground Green
            New-UIButton "to CSV" -Padding 16,0,16,3 -Margin 4 -AddClick $PingPlus.Scripts.ToCsv      -AlsoSet @{FontSize=14}
            New-UIButton "Reset"  -Padding 16,0,16,3 -Margin 4 -AddClick $PingPlus.Scripts.Reset      -AlsoSet @{FontSize=14}
        
            New-UITextBlock "Threads: " -Margin 14,6,0,4
            New-UITextBox -Margin 0,6,4,4 -Width 20 -BindTextTo ThreadCount -Align TopLeft
            New-UISlider -width 200 -Margin 10,6,4,4 -Orientation Horizontal -Minimum 1 -Maximum 50 -Ticks 1,5,10,15,20,30,40,50 -TickPlacement BottomRight -IsSnapToTickEnable $true -Foreground Black -BindValueTo ThreadCount
        } | 
            Add-UIBinding -Property IsEnabled -Path EnableUI

        #---   Progress: + Elapsed   ---------------------------------------
        New-UIStackPanel -Orientation Horizontal -Margin 10,7,0,0 -Height 25 -GridRow 3 {
            New-UITextBlock "Progress: "                  -AlsoSet @{FontSize=14}
            New-UITextBlock -BindTextTo Progress.Complete -AlsoSet @{FontSize=14} -ForeGround Red
            New-UITextBlock " / "                         -AlsoSet @{FontSize=14}
            New-UITextBlock -BindTextTo Progress.Count    -AlsoSet @{FontSize=14} -ForeGround Red
            New-UITextBlock -Margin 10,0,0,0 -FontWeight Bold -BindTextTo $Progress.Elapsed -AlsoSet @{FontSize=14} -ForeGround Red
        } #StackPanel
        #New-UIProgressBar -Margin 4,24,0,4 -Height 20 -Align TopStretch -BindMaximumTo Progress.Count -BindValueTo Progress.Completed -GridRow 3

        #---   New-UIListView   ------------------------------------------
        New-UIGrid -GridRow 4 -ColDefinition auto, * {
            New-UIListView -BindItemsSourceTo ResultList -Columns Name, Ping, RemoteAddress, RemotePort, TestPort, WSman -Margin 4 -GridCol 1
            #New-UIListView -BindItemSourceTo ResultList -Columns Name, RemoteAddress, RemotePort, InterFaceAlias, Ping, TestPort, WSman -Margin 4 -GridCol 1
        } #UIGrid

        New-UIStackPanel -GridRow 5 -Margin 0,5,0,0 -Orientation Horizontal {
            New-UIButton "Close" -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab}
            New-UIButton "cls"   -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return}
            #New-UIButton "Reset to defaults" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.ResetToDefaults}
        } #StackPanel

    } #Grid
#endregion
#---------------------------
# PowerShell script complete