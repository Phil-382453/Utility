﻿<#
.SYNOPSIS 
    (Input tab) Get process info - InstanceName, PID, %CPU, RAM usage, CommandLine
.ROLE
    Operating System
.FUNCTIONALITY
    Process,pid,cpu,ram,Memory,KernelModeTime,ThreadCount,cmdline,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables

#endregion
#------------------------------------------------------
#region - UI Action Scripts
$PIDCmdLineMaster = New-UIObject

$PIDCmdLineMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname

$PIDCmdLineMaster.Scripts = @{}
# Process name, % CPU, Path
$PIDCmdLineMaster.Scripts.Query1 = {
    $SubScriptMessage = "$(($PIDCmdLineMaster.ScriptName) -replace ".ps1") - CPU" # create console subscript message
    $script = {
        $cpu_count = $env:NUMBER_OF_PROCESSORS -as [int]
        $Proc = Get-counter "\Process(*)\% processor time" -ErrorAction SilentlyContinue | select *
        $Proc.CounterSamples | sort -desc CookedValue | 
        Select InstanceName,@{Name="Percent_cpu";Expression={[decimal]("{0:N0}" -f( ($_.CookedValue)/$cpu_count) )}},Path
    } #$script
    & $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # Query1 Process by CPU usage

# Process, PID, RAM (MB)
$PIDCmdLineMaster.Scripts.Query2 = {
    $SubScriptMessage = "$(($PIDCmdLineMaster.ScriptName) -replace ".ps1") - RAM" # create console subscript message
    $script = {
        $proname  = @{label = "Process" ;Expression = {$_.name}}
        $pid1 =     @{label = "PID"     ;Expression = {($_.ID)}}
        $ramusage = @{label = "RAM (MB)";Expression = {[math]::round(($_.ws /1mb),2)}}
        get-process | Sort -Descending WS | select $proname,$pid1,$ramusage
    } #$script
    & $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # Query2 Process by RAM usage

# Process name, PID, CommandLine
$PIDCmdLineMaster.Scripts.Query3 = {
    $SubScriptMessage = "$(($PIDCmdLineMaster.ScriptName) -replace ".ps1") - Cmdline column" # create console subscript message
    $script = {
        $proname  = @{label = "Process" ;Expression = {$_.name}}
        $pid1 =     @{label = "PID"     ;Expression = {($_.ProcessID)}}
        Get-WmiObject Win32_Process | select $proname,$pid1,KernelModeTime,UserModeTime,ThreadCount,CommandLine
    } #$script
    & $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .Query3 Process by CmdLine
#endregion
#------------------------------------------------------
#region - UI Data Loading

#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $PIDCmdLineMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical { 
            New-UIStackPanel -Margin 20,20,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,0,0,0 -FontWeight Bold
                New-UITextBlock "Purpose:" -FontWeight Bold -Margin 0,6,4,0 -AlsoSet @{FontSize=14}
                New-UITextBlock "Collect all processes on remote server(s)." -Margin 20,6,0,0 
                New-UITextBlock "Query1 Get process info - InstanceName, % CPU, Path." -Margin 20,6,0,0 
                New-UITextBlock "Query2 Get process info - InstanceName, PID, RAM (MB)" -Margin 20,6,0,0
                New-UITextBlock "Query3 Get process info - InstanceName, PID, Cmd line used to launch the process." -Margin 20,6,0,0 
                New-UITextBlock "This will allow identifying processes with same name but different launch attributes." -Margin 20,6,0,0  -foreground "Green" 
                New-UITextBlock "Example: multiple w3wp processes, one for each application pool." -Margin 20,6,0,0 -foreground "Green"
            } #StackPanel
            New-UIStackPanel -Margin 20,20,0,0 {
                New-UITextBlock "Action:" -FontWeight Bold -Margin 0,6,0,0 -AlsoSet @{FontSize=14}
                New-UIStackPanel -Orientation Horizontal -Margin 20,20,0,0 {
                    New-UIButton "   Query % CPU   " -Padding 10,6,10,6 -AddClick $PIDCmdLineMaster.Scripts.Query1
                    New-UITextBlock "Get process info - InstanceName, % CPU, Path." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UIStackPanel -Orientation Horizontal -Margin 20,20,0,0 {
                    New-UIButton "Query RAM (MB)" -Padding 10,6,10,6 -AddClick $PIDCmdLineMaster.Scripts.Query2
                    New-UITextBlock "Get process info - InstanceName, PID, RAM (MB)." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UIStackPanel -Orientation Horizontal -Margin 20,20,0,0 {
                    New-UIButton " Query Cmd Line " -Padding 10,6,10,6 -AddClick $PIDCmdLineMaster.Scripts.Query3
                    New-UITextBlock "Get process info - InstanceName, PID, CmdLine." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,14,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer

    # Bottom row of buttons
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        #New-UIButton "Run"       -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick $PIDCmdLineMaster.Scripts.Run1 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 