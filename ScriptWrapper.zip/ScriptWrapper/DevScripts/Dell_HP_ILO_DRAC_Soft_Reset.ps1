﻿<#
.SYNOPSIS  
    This script will SOFT-Reset a Dell idrac or HP ilo...No data will be modified.
.ROLE
    OOB
.FUNCTIONALITY  
    OOB,drac,idrac,racadm,ilo,hponcfg,remote access,EACO,Dell,HP,Text
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Text
#>

""
"#############################"
"HostName = $($env:computername)"

$Manuf = (gwmi Win32_ComputerSystem).Manufacturer # get manufacturer
switch -wildcard ($Manuf) {
    "VMware*" {
                $Manuf
                break}
    "Dell*"   {
                $x = racadm racreset      #reboots the iDRAC without changing any settings
                $x
                if (($x -eq "") -or ($x -eq $null)) { 
                    "`r`nManufacturer = $((gwmi Win32_ComputerSystem).Manufacturer)"
                    "There was a problem running the command = racadm racreset" 
                } #if
                break}
    "HP*"     {
                $hponcfgPath =  "c:\progra~1\HP\hponcfg\hponcfg.exe",
                                "c:\progra~1\Hewlet~1\hponcfg\hponcfg.exe",
                                "c:\progra~1\Hewlet~2\hponcfg\hponcfg.exe",
                                "c:\windows\tools\hponcfg.exe",
                                "c:\temp\hponcfg.exe" | 
                                Where-Object { Test-Path $_ } | Select-Object -First 1
                if (!$hponcfgPath) { "HPOncfg is not found" }
                else {
                    cd $hponcfgPath
                    .\hponcfg.exe /iLO_reboot #reboots the ilo without changing any settings
                }
                break}
} #switch

<# HPONCFG cmds

HPONCFG cmds:
hponcfg /reset      ...!!!!! reset to factory defaults
hponcfg /iLO_reboot ...reboots the ilo without changing any settings

HPONCFG Example output:
#############################
HostName = WPPWA00A0276
HP Lights-Out Online Configuration Utility
Version 4.8.0.0 (c) 2016 Hewlett Packard Enterprise Development LP 
Firmware Revision = 2.62  Device type = iLO 4  Driver name = hpqilo3chif

Rebooting iLO Management Processor...This may take a few minutes
__| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __| __/ __--__\ __  
iLO 4 has been rebooted.

#############################
HostName = LUPWD00A0023
HP Lights-Out Online Configuration Utility
Version 4.3.0.0 (c) Hewlett-Packard Company, 2013 
Firmware Revision = 2.62  Device type = iLO 4  Driver name = hpqilo3chif

hponcfg [  /help  |  /?  |  /m firmwarelevel  | /reset [/m firmwarelevel]
         | /f filename [/l filename][/s namevaluepairs]
                     [/xmlverbose or /v][/m firmwarelevel]
         | /i [/l filename][/s namevaluepairs]
                     [/xmlverbose or /v][/m firmwarelevel]
         | [/a] /w filename [/m firmwarelevel]
         | /get_hostinfo [/m firmwarelevel]
         | /mouse [/dualcursor][/allusers]
         | /display [/allusers]
  ...
  ...
#>

<# Racadm example output
#############################
HostName = CUPWD01A0005
RAC reset operation initiated successfully. It may take a few
minutes for the RAC to come online again.


#############################
HostName = CUPWD02A0005


IMPORTANT NOTE!
The RAC is unable to communicate with the BMC. This condition may
occur because of (1) no BMC is present, (2) missing or disfunctional
IPMI-related software components. Many RAC features depend on BMC
connectivity in order to work properly, and you may see failures
as a result.

Manufacturer = Dell Inc.
There was a problem running the command = racadm racreset
#>