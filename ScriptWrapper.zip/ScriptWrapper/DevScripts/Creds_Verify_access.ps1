﻿<#
.SYNOPSIS  
    Verify Credentials have privileged access to Server(s)"
.ROLE
    Access
.FUNCTIONALITY
    Access,permission,user,account,username,security,Credentials_Access,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$component              = @{} # A dictionary or associative array
#$component.ComputerName = $env:COMPUTERNAME
$component.Domain       = $env:USERDNSDOMAIN
$component.Status       = "Access verified good"
[pscustomobject]$component # echo to output