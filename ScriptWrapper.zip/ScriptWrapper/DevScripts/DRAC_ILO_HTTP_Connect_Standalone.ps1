﻿<#
.SYNOPSIS  
    Direct connect to DRAC/iLo - Verify Online, Credentials, Status ... windows\unix\lynix\etc
.FUNCTIONALITY
    security,access,ilo,remote,logon,Drac_iLo_Direct_STATUS,Standalone
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Standalone
#>

$serverList  = $null
$serverList1 = $null
Function Get-InputBox {
    [CmdletBinding()]
    [OutputType([String])]
    Param(
        # Param1
        [Parameter(Mandatory=$false, Position=0)]
        [string]$Message,

        # Param2
        [Parameter(Mandatory=$false, Position=1)]
        [string]$WindowTitle,

        # Param3 The last script run will write the item list to file. 
        # This parameter accepts the filename and path so the item list can be pre-populated.
        [Parameter(Mandatory=$false, Position=2)]
        [string]$Inputfile
    )

    Begin {
        ############## Load Assembly for creating form & button
        [void][System.Reflection.Assembly]::LoadWithPartialName( “System.Windows.Forms”)
        [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
        [void][System.Reflection.Assembly]::LoadWithPartialName( “Microsoft.VisualBasic”)
        ############## Initialize form items...optional
        $handler_form_Load = { # initialize variables and controls, when the form 1st loads
            if ($Inputfile){
                if(test-path $Inputfile){ # if serverfile exists
                    $file = get-content $Inputfile # read the file and populate the txtbox
                    foreach($line in $file){ # remove blank lines and trim whitespace
                        if ($line.trim() -ne ""){$textBox.AppendText("$($line.trim())`r`n")} 
                    } #for
                } #if
            } #if
        } #$handler_form_Load
    } #Begin

    Process {
        # define the form
        # define the controls (textbox, buttons, labels, checkbox, radiobutton, etc
        # add each control to the form (Controls.Add)
        ############## Main Window - Form
        $form = New-Object System.Windows.Forms.Form
        $form.Text = $WindowTitle
        $form.Size = New-Object System.Drawing.Size(230,320)
        $form.FormBorderStyle = 'FixedSingle'
        $form.StartPosition = "CenterScreen"
        $form.Topmost = $True
        $form.add_Load($handler_form_Load) # trigger the above item ($handler_form_Load)
        $form.ShowInTaskbar = $true
        $form.Tag = "" # tag is used to return the list

        # Label
        $label = New-Object System.Windows.Forms.Label
        $label.Location = New-Object System.Drawing.Size(10,10)
        $label.Size = New-Object System.Drawing.Size(280,20)
        $label.AutoSize = $true
        $label.Text = $Message

        # TextBox
        $textBox = New-Object System.Windows.Forms.TextBox
        $textBox.Location = New-Object System.Drawing.Size(10,40)
        $textBox.Size = New-Object System.Drawing.Size(200,200)
        $textBox.AcceptsReturn = $true
        $textBox.AcceptsTab = $false
        $textBox.Multiline = $true
        $textBox.ScrollBars = 'Both'
        $textBox.WordWrap = $false
        $textBox.Text = ""

        # button
        $okButton = New-Object System.Windows.Forms.Button
        $okButton.Location = New-Object System.Drawing.Size(10,250)
        $okButton.Size = New-Object System.Drawing.Size(75,25)
        $okButton.Text = "OK"
        $okButton.Add_Click({ 
            $temp,$form.tag = "" # initialize so no unexpected values
            # split into lines, remove blanks, remove leading/'trailing whitespace
            $temp = ($textBox.Text).Split("`n").Trim() | Where {$_.trim() -ne ""}
            $form.tag = $temp # $form.tag is the only way to "return" a value
            if($form.tag -eq $null){$form.tag = ""} # needed to show empty vs cancel button
            $form.Close() # close the popup
        })

        # button
        $cancelButton = New-Object System.Windows.Forms.Button
        $cancelButton.Location = New-Object System.Drawing.Size(130,250)
        $cancelButton.Size = New-Object System.Drawing.Size(75,25)     
        $cancelButton.Text = "Cancel"
        $cancelButton.Add_Click({ $form.Tag = $null; $form.Close() })
        $form.CancelButton = $cancelButton # allow using esc key for clicking cancel button

        # Add controls to the form
        $form.Controls.Add($label)
        $form.Controls.Add($textBox)
        $form.Controls.Add($okButton)
        $form.Controls.Add($cancelButton)

        # Initialize and show the form
        $form.Add_Shown({$form.Activate()})
        [system.windows.forms.application]::run($form) | Out-Null
    } #Process

    End {     
        If ($form.tag -eq ""){ # no data entered
            Write-Host "Item list empty." -foregroundcolor "red"
        } elseif ($form.tag -eq $null) { # CANCEL button clicked
            Write-Host "Cancel button clicked." -foregroundcolor "red"
        } else { # save the data to file...used to prepopulate next script run
            $form.Tag | set-content $Inputfile # write list to file.
        } #else
        return ($form.Tag) # Return the list
    } #End
} #funct Get-InputBox

Function Invoke-PipelineThreading {
    Param
    (
        [Parameter(ValueFromPipeline=$true)] [object[]] $InputObject,
        [Parameter(Position=0, Mandatory=$true)] [scriptblock] $Script,
        [Parameter()] [int] $Threads = 10,
        [Parameter()] [int] $ChunkSize = 10,
        [Parameter()] [switch] $AutoChunkSize,
        [Parameter()] [scriptblock] $StartupScript = { },
        [Parameter()] [string[]] $ImportVariables
    )
    Begin
    {
        $inputObjectList = New-Object System.Collections.Generic.List[object]
    }
    Process
    {
        foreach ($inputObjectItem in $InputObject) { $inputObjectList.Add($inputObjectItem) }
    }
    End
    {
        $objectCount = $inputObjectList.Count
        if (!$objectCount) { return }
        if ($AutoChunkSize) { $ChunkSize = [Math]::Ceiling($objectCount / $Threads) }
        $finalThreadCount = [Math]::Min([Math]::Ceiling($objectCount / $ChunkSize), $Threads)
        $threadList = for ($i = 1; $i -le $finalThreadCount; $i++)
        {
            $thread = [ordered]@{}
            $thread.Thread = $i
            $thread.Round = 1
            $thread.PowerShell = [PowerShell]::Create()
            $thread.Invocation = $null
            [pscustomobject]$thread
        }
        $threadList = @($threadList)

        foreach ($variable in $ImportVariables)
        {
            foreach ($thread in $threadList)
            {
                $var = $PSCmdlet.SessionState.PSVariable.Get($variable)
                $thread.PowerShell.Runspace.SessionStateProxy.SetVariable($var.Name, $var.Value)
            }
        }

        Write-Verbose "Running Startup Script"
        foreach ($thread in $threadList)
        {
            $thread.Invocation = $thread.PowerShell.AddScript($StartupScript).BeginInvoke()
        }
        while ($threadList.Where({!$_.Invocation.IsCompleted})) { }
        foreach ($thread in $threadList)
        {
            $thread.PowerShell.EndInvoke($thread.Invocation)
            $thread.Invocation = $null
        }
        Write-Verbose "Completed Startup Script"

        $index = 0
        $completed = 0

        while ($completed -lt $objectCount)
        {
            do
            {
                $readyThreads = $threadList.Where({-not $_.Invocation -or $_.Invocation.IsCompleted})
            } while (!$readyThreads)

            foreach ($thread in $readyThreads)
            {
                if ($thread.Invocation)
                {
                    $result = $thread.PowerShell.EndInvoke($thread.Invocation)
                    $result
                    $thread.Invocation = $null
                    $completed += $ChunkSize
                }
                if ($index -ge $objectCount) { continue }
                $incrementSize = [Math]::Min($ChunkSize, $objectCount-$index)
                Write-Verbose "Executing script in thread $($thread.Thread) for items $index-$($index + $ChunkSize - 1)"
                $nextItems = $InputObjectList.GetRange($index, $incrementSize)
                $index += $incrementSize
                $thread.PowerShell.Runspace.SessionStateProxy.SetVariable('_', $nextItems)
                $thread.PowerShell.Runspace.SessionStateProxy.SetVariable('Thread', $thread.Thread)
                $thread.PowerShell.Runspace.SessionStateProxy.SetVariable('Round', $thread.Round)
                $thread.Invocation = $thread.PowerShell.AddScript($Script).BeginInvoke()
                $thread.Round += 1
            }
        }
    }
} #funct runspace code to multi-thread the connections:

<# Example output:
# 
# IloAddress        : LCPWD01R0008
# Type              : Dell
# Hostname          : LCPWD01A0008
# PowerState        : On
# PowerOnResultCode : Not Attempted
# 
# IloAddress        : LCPWD02R0007
# Type              : HP
# Hostname          : LCPWD02A0007
# PowerState        : On
# PowerOnResultCode : Not Attempted
# 
# IloAddress        : Servernamex
# Type              : 
# Hostname          : 
# PowerState        : 
# PowerOnResultCode : Not Attempted
# 
# =================================
# import from csv
#$iloAddressList = Import-Csv C:\temp\servers.csv | % {$_.HostName} | % Trim | ? { $_ }
#
# read from txt file
#$iloAddressList = (Get-Content C:\temp\servers.txt) -split "`r`n" | % Trim | ? { $_ }
#>

######################
# config file location
$mainfile = "$($env:APPDATA)\Scripts_UI"
$Srvfile      = "$($mainfile)\Servers.txt"
$csvSuccess   = "$($mainfile)\Success.csv" #...................temp file for jobs
$csvFail      = "$($mainfile)\Fail.csv" #......................temp file for jobs
$excelFileout = "$($mainfile)\Results.xlsx" # output xlsx file full path and name
$cfgfile      = "$($mainfile)\RunGuiSettings.txt" #....................script cfg

##################
# get server list
$iloAddressList = Get-InputBox -Message "DRAC or iLO name or IP, One per line" -WindowTitle "DRAC iLo List" -Inputfile $Srvfile
if(($iloAddressList -eq $null) -or ($iloAddressList -eq "")){Write-Host "Server list empty" -f Red; exit}

$tries = 0
while (!$tempCred) # prompt to enter creds for ILO/DRAC
{
    $message = "Enter your credentials for ILO$(if ($tries -gt 0) { " ($tries bad attempts)" } )"
    $tempCred = Get-Credential -Message $message
    if (!$tempCred) { throw "Credentials were not specified." }
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $domainContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext 'Domain', 'ent.wfb.bank.corp'
    $netCred = $tempCred.GetNetworkCredential()
    if (!$domainContext.ValidateCredentials($netCred.UserName, $netCred.Password))
    {
        $tempCred = $null
        $tries += 1
    }
}

$finalCred = New-Object System.Net.NetworkCredential ($tempCred.GetNetworkCredential().UserName, 'ent.wfb.bank.corp' -join '@'), $tempCred.Password

# You can also use a simple loop if you want to single thread it to see errors, or adapt this for Start-Job | Receive-Job notation
# $iloAddressList | ForEach-Object { 

# The actual ILO code: 
$iloAddressList | Invoke-PipelineThreading -Threads 10 -ChunkSize 1 -ImportVariables finalcred -Script {
    $iloAddress = $_ | Select-Object
    
    $result = 1 | Select-Object IloAddress, Type, Hostname, PowerState #, PowerOnResultCode
    $result.IloAddress = $iloAddress

    # Function to make the rest of the code more compact
    # Because Invoke-WebRequest is glitchy
    Function InvokeWebRequestPlus($Url,$Content,$Method,$Credential,$XAuthToken,$Timeout) {
        [System.Net.ServicePointManager]::SecurityProtocol = 'Tls12', 'Tls11', 'Tls'
        $request = [System.Net.WebRequest]::Create($Url)
        $request.ServerCertificateValidationCallback = { $true }
        if ($Credential) { $request.Credentials = $Credential }
        if ($Method) { $request.Method = $Method }
        if ($XAuthToken) { $request.Headers['X-Auth-Token'] = $XAuthToken }
        if ($Timeout) { $request.Timeout = $Timeout }
        if ($Content) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($Content)
            $request.ContentType = 'application/json'
            $request.ContentLength = $bytes.Length
            $requestStream = $request.GetRequestStream()
            $requestStream.Write($bytes, 0, $bytes.Length)
            $requestStream.Close()
        }
        $response = $request.GetResponse()
        $responseStream = $response.GetResponseStream()
        $memoryStream = New-Object System.IO.MemoryStream
        $responseStream.CopyTo($memoryStream)
        $responseText = [System.Text.Encoding]::UTF8.GetString($memoryStream.ToArray())

        [pscustomobject]@{ Headers=$response.Headers; Text=$responseText; ResponseCode=$response.ResponseCode }
    }

    # Step 1: Is it Dell or HP?
    $apiInfo = $null
    $apiInfo = InvokeWebRequestPlus -Url "https://$iloAddress/redfish/v1/" | ForEach-Object Text | ConvertFrom-Json
    if     ($apiInfo.Oem.Dell) { $result.Type = 'Dell' }
    elseif ($apiInfo.Oem.HP)   { $result.Type = 'HP' }
    
    # Step 2a: Get session for HP
    if ($result.Type -eq 'HP') {
        $authToken = $null
        $location = $null
        $content = @{
            UserName = $finalCred.UserName
            Password = $finalCred.Password
        } | ConvertTo-Json -Compress

        $response = InvokeWebRequestPlus -Url "https://$iloAddress/redfish/v1/sessions/" -Content $content -Method Post -Timeout (3*60*1000)
        
        $authToken = $response.Headers['X-Auth-Token']
        $location = $response.Headers['Location']
    }

    # Step 2: Get Power State
    $systemInfo = $null
    if ($result.Type -eq 'Dell') {
        $systemInfo = InvokeWebRequestPlus -Url "https://$iloAddress/redfish/v1/Systems/System.Embedded.1" -Credential $finalCred |
            ForEach-Object Text |
            ConvertFrom-Json
    }
    elseif ($result.Type -eq 'HP') {
        $systemInfo = InvokeWebRequestPlus -Url "https://$iloAddress/redfish/v1/Systems/1/" -XAuthToken $authToken |
            ForEach-Object Text |
            ConvertFrom-Json
    }

    $result.Hostname = $systemInfo.HostName
    $result.PowerState = $systemInfo.PowerState

    # Step 3: Logout for HP
    if ($result.Type -eq 'HP') {
        InvokeWebRequestPlus -Url $location -XAuthToken $authToken -Method Delete | Out-Null
    }
    
    $result
    $result | export-csv "c:\temp\Results.csv" -append -notypeinfo
} #Invoke-PipelineThreading

write-host "Script complete" -f cyan
pause 