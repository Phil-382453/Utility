﻿<#
.SYNOPSIS  
    (Input tab) This will allow comparing 2 files. Differences are displayed with arrow pointing to file (left or right) that has the difference.
.ROLE
    Utility
.FUNCTIONALITY
    files,compare,InputTab,NoServersNeeded
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$FileCompareMaster = New-UIObject
$FileCompareMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$FileCompareMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$FileCompareMaster.Textbox1 = ""
$FileCompareMaster.Textbox2 = ""
#endregion>
#------------------------------------------------------
#region - UI Action Scripts
$FileCompareMaster.Scripts = @{}
$FileCompareMaster.Scripts.Run = {

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($FileCompareMaster.WorkingDirectory)\$($FileCompareMaster.ScriptName).xml" -InputObject @{
        Textbox1 = $FileCompareMaster.Textbox1
        Textbox2 = $FileCompareMaster.Textbox2
    } #Export-Clixml

    $file1 = $FileCompareMaster.Textbox1 # get the textbox contents
    $file2 = $FileCompareMaster.Textbox2 # get the textbox contents
    $ArgumentList = $file1,$file2 #send these to the param of the $script
    $SubScriptMessage = "$(($FileCompareMaster.ScriptName) -replace ".ps1") - Compare files" # create console subscript message

    $script = Convert-ScriptOutputToText {
        Param([string]$file1,[string]$file2)

        $stringRef  = gc $file1 #read in the file
        $stringdiff = gc $file2 #read in the file
        Compare-Object $stringRef $stringdiff #Echo to output
    } #script

    # set the script type for proper execution
    $UIMaster.ConnectionType = "Local_NoSvrs"
    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .Run1
#endregion
#------------------------------------------------------
#region - UI Data Loading...
try {
    $SettingsClixml = Import-Clixml "$($FileCompareMaster.WorkingDirectory)\$($FileCompareMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'Textbox1','Textbox2'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $FileCompareMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $FileCompareMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 0,20,0,0 -Foreground Blue -FontWeight Bold
            New-UITextBlock "Purpose:" -FontWeight Bold -Margin 14,5,0,10
            New-UITextBlock "This will compare 2 files listed in the textboxes below." -Margin 20,10,0,0
            New-UITextBlock "Lines that are different are displayed with arrow pointing (left or right) to the file containing the difference." -Margin 20,10,0,0
            New-UITextBlock "Output:" -Margin 40,10,0,0 -Foreground Green
            New-UITextBlock "File1 `t<= `t file 2`tFile1 contains the line that is different." -Margin 40,10,0,0
            New-UITextBlock "or" -Margin 40,0,0,2
            New-UITextBlock "File1 `t=> `t file 2`tFile2 contains the line that is different." -Margin 40,0,0,0
            New-UITextBlock "Enter the full path to File1:" -Margin 20,40,0,0 -Foreground Black
            New-UITextBox -Width 800 -Height 20 -Align CenterLeft -Margin 20,10,0,0 -BindTextTo Textbox1
            New-UITextBlock "Enter the full path to File2:" -Margin 20,40,0,0 -Foreground Black
            New-UITextBox -Width 800 -Height 20 -Align CenterLeft -Margin 20,10,0,0 -BindTextTo Textbox2
            New-UIStackPanel -Orientation Horizontal -Margin 20,40,0,0 {
                New-UIButton "Run" -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                    -AddClick $FileCompareMaster.Scripts.Run
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 0,10,0,0 -Foreground Blue -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion>
#------------------------------------------------------
# PowerShell script complete 