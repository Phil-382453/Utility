﻿<#
.SYNOPSIS
    (Input tab) Server(s) will robocopy (pull) files/folder from UNC, Verify dir contents, Unzip a file, and delete a file(s).
.ROLE
    Utility
.DESCRIPTION  
    This script will work with file(s)/folder on one or more servers.
    File copy      - copy a file(s) to a local path on a server(s).
    Folder copy    - copy a folder (recurse) to a local path on a server(s).
    Verify folder  - run dir command on the folder to list its contents.
    Unzip file     - unzip a file on one or more servers.
    Delete file(s) - delete file(s) on one or more servers.
.INPUTS
    Serverlist - from Main (1st) tab.
    Privileged Credentials for the server list.
    Copy:
        Source file(s)/folder - UNC.
        Credentials to access the source file/folder
        Destination - Local path on server(s).
    Verify folder: 
        run dir command on server(s)
    Unzip:
        Unzip a file to the same location, on the server list.
    Delete:
        Delete one or more files, on the server list.
.FUNCTIONALITY
    Copy,files,folders,dir,delete,unzip,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
######################
# initialize $CopyUnzipDelete
$CopyUnzipDelete = New-UIObject 
$CopyUnzipDelete.ServerListFilePath = "$env:appdata\Servers.txt"
$CopyUnzipDelete.ScriptName         = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$CopyUnzipDelete.WorkingDirectory   = $UIMaster.WorkingDirectory
$CopyUnzipDelete.ServerText         = $UIMaster.ServerText #...ServerList from Main tab
$CopyUnzipDelete.LabelBrowseSource  = "This is the source file path (UNC). Selected files will appear in the FilesNames box above." # Default
$CopyUnzipDelete.CopyType           = "File" # Default. File/Folder - Tells script which browser
$CopyUnzipDelete.CredsforCopy       = $UIMaster.CredsforCopy
$CopyUnzipDelete.FolderPathSource   = ""
$CopyUnzipDelete.FileNamesSource    = "testcopy1.txt`r`ntestcopy2.txt`r`n" # Default
$CopyUnzipDelete.TextboxDestination = "c:\temp" # Default
$CopyUnzipDelete.VerifyFolderContents = "c:\temp"
$CopyUnzipDelete.RadioFilesToServer   = $true  # Default
$CopyUnzipDelete.RadioFolderToServer  = $false # Default
$CopyUnzipDelete.UnzipFileName       = ""
$CopyUnzipDelete.Lable1UnzipFileName = "Enter the local path of the file to unzip.        Ex: c:\temp\file1.zip"
$CopyUnzipDelete.Lable2UnzipFileName = "Files will be unzipped to their current location. Ex: c:\temp\file1"
#endregion>
#------------------------------------------------------
#region - UI Action Scripts ... Launch different script types: standalone,input-required,simple scriptblock, output tab and buttons.
$CopyUnzipDelete.Scripts = @{} # Initialize

$CopyUnzipDelete.Scripts.Helpx = {
        $help = @() #..............................................................initialize as array
        $help = 'Copy files or folders to one or more servers:' + "`n" +
            '    Each server will:' + "`n" +
            '       Use creds to connect a psdrive to the source UNC.' + "`n" +
            '       Robocopy from source to server local driv path.' + "`n" +
            '' + "`n" +
            '    1. Serverlist:' + "`n" +
            '       Copy/Paste or Load from File - (csv or txt)' + "`n" +
            '       csv - choose servers column.' + "`n" +
            '       Removes duplicates and empty lines.' + "`n" +
            '' + "`n" +
            '    2. Copy Type:' + "`n" +
            '       - Files  - Select file(s) from a Source UNC filepath.' + "`n" +
            '       - Folder - Copy Folder/subfolders/files.' + "`n" +
            '' + "`n" +
            '    3. Browse to the Source UNC path:' + "`n" +
            '       File browser/Folder browser.' + "`n" +
            '' + "`n" +
            '    4. Credentials for the Source:' + "`n" +
            '       Each server will connect to the same Source path.' + "`n" +
            '       Creds are needed to connect server/Source path.' + "`n" +
            '' + "`n" +
            '    5. Enter the Destination...Server Local Path:' + "`n" +
            '       - Example: D:\folder1\folder2\...' + "`n" +
            '' + "`n" +
            '    6. Show Choices:' + "`n" +
            '         - Saved to file/loaded with next script run.' + "`n" +
            '         Copy Type, Browse Path [filenames],' + "`n" +
            '         Username, Destination,' + "`n" +
            '         ServerList' + "`n" +
            '' + "`n" +
            '    7. Run:' + "`n" +
            '       A Scriptblock is sent to ServerList -AsJob' + "`n" +
            '         Blazing fast :)' + "`n" +
            '       Code executes on each server:' + "`n" +
            '       1. New-PSDrive -PSProvider filesystem' + "`n" +
            '          -Root "$Source" -Name "name123"' + "`n" +
            '          -Credential $CredForCopy' + "`n" +
            '       2. Robocopy uses same "$Source" as New-PSDrive.' + "`n" +
            '          robocopy.exe "$Source" "$Destination"' + "`n" +
            '       3. Remove-PSDrive' + "`n" +
            '       4. Output from Robocopy sent to console.' + "`n"

    $helpmsg = new-object -comobject wscript.shell #.................create com object
    $helpmsg.popup(“$($help)“,0,“ Help”,0) #.............display the popup
    return
}

# Execute when clicking radio buttons
$CopyUnzipDelete.Scripts.RadioFilesToServers = {
    # 1st - Save settings
    $CopyUnzipDelete.FileNames1         = $CopyUnzipDelete.FileNamesSource # not needed....FileNamesSource already equals ""
    $CopyUnzipDelete.FolderDestination1 = $CopyUnzipDelete.TextboxDestination # save setting before updating
    # 2nd - Update settings from previous
    if($CopyUnzipDelete.FileNames2)      {$CopyUnzipDelete.FileNamesSource    = $CopyUnzipDelete.FileNames2      } # update filenames box
    if($CopyUnzipDelete.FileDestination1){$CopyUnzipDelete.TextboxDestination = $CopyUnzipDelete.FileDestination1} # update textbox based on past entry
    $CopyUnzipDelete.LabelBrowseSource = "This is the source file path (UNC). Selected files will appear in the FilesNames box above."
}.GetNewClosure()

# Execute when clicking radio buttons
$CopyUnzipDelete.Scripts.RadioFolderToServers = {
    # 1st - Save settings
    $CopyUnzipDelete.FileNames2       = $CopyUnzipDelete.FileNamesSource # save setting before updating
    $CopyUnzipDelete.FileDestination1 = $CopyUnzipDelete.TextboxDestination # save setting before updating
    # 2nd - Update settings from previous
    if($CopyUnzipDelete.FileNamesSource)   {$CopyUnzipDelete.FileNamesSource    = ""                               } # update textbox based on past entry
    if($CopyUnzipDelete.FolderDestination1){$CopyUnzipDelete.TextboxDestination = $CopyUnzipDelete.FolderDestination1} # update textbox based on past entry
    $CopyUnzipDelete.LabelBrowseSource  = "This is the source folder path (UNC)."
}.GetNewClosure()

# Source Path File/Folder
$CopyUnzipDelete.Scripts.Browse = {
    $Source    = $null #...clear any old values
    $FileNames = $null #...clear any old values
    $temp      = $CopyUnzipDelete.FolderPathSource # save current value from GUI source textbox (folderpath) 

    if($CopyUnzipDelete.RadioFolderToServer){
        [string]$Source = [string](Get-FolderBrowser -inidir $temp) # Broswe/Select Source folder for copy.
        $Source = $Source.Trim() # remove leading/trailing whitespace

        if ($Source){ # if a source folder is select from browse
            $CopyUnzipDelete.FolderPathSource = $Source # Place the selected folder (and path) into the GUI textbox (source).
            $CopyUnzipDelete.FileNamesSource = $null # dont show files in gui textbox when copying a folder.
            # Append FolderName to Destination in the GUI textbox (destination)...I expect the selected folder would be copied not just files and subfolders
            $CopyUnzipDelete.Destination = "$($CopyUnzipDelete.TextboxDestination)\$(($Source.Split('\'))[-1])" # Append FolderName to Destination in the GUI (destination) textbox.
            $CopyUnzipDelete.TextboxDestination = $CopyUnzipDelete.Destination # Update the GUI destination textbox with appended folder name.
        }
        else {
            write-Host ""; write-Host "Cancel" -f Red
            $CopyUnzipDelete.Source = ""
            return # Try again
        }
    } #if
    Elseif ($CopyUnzipDelete.RadioFilesToServer){
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        $dialog = New-Object System.Windows.Forms.OpenFileDialog #.......create a file open form
        $dialog.InitialDirectory = $CopyUnzipDelete.FolderPathSource #...set the starting directory for browsing
        $dialog.Multiselect = $true #...............allow choosing multiple files
        $result = $dialog.ShowDialog() #............make the dialog box visible
        # $dialog.FileNames ... contains the list of select files (full path)
        if ($result -ne 'OK') {
            write-Host ""
            write-Host "Cancel" -f Red
            $CopyUnzipDelete.Source = ""
            return # Try again
        }

        # Get the source filename list (and source folder path)
        [string[]]$FileNames += $dialog.FileNames | ForEach-Object {($_ -split ("\\"))[-1]} # get the source filename list
        $Source = (($dialog.FileNames | select -First 1) -replace "$($FileNames[0])","").TrimEnd('\') # get the source foldername
        $CopyUnzipDelete.FolderPathSource = $Source #   set the UIMaster
        $CopyUnzipDelete.FileNamesSource  = $FileNames -join "`r`n" # set the UIMaster  FolderPathSource
         -join "`r`n"
    } #else
}.GetNewClosure() #Browse

# Enter credentials for the source UNC. This is required by the servers to connect to the source.
$CopyUnzipDelete.Scripts.EnterCredsForSource = {
    # Minimize the window while getting credentials
    $previousWindowState = $UIMaster.Window.windowState
    $UIMaster.Window.WindowState = 'Minimized'
    if(!("$($CopyUnzipDelete.CredsforCopy.UserName)")){
        $CopyUnzipDelete.CredsforCopy = $UIMaster.CredsforCopy
    }
    if(!("$($CopyUnzipDelete.CredsforCopy.UserName)")){
        $CopyUnzipDelete.CredsforCopy = Get-Credential -credential "$($CopyUnzipDelete.CredsforCopy.UserName)" # Get creds for source file access. Set the UIMaster
    }
    #Write-Host ""
    #Write-Host "...verifying `$creds"
    #Write-Host ""
    $UIMaster.CredsforCopy = $CopyUnzipDelete.CredsforCopy # Set Main Script Creds2Copy to match
    $UIMaster.Window.WindowState = $previousWindowState # Restore the popup window
}.GetNewClosure() #EnterCredsForSource
##############################################################################
$CopyUnzipDelete.Scripts.RunCopy   = {
    # Validate input
    if ($UIMaster.ServerText -eq "")                {Show-UIMessageBox "      No Servers Entered!"; return} 
    if(!"$($CopyUnzipDelete.CredsforCopy.UserName)"){Show-UIMessageBox "      Please enter Creds for the copy Source!"; return}
    if(!"$($CopyUnzipDelete.FolderPathSource)")     {Show-UIMessageBox "      Please enter copy Source!"; return}
    if(!"$($CopyUnzipDelete.TextboxDestination)")   {Show-UIMessageBox "      Please enter copy Destination!"; return}

    #Write-Host "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
    # Export settings to cache
    Export-Clixml -Path "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml" -InputObject @{
        RadioFilesToServer   = $CopyUnzipDelete.RadioFilesToServer
        RadioFolderToServer  = $CopyUnzipDelete.RadioFolderToServer
        FolderPathSource     = $CopyUnzipDelete.FolderPathSource
        FileNamesSource      = $CopyUnzipDelete.FileNamesSource
        TextboxDestination   = $CopyUnzipDelete.TextboxDestination
        VerifyFolderContents = $CopyUnzipDelete.VerifyFolderContents
        UnzipFileName        = $CopyUnzipDelete.UnzipFileName
           DeleteFileNames      = $CopyUnzipDelete.DeleteFileNames
    } #Export-Clixml

    # Collect variables to send to the Scriptblock as Arguments
    $CredsforCopy = $CopyUnzipDelete.CredsforCopy
    if ($CopyUnzipDelete.RadioFilesToServer)  {
        $CopyType = "FilesToServer"
        $SubScriptMessage = "$(($CopyUnzipDelete.ScriptName) -replace ".ps1") - File(s) Copy to server(s)"
    }
    elseif($CopyUnzipDelete.RadioFolderToServer) {
        $CopyType = "FolderToServer"
        $SubScriptMessage = "$(($CopyUnzipDelete.ScriptName) -replace ".ps1") - Folder Copy to server(s)"
    }
    #elseif($CopyUnzipDelete.RadioFilesFromServer){$CopyType = "FilesFromServer"}
    $Source       = $CopyUnzipDelete.FolderPathSource
    $Destination  = $CopyUnzipDelete.TextboxDestination
    
    # trim & remove empty rows from filenames
    $ErrorActionPreference = "SilentlyContinue"
    $FileNames    = $CopyUnzipDelete.FileNamesSource.Split("`n").Trim() | Where {$_.trim() -ne ""} # trim & remove empty rows
    $ErrorActionPreference = "Continue"

    $ArgumentList = $CredsforCopy,$CopyType,$Source,$Destination,$FileNames
    #######################################
    # Launch this script section
    $script = Convert-ScriptOutputToText { # query script
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [System.Management.Automation.PSCredential]$CredForCopy,

            # Used to identify copy type
            [Parameter(Mandatory=$true,Position=1)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [ValidateSet("FilesToServer","FolderToServer","FilesFromServer")]
            [string]$CopyType, 

            # Contains folder path (only)
            [Parameter(Mandatory=$true,Position=2)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string]$Source,

            # Used to identify destination (for copy)
            [Parameter(Mandatory=$true,Position=3)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string]$Destination,

            # Contains fileNames (only, not folder path)
            [Parameter(Mandatory=$false,Position=4)]
            [string[]]$FileNames
        )
        Begin{
            <# Troubleshooting
            #$passwrd = $CredForCopy.GetNetworkCredential().Password
            Write-Host ""
            Write-Host "Hostname    = $($env:computername)"
            Write-Host "CredForCopy = $($CredForCopy.UserName)"
            Write-Host "CopyType    = $($CopyType)"
            Write-Host "SourcePath  = $($Source)"
            Write-Host "LocalPath   = $($Destination)"
            Write-Host "FileNames:"
            foreach($file in $FileNames){Write-Host "`t$($file)"}
            Write-Host ""
            #>
            ###########################################
            # New-PSDrive will establish the connection
            # robocopy uses the same $Source
            $DriveName = (ls function:[d-z]: -n | ?{ !(test-path $_) } | random).TrimEnd(':') # remove the : from drive letter

            if(($CopyType -eq "FilesToServer") -or ($CopyType -eq "FolderToServer")){
                #Write-Host "$($CopyType)"
                # this will give an error even though it works...dont use erroraction or try/catch...suppress output errors
                New-PSDrive -PSProvider FileSystem -Root "$($Source)" -Name $DriveName -Credential $CredForCopy | Out-Null
            }
            else {
                # this will give an error even though it works...dont use erroraction or try/catch...suppress output errors
                #New-PSDrive -PSProvider FileSystem -Root "$($Source)" -Name $DriveName -Credential $CredForCopy | Out-Null
            }
        } #Begin
        Process{
            if ($CopyType -eq "FilesToServer"){ # File Copy
                ##################################
                $FileNamesx = ($FileNames -split "`r`n").Trim()
                foreach($FileName in $FileNamesx){
                    [string[]]$Robocopy += robocopy.exe "$($Source)" "$($Destination)" "$($FileName)" /NP /XJ /R:1 /W:1
                } #foreach
            } #if
            elseif ($CopyType -eq "FolderToServer") { # Folder Copy
                #Write-Host "$($CopyType)"
                ##################################
                [string[]]$Robocopy += robocopy.exe "$($Source)" "$($Destination)" /NP /E /R:1 /W:1
            } #else
            elseif ($CopyType -eq "CopyFilesFromServer"){
                ##################################
                foreach($fileName in $Filenames){
            #        [string[]]$Robocopy += robocopy.exe "$($Source)" "$($Destination)" "$($FileName)" /NP /XJ /R:3 /W:1
                    #robocopy.exe "$($Source)" "$($Destination)" "$($FileName)" /NP /XJ /R:3 /W:1
                } #for
            } #elseif
        } #Process
        End{
            #######################
            # remove the connection
            #""
            #"###############################################################################"
            #"###############################################################################"
            #"HostName = $($env:computername)"
            #""
            foreach($line in $Robocopy){"$($line)"}
            <#
            Write-Verbose ""
            Write-Verbose "=========================" -f Magenta
            Write-Verbose "HostName     = $($env:computername)" -f Yellow
            Write-Verbose "CredForCopy  = $($CredForCopy.UserName)"
            Write-Verbose "CopyType     = $($CopyType)"
            Write-Verbose "SourcePath   = $($Source)"
            Write-Verbose "LocalPath    = $($Destination)"
            Write-Verbose "PSDrive Name = $($DriveName)"
            #>
            if(Get-PSDrive -Name $DriveName){ Remove-PSDrive $DriveName -Force }
            #"Get-PSDrive"
            #Get-PSDrive
        } #End
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CopyUnzipDelete.Scripts.RunListFolderContents = {

    # Validate input
    if ($UIMaster.ServerText                  -eq ""){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($CopyUnzipDelete.VerifyFolderContents -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return}

    $SubScriptMessage = "$(($CopyUnzipDelete.ScriptName) -replace ".ps1") - Get info (dir)"

    Write-Verbose "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml" -InputObject @{
        RadioFilesToServer   = $CopyUnzipDelete.RadioFilesToServer
        RadioFolderToServer  = $CopyUnzipDelete.RadioFolderToServer
        FolderPathSource     = $CopyUnzipDelete.FolderPathSource
        FileNamesSource      = $CopyUnzipDelete.FileNamesSource
        TextboxDestination   = $CopyUnzipDelete.TextboxDestination
        VerifyFolderContents = $CopyUnzipDelete.VerifyFolderContents
        UnzipFileName        = $CopyUnzipDelete.UnzipFileName
           DeleteFileNames      = $CopyUnzipDelete.DeleteFileNames
    } #Export-Clixml
    # Collect variables to send to the Scriptblock as Arguments
    $ArgumentList = $CopyUnzipDelete.VerifyFolderContents

    #######################################
    # Launch this script section
    $script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            $VerifyFolderContents
        )
        Begin{
            #""
            #"###############################################################################"
            #"###############################################################################"
            #"HostName = $($env:computername)"
            #""
        }
        Process{ 
            $temp = $VerifyFolderContents -split "`r`n" | ForEach Trim | Where { $_ }  # trim & remove empty rows
            Foreach($folder in $temp){ 
                $folder = $folder.Trim()
                dir $folder
            }
        }
        End{}
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CopyUnzipDelete.Scripts.RunUnzip  = {
    
    # Validate input
    if ($UIMaster.ServerText           -eq ""){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($CopyUnzipDelete.UnzipFileName -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return} 
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml" -InputObject @{
        RadioFilesToServer   = $CopyUnzipDelete.RadioFilesToServer
        RadioFolderToServer  = $CopyUnzipDelete.RadioFolderToServer
        FolderPathSource     = $CopyUnzipDelete.FolderPathSource
        FileNamesSource      = $CopyUnzipDelete.FileNamesSource
        TextboxDestination   = $CopyUnzipDelete.TextboxDestination
        VerifyFolderContents = $CopyUnzipDelete.VerifyFolderContents
        UnzipFileName        = $CopyUnzipDelete.UnzipFileName
           DeleteFileNames      = $CopyUnzipDelete.DeleteFileNames
    } #Export-Clixml
    
    $SubScriptMessage = "$(($CopyUnzipDelete.ScriptName) -replace ".ps1") - Unzip File on server(s)"

    Write-Verbose "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
    # Collect variables to send to the Scriptblock as Arguments
    $ZipFileFull = $CopyUnzipDelete.UnzipFileName
    $ArgumentList =  $ZipFileFull

    #######################################
    # Launch this script section
    $script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string]$ZipFileFull
        )
        Begin{
            Add-Type -assembly "system.io.compression.filesystem" # assemble required for zip/unzip
        }
        Process{ 
            #""
            #"###############################################################################"
            #"###############################################################################"
            #"HostName = $($env:computername)"

            $ZipFileNameExt = ($ZipFileFull.split("`\"))[-1] # Get filename.ext - split the $ZipFileFull by backslash
            $ZipFilePath    = $ZipFileFull -replace ("$($ZipFileNameExt)","") # Remove the zipfile name.ext from the zipfile full path
            $ZipFileName    = $ZipFileNameExt -replace  ".zip","" # 
            
            write-host "ZipFileFull    = $($ZipFileFull)"    # passed in = c:\temp\filename1.zip
            write-host "ZipFilePath    = $($ZipFilePath)"    # 1st half of split = c:\temp (no filename)
            write-host "ZipFileNameExt = $($ZipFileNameExt)" # 2nd half of split = filename.zip
            write-host "ZipFileName    = $($ZipFileName)"    # 2nd half of split = just the filename (no .zip)
            
            # Extract the zip file to the current directory (usually c:\temp)
            [System.IO.Compression.ZipFile]::ExtractToDirectory("$($ZipFileFull)","$($ZipFilePath)$($ZipFileName)")

            #dir "$ZipFilePath\$ZipFileName"
        }
        End{}
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$CopyUnzipDelete.Scripts.RunDelete = {

    # Validate input
    if ($UIMaster.ServerText             -eq ""){Show-UIMessageBox "      No Servers Entered!"   ; return} 
    if ($CopyUnzipDelete.DeleteFileNames -eq ""){Show-UIMessageBox "      No FolderPath Entered!"; return} 
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml" -InputObject @{
        RadioFilesToServer   = $CopyUnzipDelete.RadioFilesToServer
        RadioFolderToServer  = $CopyUnzipDelete.RadioFolderToServer
        FolderPathSource     = $CopyUnzipDelete.FolderPathSource
        FileNamesSource      = $CopyUnzipDelete.FileNamesSource
        TextboxDestination   = $CopyUnzipDelete.TextboxDestination
        VerifyFolderContents = $CopyUnzipDelete.VerifyFolderContents
        UnzipFileName        = $CopyUnzipDelete.UnzipFileName
           DeleteFileNames      = $CopyUnzipDelete.DeleteFileNames
    } #Export-Clixml
    
    $SubScriptMessage = "$(($CopyUnzipDelete.ScriptName) -replace ".ps1") - Delete File/Folder on server(s)"
    
    Write-Verbose "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
    # Collect variables to send to the Scriptblock as Arguments
    $DeleteFileNames = $CopyUnzipDelete.DeleteFileNames 
    $ArgumentList = $DeleteFileNames
    Write-Verbose ""
    Write-Verbose $ArgumentList

    ###########################################
    ### Execute File Delete on remote server(s)
    ###########################################
    # Launch this script section
    $script = Convert-ScriptOutputToText {
        Param(
            # Used to connect to source (for copy)
            [Parameter(Mandatory=$true,Position=0)]
            [ValidateNotNull()]
            [ValidateNotNullOrEmpty()]
            [string[]]$DeleteFileNames
        )
        Begin{
            #""
            #"###############################################################################"
            #"###############################################################################"
            #"HostName = $($env:computername)"
            #""
        }
        Process{
            $DeleteFileNameslist = $DeleteFileNames.Split("`n").Trim() | Where {$_.trim() -ne ""} # trim & remove empty rows
            foreach ($item in $DeleteFileNameslist){ 
                Write-Verbose "1";Write-Verbose "$($item)";Write-Verbose "2"

                if(Test-Path "$($item)"){ 
                    remove-item "$($item)" -force -recurse -ErrorAction SilentlyContinue
                    if(Test-Path "$item"){"Delete Fail - $($item)"}
                    else {"Delete Success - $($item)"}
                }
                else {"Not found - $($item)"}
            } #for        
        }
        End{""}
    } #$script
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
##############################################################################
# Close the tab
$CopyUnzipDelete.Scripts.Cancel = {
    $tabItem = Find-UIParent -Type TabItem
    $tabItem.Parent.Items.Remove($tabItem)
}.GetNewClosure() # close script tabs
#endregion>
#------------------------------------------------------
#region - UI Data Loading ... list of scripts, Synopsis, Functionality, ScriptText, Outputs, IsFavorite, Color
Write-Host "Loading Cache.....please wait"

# Get Server List from cache file if it exists.
# $CopyUnzipDelete.ServerText = (Get-Content -Path "$($CopyUnzipDelete.ServerListFilePath)" -ErrorAction Ignore) -join "`r`n"

# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($CopyUnzipDelete.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml" -ErrorAction Stop
    $list1 = 'RadioFolderToServer','RadioFilesToServer','FolderPathSource','FileNamesSource'
    $list2 = 'TextboxDestination','VerifyFolderContents','UnzipFileName','DeleteFileNames'
    $list3 = $list1 + ',' + $list2
    foreach ($setting in $list3) {
        if ($SettingsClixml.Contains($setting)) { $CopyUnzipDelete.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

Write-Host "Complete" 
Write-Host "===============================" -f Green
Write-Host ""

#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -DataContext $CopyUnzipDelete -RowDefinition *,auto -ColDefinition * {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIGrid -RowDefinition auto,auto,auto -ColDefinition * {
            $PSDefaultParameterValues["New-UIGrid:ShowGridLines"] = $false
            
            # Grid Row 0 - Copy
            New-UIStackPanel -GridRow 0 -Orientation Vertical -Margin 25,10,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,0,0,0 -Foreground Blue -FontWeight Bold

                # Main Label 
                New-UIStackPanel -Orientation Horizontal -Margin 0,0,0,0 {
                    New-UITextBlock "Copy files or folders to one or more servers:" -Margin 0,0,10,0 -AlsoSet @{FontSize=18} -FontWeight Bold -Foreground Blue 
                    #New-UIButton "Help" -Align CenterLeft -Padding 10,6,10,6 -AddClick $CopyUnzipDelete.Scripts.Helpx
                } #stackpanel
                New-UITextBlock -Margin 0,4,0,0 "Each server will use creds to connect to the source UNC and Robocopy to server local driv path." -Foreground Black -AlsoSet @{FontSize=14}
                
                # Radio buttons, filenames (Textbox), Enter Creds button
                New-UIStackPanel -Orientation Horizontal -Margin 0,0,0,0 {
                    New-UIStackPanel -Orientation Vertical -Margin 0,0,0,0 {
                        New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 {
                            # Copy Type
                            New-UIStackPanel -Orientation Vertical -Margin 0,0,0,0 {
                                New-UITextBlock "Select Copy Type:" -Margin 0,0,0,6 -Foreground Blue -AlsoSet @{FontSize=14}
                                New-UIRadioButton "Copy Files To Server" -Margin 10,4,0,0 -BindIsCheckedTo RadioFilesToServer -AddClick $CopyUnzipDelete.Scripts.RadioFilesToServers
                                New-UIRadioButton "Copy Folder To Server"  -Margin 10,6,0,0 -BindIsCheckedTo RadioFolderToServer -AddClick $CopyUnzipDelete.Scripts.RadioFolderToServers
                            } #stackpanel

                            # FileNamesSource
                            New-UIStackPanel -Orientation Vertical -Margin 43,0,0,0 {
                                New-UITextBlock "FileNames:" -Margin 0,0,0,0 -AlsoSet @{FontSize=14}
                                New-UITextBox -Width 200 -Height 50 -Margin 0,4,0,0 -VerticalScrollBarVisibility Visible -BindTextTo FileNamesSource
                            } #stackpanel
                        } #StackPanel

                        # Creds
                        New-UIStackPanel -Orientation Horizontal -Margin 2,10,0,0 {
                            New-UITextBlock "Credentials for the Source:" -Margin 0,15,25,0 -Foreground Blue -AlsoSet @{FontSize=14}
                            New-UIButton "Creds" -Padding 10,6,10,6 -Align bottomLeft -AddClick $CopyUnzipDelete.Scripts.EnterCredsForSource
                            New-UIStackPanel -Orientation Vertical -Margin 20,0,0,0 {
                                New-UITextBlock "You must enter creds that have access to the source being copied." -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                                New-UITextBlock "Each server will use these credentials for robocopy." -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                            } #StackPanel
                        } #StackPanel
                    } #stackpanel
                } #stackpanel
                
                # Browse to source (Textbox)
                New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 {
                    New-UITextBlock "Source:" -Margin 0,14,20,0 -Foreground Blue -AlsoSet @{FontSize=14}
                    New-UIButton "Browse" -Padding 10,6,10,6 -Align CenterLeft -AddClick $CopyUnzipDelete.Scripts.Browse
                    New-UITextBlock -BindTextTo LabelBrowseSource -Margin 10,14,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                } #StackPanel
                New-UIStackPanel -Orientation Vertical -Margin 0,6,0,0 { # needed for proper indent
                    New-UITextBox -Width 672 -Height 20 -BindTextTo FolderPathSource -Align CenterLeft
                } #StackPanel

                # Destination (Textbox)
                New-UITextBlock "Destination:" -Margin 0,20,0,0 -Foreground Blue -AlsoSet @{FontSize=14}
                New-UIStackPanel -Orientation Vertical -Margin 0,0,0,0 { # needed for proper indent
                    New-UITextBlock "This will be a local drive\path for the server(s)`t`tExample: c:\Windows\tools" -Margin 0,0,0,6 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 20 -Align CenterLeft -AcceptsReturn $false -BindTextTo TextboxDestination
                } #StackPanel - Textbox destination path

                # Launch the copy portion of this script
                New-UIStackPanel -Orientation Horizontal -Margin 0,30,5,0 { # needed for proper indent
                    New-UIButton "Copy" -Align CenterLeft -Padding 10,6,10,6 -AddClick $CopyUnzipDelete.Scripts.RunCopy -Foreground Red
                    New-UITextBlock "Initiate the copy" -Margin 10,5,0,0 -AlsoSet @{FontSize=14} 
                } #StackPanel

            } #stackpanel

            # GridRow 1  - Verify, Unzip, Delete
            New-UIStackPanel -GridRow 1 -Orientation Vertical -Margin 25,5,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,10,0,0 -Foreground Blue -FontWeight Bold 

                # Verify Folder Contents
                New-UIStackPanel -Orientation Vertical -Margin 0,5,0,10 {
                    New-UITextBlock "Verify Folder Contents:" -Margin 0,0,10,10 -Foreground Blue -AlsoSet @{FontSize=18} -FontWeight Bold
                    New-UITextBlock "This will list the contents (local path) for your server(s). Enter a folder path`tExample: c:\windows\tools" -Margin 0,0,0,10 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo VerifyFolderContents
                    New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 { # needed for proper indent
                        New-UIButton "Verify" -Padding 10,6,10,6 -Align TopLeft -AddClick $CopyUnzipDelete.Scripts.RunListFolderContents -Foreground Red
                        New-UITextBlock "Initiate the verify" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} 
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 0,5,0,0 -Foreground Blue -FontWeight Bold

                # Unzip
                New-UIStackPanel -Orientation Vertical -Margin 0,5,0,0 { # needed for inden
                    New-UITextBlock "Unzip:" -Margin 0,0,0,10 -Foreground Blue -AlsoSet @{FontSize=18} -FontWeight Bold
                    New-UITextBlock "Enter the local path and filename to unzip.`t`tc:\temp\filename.zip" -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "Files will be unzipped to their current location.`tc:\temp\filename\*.*" -Margin 0,0,0,10 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 20 -Align CenterLeft -AcceptsReturn $true -BindTextTo UnzipFileName
                    New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 {
                        New-UIButton "Unzip" -Padding 10,6,10,6 -Align TopLeft -AddClick $CopyUnzipDelete.Scripts.RunUnzip -Foreground Red
                        New-UITextBlock "Initiate the unzip" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} 
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 1,15,0,0 -Foreground Blue -FontWeight Bold
                
                # Delete
                New-UIStackPanel -Orientation Vertical -Margin 0,5,0,0 { # needed for indent
                    New-UITextBlock "Delete:" -Margin 0,0,0,0 -Foreground Blue -AlsoSet @{FontSize=18} -FontWeight Bold
                    New-UITextBlock "This will delete file(s) on the server(s)" -Margin 0,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "Enter the local path and filename to delete. Multiple files allowed...full path for each." -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "Example:`t`tc:\temp\file1.txt" -Margin 0,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBlock "`t`td:\folder1\file1.txt" -Margin 0,0,0,10 -Foreground Black -AlsoSet @{FontSize=14}
                    New-UITextBox -Width 672 -Height 60 -Align CenterLeft -AcceptsReturn $true -BindTextTo DeleteFileNames
                    New-UIStackPanel -Orientation Horizontal -Margin 0,20,0,0 {
                        New-UIButton "Delete" -Padding 10,6,10,6 -Align TopLeft -AddClick $CopyUnzipDelete.Scripts.RunDelete -Foreground Red
                        New-UITextBlock "Initiate the delete" -Margin 10,10,0,0 -AlsoSet @{FontSize=14} 
                    } #StackPanel
                } #StackPanel
                New-UITextBlock ("*" * 200) -Margin 1,15,0,40 -Foreground Blue -FontWeight Bold
            } #stackpanel
        } #New-UIGrid
    } #New-UIScrollViewer
    
    # Grid Row 2 
    New-UIStackPanel -GridRow 2 -Orientation Horizontal -Margin 0,5,0,0 {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return}
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #New-UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete