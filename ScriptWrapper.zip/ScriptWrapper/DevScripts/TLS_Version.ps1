﻿<#
.SYNOPSIS  
    Get Client/Server TLS settings - Transport Layer Security
.ROLE
    Security
.FUNCTIONALITY
    SecurityProviders,SCHANNEL,Protocols,TLS,Text
.NOTES
     Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Text
#>

## Start ##
$valuepath  = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS ***\###"  # the *** & ### will be replaced in string
$valuename  = "DisabledByDefault"
$arrTypes   = "Client","Server"
$arrTLSVers = "1.0","1.1","1.2"

foreach ($type in $arrTypes) {

    #Write-Host "$type"
    #Write-Host "----------"
    ""
    "$type"
    "----------"

    foreach ($tlsver in $arrTLSVers) {

        #region TLS Client
        #Write-Host "Checking TLS $tlsver . . ."
        $tlspath = ($valuepath.Replace("***",$tlsver)).Replace("###",$type)
        $tlsvalue = (Get-ItemProperty -Path $tlspath -Name $valuename).$valuename
        
        if ($tlsvalue -eq 1) {
            #Write-Host "TLS $tlsver ($tlsvalue): "  -NoNewline 
            #Write-Host "Disabled" -ForegroundColor Red
            "TLS $tlsver    ($tlsvalue): Disabled"
        } 
        else {
            #Write-Host "TLS $tlsver ($tlsvalue): " -NoNewline 
            #Write-Host "Enabled" -ForegroundColor Green
            "TLS $tlsver    ($tlsvalue): Enabled"
        }
    }
}
## End ##