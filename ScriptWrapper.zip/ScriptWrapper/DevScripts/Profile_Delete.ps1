﻿<#
.SYNOPSIS  
    (Input tab) Delete a Corrupt Profile. If you recieve a temp provile at logon... logoff... have a team mate delete your user profile on the target server.
.ROLE
    Users
.FUNCTIONALITY
    User,Profile,Delete,InputTab
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$ProfileDeleteX = New-UIObject
$ProfileDeleteX.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$ProfileDeleteX.WorkingDirectory   = $UIMaster.WorkingDirectory
$ProfileDeleteX.ServerText         = "$($ProfileDeleteX.WorkingDirectory)\Servers.txt"
$ProfileDeleteX.Textbox1 = "ra382453"
#$ProfileDeleteX.Textbox2= $null

#endregion
#------------------------------------------------------
#region - UI Action Scripts
$ProfileDeleteX.Scripts = @{}
$ProfileDeleteX.Scripts.Delete = {

#Export settings for the next time the UI is loaded (to pre populate the textboxes).
     Export-Clixml -Path "$($ProfileDeleteX.WorkingDirectory)\$($ProfileDeleteX.ScriptName).xml" -InputObject @{
        Textbox1 = $ProfileDeleteX.Textbox1
    } #Export-Clixml

# 2 # Enable one of each (conn type, saveto, and output)
    #$UIMaster.ConnectionType = "Local_NoSvrs" # 
    #$UIMaster.ConnectionType = "Local_Svrs"   # 
    $UIMaster.ConnectionType = "AsJob"
    #$UIMaster.SaveToFile     = $false # we are saving the file inside the $Script...since local run
    #$UIMaster.OutputTab      = $true # [$true|$false]

# 3 # Create the console message for this script.
    $SubScriptMessage = "$(($ProfileDeleteX.ScriptName) -replace ".ps1") - Delete Profile(s)"

# 4 # $ArgumentList - only use if you need to pass variables inside the $script = {}
    [string[]]$userListx = $ProfileDeleteX.Textbox1 -split "`r`n" |
        ForEach-Object Trim | ?{ $_ -ne "" } | Select-Object -Unique

    $ArgumentList = $userListx #,$arg2
    
# 5 #1. $Script - this is what gets run on the remote server (for AsJob) ... or run locally for "Local_" ConnectionType.
    $Script = Convert-ScriptOutputToText{ #Convert-ScriptOutputToText - remove this for non-text output (table)
        Param([string[]]$userListx) #Param([Int]$arg1,[string[]]$arg2,[Array]$arg3,[object[]]$arg4,[System.Management.Automation.PSCredential]$Cred,$arg6,$arg7)
        
        ### Start section #################################################################################
       ###       Change this section to modify the command that is run on each remote server           ###
        #$errorActionPreference = "SilentlyContinue"        
        $objs = @()
        foreach($userx in $userListx){
            # Determining the SID for a Local User Account
            $objUser = New-Object System.Security.Principal.NTAccount($userx)

            # get the SID for the given Username
            $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
            $Sidx = "$($strSID.Value)"

            ###############################
            # exit the scriptblock on error
            if ($error[0] -ne $null){ # "Error translating $($userx) to SID"
                $obj = New-Object PSObject
                $obj | Add-Member -MemberType NoteProperty -Name "Username"             -Value "$($userx)"
                $obj | Add-Member -MemberType NoteProperty -Name "Profile path"         -Value "N/A"
                $obj | Add-Member -MemberType NoteProperty -Name "Active Directory SID" -Value "$error[0]"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry SID"         -Value "N/A"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry Guid"        -Value "N/A"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry SID.bak"     -Value "N/A"
                $obj | Add-Member -MemberType NoteProperty -Name "Win32_UserProfile"    -Value "N/A"
                $objs += $obj
                $error.clear() # reset the error variable for continued use 
            } else {

                ##########
                # get the profile path from the registry (C:\Users\ProfileName)
                $ProfileList_ProfileImagePath = `
                Get-ItemProperty "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx)" | `
                select -expandproperty ProfileImagePath
                #return error information about this profile path
                if ($error[0] -eq $null){ # no error
                    $ImagePathx = "$($ProfileList_ProfileImagePath)"
                    $RegSid = "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx)"
                } else { # error
                    $ImagePathx = "Profile path not found for $($userx)"
                    $RegSid = "Not found HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx)"
                    $error.clear() # reset the error variable for continued use        
                } #if
                $ProfileList_ProfileImagePath = $null

                ##########
                # get the profile reg Guid = {08270434-9525-4ed2-92f6-30bdd4ffb6dc}
                $ProfileList_Guid = `
                Get-ItemProperty "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx)" | `
                select -expandproperty Guid
                #return error information about this ProfileList Guid
                if ($error[0] -eq $null){ # no error
                    $Guidx = "$($ProfileList_Guid)"
                } else { # error
                    $Guidx = "Not foundReg ProfileList Guid for $($userx)"
                    $error.clear() # reset the error variable for continued use        
                } #if
                $ProfileList_Guid = $null

                ##########
                # get the profile reg SID.bak (S-1-5-21-1123561945-1708537768-1801674531-2116751.bak)
                $ProfileList_Guid_bak = `
                Get-ItemProperty "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx).bak" | `
                select -expandproperty Guid
                #return error information about this ProfileList Guid
                if ($error[0] -eq $null){ # no error
                    # Found "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\Sid.bak"
                    $SidBak = "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx).bak"
                } else { # error
                    $SidBak = "Not found HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($Sidx).bak"
                    $error.clear() # reset the error variable for continued use
                } #if
                $ProfileList_Guid_bak = $null

                ##########
                # get the profile reg SID (S-1-5-21-1123561945-1708537768-1801674531-2116751)
                $ProfileGuid_SidString = `
                Get-ItemProperty "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid\$($Guidx)" | `
                select -expandproperty SidString
                #return error information about this ProfileGuid
                if ($error[0] -eq $null){ # no error
                    # Found "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid\$($Guidx)"
                    $SidGuidx = "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid\$($Guidx)"
                } else { # error
                    $SidGuidx = "Not found HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid\ ...for $($userx)"
                    $error.clear() # reset the error variable for continued use
                } #if
                $ProfileGuid_SidString = $null

                ##########
                # get the Win32_UserProfile
                $UserProfile1 = Get-WmiObject -Class Win32_UserProfile -Filter "LocalPath='c:\\Users\\$($objUser)'"
                #return error information about this Win32_UserProfile
                if ($UserProfile1 -ne $null){ # no error
                    ################################################
                    # This will delete the profile from the registry and also the folder (c:\users\username)
                    # sometimes the folder does not delete
                    $UserProfile1.Delete()
                    # The next few commands will manually delete the profile items if still present
                    ################################################
                } else { # error
                    $UserProfile1 = "Win32_UserProfile not found for $($userx)"
                    $error.clear() # reset the error variable for continued use
                } #if

                # This will remove a registry subkey from "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid"
                Push-Location
                Set-Location "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileGuid"
                #Test-Path "{08270434-9525-4ed2-92f6-30bdd4ffb6dc}"
                if (Test-Path "$($Guidx)"){ # delete the registry key
                    Remove-Item "$($Guidx)"
                } #if
                Pop-Location

                # This will remove a registry subkey from "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList"
                Push-Location
                Set-Location "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList"
                #Test-Path "S-1-5-21-1123561945-1708537768-1801674531-2116751"
                if (Test-Path "$($Sidx)"){ # delete the registry key
                    Remove-Item "$($Sidx)"
                } #if
                Pop-Location

                # This will remove a registry subkey from "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList"
                Push-Location
                Set-Location "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList"
                #Test-Path "S-1-5-21-1123561945-1708537768-1801674531-2116751.bak"
                if (Test-Path "$($Sidx).bak"){ # delete the registry key
                    Remove-Item "$($Sidx).bak"
                } #if
                Pop-Location

                # This will delete the profile folder directly - incase the above command fails to remove the folder
                if (Test-Path "$($ImagePathx)"){
                    Remove-Item -Recurse -Force "$($ImagePathx)"
                } #if

                # This will delete TEMP* user profile folders if not currently in use
                if (Test-Path "c:\users"){
                    Remove-Item -Recurse -Force "c:\users\temp*"
                } #if

                $obj = New-Object PSObject
                $obj | Add-Member -MemberType NoteProperty -Name "Username"             -Value "$($userx)"
                $obj | Add-Member -MemberType NoteProperty -Name "Profile path"         -Value "$($ImagePathx)"
                $obj | Add-Member -MemberType NoteProperty -Name "Active Directory SID" -Value "$($Sidx)"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry SID"         -Value "$($RegSid)"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry Guid"        -Value "$($SidGuidx)"
                $obj | Add-Member -MemberType NoteProperty -Name "Registry SID.bak"     -Value "$($SidBak)"
                $obj | Add-Member -MemberType NoteProperty -Name "Win32_UserProfile"    -Value "$($UserProfile1)"
                $objs += $obj
                $error.clear()
            } #else
        } #for
        Return $objs
        # (optional) This will rename a registry key
        # Rename-Item -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\ProfileList\$($strSID.Value)" -NewName "$($strSID.Value).old"

        ### End section ###################################################################################
        ###       Change this section to modify the command that is run on each remote server           ###
        ###################################################################################################
    } #script

    # or 2.
    #$remoteCommand = $ProfileDeleteX.Textbox # get the textbox contents...Change this as needed.
    #$scriptBlock1 = [Scriptblock]::Create($remoteCommand) # convert the text to scriptblock
    #$scriptBlock = $scriptBlock1               # No change to convert output to table
    # or
    #$scriptBlock = Convert-ScriptOutputToText $scriptBlock1 # convert output to text

    # or 3.

    # Call the $UIMaster.Scripts.RunScriptBlock
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList #-SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .Run
#endregion
#------------------------------------------------------
#region - UI Data Loading...
# Read in the script settings file and populate the textbox.
try {
    $SettingsClixml = Import-Clixml "$($ProfileDeleteX.WorkingDirectory)\$($ProfileDeleteX.ScriptName).xml" -ErrorAction Stop
    $list = 'Textbox1' #,'Textbox2'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $ProfileDeleteX.$setting = $SettingsClixml.$setting } # will update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $ProfileDeleteX {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 10,10,0,0 -Foreground Blue -FontWeight Bold
            New-UITextBlock "Delete profile(s) on remote ServerList:" -FontWeight Bold -Margin 20,10,0,0 -AlsoSet @{FontSize=18} -Foreground blue
            New-UITextBlock "One Username per line in the textbox." -Margin 20,20,0,0 -AlsoSet @{FontSize=14}
            New-UITextBlock "The profile is removed from the registry and the profile path is deleted." -Margin 20,0,0,0 -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal {
                New-UITextBox -Width 100 -Height 200 -Margin 20,20,0,0 -AcceptsReturn $true `
                    -VerticalScrollBarVisibility Visible -HorizontalScrollBarVisibility Visible `
                    -BindTextTo Textbox1
                New-UIButton "Run" -Padding 14,4,14,6 -Align TopLeft -Margin 10,20,0,0 -Foreground Red -AlsoSet @{FontSize=14}`
                    -AddClick $ProfileDeleteX.Scripts.Delete
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 10,30,0,0 -Foreground Blue -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 