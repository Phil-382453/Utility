﻿<#
.SYNOPSIS 
    Get list of installed software - Works best for small number of servers (1 or 2)
.ROLE
    Software
.FUNCTIONALITY
    Add-Remove,installed,Software_Installed,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$enUS = [System.Globalization.CultureInfo]'en-US'           

$getSoftwareNameScript = {
                
    if ($_.DisplayName)
    {
        trap [System.FormatException] { continue }
        $installDate = $null
        $installDate = [datetime]::ParseExact($_.InstallDate, 'yyyyMMdd', $enUS)
        $result = New-Object System.Collections.Specialized.OrderedDictionary
        $result.ComputerName = $env:COMPUTERNAME
        $result.Name = $_.DisplayName
        $result.Version = $_.DisplayVersion
        $result.UninstallString = $_.UninstallString
        $result.InstallDate = $installDate
        #$result.Publisher = $_.Publisher
        #$result.Comments = $_.Comments -replace "\r\n", " "
                    
        New-Object -TypeName PSCustomObject -Property $result
    }
}

$whereFilter = {
  (-not($_.Name -like "Update*" -or $_.Name -like "Service Pack*" -or `
        $_.Name -like "Security Update*"-or $_.Name -like '' -or $_.Name -like $null))
}

$native = $null
$wow6432 = $null

$native = Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall -ErrorAction SilentlyContinue |
    Get-ItemProperty |
    ForEach-Object $getSoftwareNameScript

$wow6432 = Get-ChildItem HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall -ErrorAction SilentlyContinue |
    Get-ItemProperty |
    ForEach-Object $getSoftwareNameScript

if ($wow6432)
{
    & {
        $native | Select-Object ComputerName,Name,InstallDate,Version,@{Name='Bit'; Expression={64}},UninstallString,Publisher
        $wow6432 | Select-Object ComputerName,Name,InstallDate,Version,@{Name='Bit'; Expression={32}},UninstallString,Publisher
    } | Where $whereFilter | Sort-Object Name, Version

}
else
{

    $native | Select-Object ComputerName,Name,InstallDate,Version,@{Name='Bit'; Expression={32}},UninstallString,Publisher |
        Where $whereFilter | Sort-Object Name, Version
}