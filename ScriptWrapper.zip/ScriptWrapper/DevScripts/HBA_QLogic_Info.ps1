﻿<#
.SYNOPSIS  
    This script will run QConvergeConsole CLI cmds on remote server(s)
.ROLE
    SAN
.FUNCTIONALITY
    HBA,SAN,Drives,Disks,Qlogic,Text
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Text
#>
"cmd = qaucli -pr fc -g"
qaucli -pr fc -g
$x1 = qaucli -pr fc -g
# collect each HBA instance number into $array
foreach ($line in $x1){ if($line -like "*HBA instance *"){ [string[]]$array += (($line.split(')'))[0]).split()[-1] } }

# collect HBA instance information
foreach($instance in $array){
    [string[]]$x2 += qaucli -pr fc -l $instance
}
foreach($line in $x2){
    $line -replace "Instance","Instance(port)"
    #if($line -match [regex]"HBA Instance \d"){$line} else {$line}
}

"================================="
"cmd = qaucli -pr fc -c"
""
qaucli -pr fc -c
"================================="
"cmd = qaucli -pr fc -i"
""
qaucli -pr fc -i
"================================="