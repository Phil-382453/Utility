<#
.SYNOPSIS
    (NewScript) For OS patch compliance validation.
.ROLE
    Utility
.FUNCTIONALITY
    Patching,Hotfix,Table,NewScript
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    Table
#>
# Everything past this point is treated as a scriptblock .. and sent to your list of servers .. for remote execution.

$updateSession = New-Object -ComObject "Microsoft.Update.Session"
$searchResults = $updateSession.CreateUpdateSearcher().Search("IsInstalled=0")

$template = '' | Select-Object ComputerName,UpdateTitle,UpdateKB,SecurityBulletin,IsDownloaded,UpdateUrl
$template.ComputerName = $env:ComputerName

for ($i = 0; $i -lt $searchResults.Updates.Count; $i++){
    $update = $searchResults.Updates.Item($i)
    $result = $template | Select-Object *
    $result.UpdateTitle      = $update.Title
    $result.UpdateKB         = $($update.KBArticleIDs)
    $result.SecurityBulletin = $($update.SecurityBulletinIDs)
    $result.IsDownloaded     = $update.IsDownloaded
    $result.UpdateUrl        = $($update.MoreInfoUrls)
    $result
} #for

if ($searchResults.Updates.Count -eq 0){
    $result = $template | Select-Object *
    $result.UpdateTitle = "(No Required Updates)"
    $result

} #if