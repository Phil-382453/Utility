﻿<#
.SYNOPSIS  
    Collect remote access card info for a list of servers (table/csv output)
.ROLE
    OOB
.FUNCTIONALITY
    OOB,Manufacturer,HP,Dell,ilo,drac,remote,access,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$template = 1 | Select-Object ComputerName,Manufacturer,ipR,SubnetMaskR,GatewayR,NameR
$computerWmi = (gwmi Win32_ComputerSystem)

if ($computerWmi.Manufacturer -match "(HP|Hewlett Packard)"){
    $hponcfgPath =  "c:\progra~1\HP\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~1\hponcfg\hponcfg.exe",
                    "c:\progra~1\Hewlet~2\hponcfg\hponcfg.exe",
                    "c:\windows\tools\hponcfg.exe",
                    "c:\temp\hponcfg.exe" | 
                    Where-Object { Test-Path $_ } | Select-Object -First 1
        
    if (!$hponcfgPath) { # "HPONCFG NOT FOUND" 
        $Return = $template.PSObject.Copy()
        $Return.ComputerName = $env:COMPUTERNAME
        $Return.Manufacturer = $computerWmi.Manufacturer
        $Return.ipR = "HPONCFG NOT FOUND"
    }
    else {
        $nada = & $hponcfgPath /w "$($env:systemdrive)\temp\ILO.txt" # dump ilo config to text
        start-sleep -s 2 # sleep 2 seconds
        $iloFile1 = Get-Content "$($env:systemdrive)\temp\ILO.txt"
        $iloFile = $iloFile1 #| ConvertTo-Xml -As String
        if(!$iloFile){ # "HPONCFG NO OUTPUT" 
            $Return = $template.PSObject.Copy()
            $Return.ComputerName = $env:COMPUTERNAME
            $Return.Manufacturer = $computerWmi.Manufacturer
            $Return.ipR = "HPONCFG output file not found"
        }
        else{
            $Return = $template.PSObject.Copy() # create an object from template
            $Return.ComputerName = $env:COMPUTERNAME # populate the object properties
            $Return.Manufacturer = $computerWmi.Manufacturer
            foreach ($line in $iloFile){
                if(($line -like "*<IP_ADDRESS*")){ # IP Address
                    if($line -like "*=*"){ 
                        $Return.ipR = ($line.split("`""))[1] 
                        $nslookupx = & nslookup "$($Return.ipR)" | select -last 3 | select -first 1 # keep only the name result
                        $temp = $nslookupx
                        $temp = ($temp.split(":"))[1]
                        $Return.NameR = $temp.Trim()
                    }
                    else{ $x = ($line.split(":"))[1] ; $Return.ipR = $x.Trim() } 
                } #if
                elseif($line -like "*<SUBNET_MASK*"){
                    if($line -like "*=*"){ $Return.SubnetMaskR = ($line.split("`""))[1] }
                    else{ $x = ($line.split(":"))[1] ; $Return.SubnetMaskR = $x.Trim() }
                } #elseif
                elseif($line -like "*<GATEWAY_IP_ADDRESS*"){
                    if($line -like "*=*"){ $x = ($line.split("`""))[1] ; $Return.GatewayR = $x }
                    else{ $x = ($line.split(":"))[1] ; $Return.GatewayR = $x.Trim() }
                } #elseif
            } #foreach
        } #else
    } #else
} #if
elseif ($computerWmi.Manufacturer -match "Dell") {
    $reportText = omreport.exe chassis remoteaccess
    if (!($reportText)) {
        $omreport =  "c:\progra~1\Dell\SysMgt\oma\bin\omreport.exe","" | Where-Object { Test-Path $_ } | Select-Object -First 1
    
        if ($omreport){ 
           $omreport =  $omreport -replace ("omreport.exe","")
            cd $omreport
            $reportText = .\omreport.exe chassis remoteaccess
        } #if
    } #if

    if (!$reportText) {
        $Return = $template.PSObject.Copy()
        $Return.ComputerName = $env:COMPUTERNAME
        $Return.Manufacturer = $computerWmi.Manufacturer
        $Return.ipR = "omreport.exe did not return output"
    } #if
    elseif ($reportText -like "*Error*") {
        $Return = $template.PSObject.Copy() # create an object from template
        $Return.ComputerName = $env:COMPUTERNAME # populate the object properties
        $Return.Manufacturer = $computerWmi.Manufacturer
        foreach ($line in $reportText){
            if ($line -like "*Error*") { $Return.ipR = "omreport.exe: $($line.Trim())" } #if
        } #foreach
    }
    else{
        $Return = $template.PSObject.Copy() # create an object from template
        $Return.ComputerName = $env:COMPUTERNAME # populate the object properties
        $Return.Manufacturer = $computerWmi.Manufacturer
        foreach ($line in $reportText){
            if($line -like "*IP?ADDRESS*"){ # IP Address
                if($line -like "*=*"){ $Return.ipR = ($line.split("`""))[1] }
                else{ $x = ($line.split(":"))[1] ; $Return.ipR = $x.Trim() }
                
                $nslookupx = & nslookup "$($Return.ipR)" | select -last 3 | select -first 1 # keep only the name result
                $temp = $nslookupx
                $temp = ($temp.split(":"))[1]
                $Return.NameR = $temp.Trim()
            } #if
            elseif($line -like "*SUBNET*"){
                if($line -like "*=*"){ $Return.SubnetMaskR = ($line.split("`""))[1] }
                else{ $x = ($line.split(":"))[1] ; $Return.SubnetMaskR = $x.Trim() }
            } #elseif
            elseif($line -like "*GATEWAY*"){
                if($line -like "*=*"){ $Return.GatewayR = ($line.split("`""))[1] }
                else{ $x = ($line.split(":"))[1] ; $Return.GatewayR = $x.Trim() }
            } #elseif
        } #foreach
    } #else
} #elseif
elseif ($computerWmi.Manufacturer -match "VMware"){
        $Return = $template.PSObject.Copy()
        $Return.ComputerName = $env:COMPUTERNAME
        $Return.Manufacturer = $computerWmi.Manufacturer
} #elseif

# return the output
$Return