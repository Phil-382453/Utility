﻿<#
.SYNOPSIS
    (Input tab) Query, Install, or Uninstall patches
.ROLE
    Operating System
.FUNCTIONALITY  
    patches,hotfix,install,uninstall,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$PatchesMaster = New-UIObject

$PatchesMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$PatchesMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$PatchesMaster.HotFixIDz = ""
$PatchesMaster.hotfixpath = "$($env:systemdrive)\temp"
$PatchesMaster.ModeQuery = $true
$PatchesMaster.ModeUninstall = $false
$PatchesMaster.ModeUninstallMaxCount = 5
$PatchesMaster.ModeInstall = $false
#endregion - Properties (Defaults) for Binding
#------------------------------------------------------
#region - UI Action Scripts
$PatchesMaster.Scripts = @{}
$PatchesMaster.Scripts.Run = {

    $HotFixIDz = ($PatchesMaster.HotFixIDz -split "`r`n") | ForEach-Object Trim | Where-Object { $_ } | Select-Object -Unique

    #Write-Host "$($PatchesMaster.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($PatchesMaster.WorkingDirectory)\$($PatchesMaster.ScriptName).xml" -InputObject @{
        HotFixIDz       = $PatchesMaster.HotFixIDz
        ModeQuery       = $PatchesMaster.ModeQuery
        ModeUninstall   = $PatchesMaster.ModeUninstall
        ModeInstall     = $PatchesMaster.ModeInstall
    } #Export-Clixml
    
    if ($PatchesMaster.ModeQuery) {

        $SubScriptMessage = "$(($PatchesMaster.ScriptName) -replace ".ps1") - Query" # create console subscript message
        $ArgumentList = $HotFixIDz

        $script = { # query script
            param ($HotFixIDz)
            $template1 = 1 | Select-Object HotfixID,Status,InstalledOn,InstalledBy
            $GetHotifx = Get-HotFix | Select-Object -Property HotfixID, InstalledOn, InstalledBy
            
            #$HotFixIDz = "KB9999999","KB3192137","KB4132216","KB4485447"
            if(($HotFixIDz -eq '*') -or ($HotFixIDz -eq $null)  -or ($HotFixIDz -eq '')){ # get all hotfixes if * or empty
                $GetHotifx | %{
                    $result = $template1.PSObject.Copy()
                    $result.HotfixID    = $_.HotfixID
                    $result.Status      = "Installed"
                    $result.InstalledOn = $_.InstalledOn
                    $result.InstalledBy = $_.InstalledBy 
                    return $result
                } #foreach
            } #if
            else { # get specific hotfixes
                $GetHotifx | %{
                    if ($_.HotfixID -in $HotFixIDz){
                        $result = $template1.PSObject.Copy()
                        $result.HotfixID    = $_.HotfixID
                        $result.Status      = "Installed"
                        $result.InstalledOn = $_.InstalledOn
                        $result.InstalledBy = $_.InstalledBy 
                        $result
                        [array]$results += $result
                    } #if
                } #foreach

                # list hotfixes not found
                $HotFixIDz | Where {$results.HotfixID -NotContains $_} | %{ 
                    $result = $template1.PSObject.Copy()
                    $result.HotfixID    = $_
                    $result.Status      = "Not found"
                    $result.InstalledOn = "N/A"
                    $result.InstalledBy = "N/A" 
                    $result
                } #foreach
            } #else
        } #script
        
        & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    }  #if
    elseif ($PatchesMaster.ModeUninstall) {
        # verify list of hotfixes
        if(($HotFixIDz -eq '*') -or ($HotFixIDz -eq $null)  -or ($HotFixIDz -eq '')){
            Write-Host "The Hotfix Name box cannot be empty or wildcard for uninstall patches." -f Red
            Return
        }
        else {$HotFixIDz_Uninstall = $null}
        
        $SubScriptMessage = "$(($PatchesMaster.ScriptName) -replace ".ps1") - Uninstall" # create console subscript message
        $ArgumentList = $HotFixIDz_Uninstall
                
        $script = {
            param ($HotFixIDz_Uninstall)

            #$HotFixIDz = "KB9999999","KB3192137","KB4132216","KB4485447"
            if(-not(($HotFixIDz -eq '*') -or ($HotFixIDz -eq $null)  -or ($HotFixIDz -eq ''))) { # get all hotfixes if * or empty
                $HotFixIDz_Uninstall = $HotFixIDz | select -first $PatchesMaster.ModeUninstallMaxCount
            }
            # Do uninstall script
            foreach($hotfix in $HotFixIDz_Uninstall){
                $hotfixUninstall = $hotfix -replace ('KB','/KB:')
                [array]$objs += Start-Process wusa.exe -ArgumentList "$($hotfixUninstall) /uninstall /quiet /norestart" -Wait
            } #for
        } #script

        & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    } #else
    elseif ($PatchesMaster.ModeInstall) {
        
        $SubScriptMessage = "$(($PatchesMaster.ScriptName) -replace ".ps1") - Install" # create console subscript message
        $ArgumentList = $PatchesMaster.hotfixpath
        
        $script = {
            param ($hotfixpath)
            # Do Install script
            foreach($hotfix in $hotfixpath){
                if (!(Test-Path "$($hotfix)")){return "$($PatchesMaster.hotfixpath)\$($hotfix) Not found"} # Verify 
            } #foreach
            foreach($hotfix in $HotFixIDz){
                $install = Start-Process wusa.exe -ArgumentList "$($PatchesMaster.hotfixpath)\$($hotfix) /quiet /norestart" -Wait
            } #foreach
        }

        & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    } #else
}.GetNewClosure() # .Run1
#endregion
#------------------------------------------------------
#region - UI Data Loading
# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($PatchesMaster.WorkingDirectory)\$($ServicesMaster.ScriptName).xml" -ErrorAction Stop
    $list1 = 'HotFixIDz','ModeQuery','ModeUninstall','ModeInstall'

    # populate controls from cache
    foreach ($setting in $list1) {
        if ($SettingsClixml.Contains($setting)) { $ServicesMaster.$setting = $SettingsClixml.$setting }
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $PatchesMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 14,10,0,0 -FontWeight Bold
            New-UITextBlock "Query:" -FontWeight Bold -Margin 14,6,4,0
            New-UITextBlock "Enter one or more Hotfix ID's into the Hotfix Name box (One per line)." -Margin 20,6,4,0
            New-UITextBlock "Blank or * to Query all." -Margin 20,6,4,0
            New-UITextBlock "" -Margin 14,6,4,0
            New-UITextBlock "Uninstall:" -FontWeight Bold -Margin 14,6,4,0
            New-UITextBlock "Enter one or more Hotfix ID's into the Hotfix Name box (One per line)." -Margin 20,6,4,0
            New-UITextBlock "Only the first 5 Hotfix ID's are used. Extras are ignored." -Margin 20,6,4,0
            New-UITextBlock "cmd = Start-Process wusa.exe -ArgumentList 'hotfixUninstall' /uninstall /quiet /norestart" -Margin 20,6,4,0
            New-UITextBlock "" -Margin 14,6,4,0
            New-UITextBlock "Install:" -FontWeight Bold -Margin 14,6,4,0
            New-UITextBlock "Copy the hotfix install file to each server." -Margin 20,6,4,0
            New-UITextBlock "In the Install Hotfix Location Box, enter the local path including the name of the hotfix install file." -Margin 20,6,4,0
            New-UITextBlock "The 'Hotfix Name' box is ignored during installs." -Margin 20,6,4,0
            New-UITextBlock "Install is limited to one Hotfix." -Margin 20,6,4,0
            New-UITextBlock "cmd = Start-Process wusa.exe -ArgumentList 'hotfixpath\hotfixfile' /quiet /norestart" -Margin 20,6,4,0
            New-UITextBlock "" -Margin 20,6,4,0

            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical -Margin 14,0,0,0 {
                    New-UITextBlock "Hotfix Name (one per line)" -FontWeight Bold -Margin 4,6,4,0
                    New-UITextBox -AcceptsReturn $true -BindTextTo HotFixIDz -Align TopLeft -Width 200 -Height 100 -Margin 4,10,4,0
                } #StackPanel
                New-UIStackPanel -Orientation Vertical -Margin 14,0,0,0 {
                    New-UITextBlock "Action:" -FontWeight Bold -Margin 4,6,4,0
                    New-UIRadioButton "Query Hotfix"     -Margin 14,10,4,0 -BindIsCheckedTo ModeQuery
                    New-UIRadioButton "Uninstall Hotfix" -Margin 14,6,4,0  -BindIsCheckedTo ModeUninstall -foreground "Red"
                    New-UIRadioButton "Install Hotfix"   -Margin 14,6,4,0  -BindIsCheckedTo ModeInstall -foreground "Red"
                } #StackPanel
                New-UIStackPanel -Orientation Vertical -Margin 14,0,0,0 {
                    New-UIButton "Run" -Margin 10,10,0,10 -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $PatchesMaster.Scripts.Run
                } #StackPanel

            } #StackPanel
            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical -Margin 14,6,4,0 {
                    New-UITextBlock "Install Hotfix Location (path and filename)" -FontWeight Bold -Margin 4,6,4,0
                    New-UITextBox -AcceptsReturn $true -Width 200 -Height 100 -Align TopLeft -Margin 4,10,4,0 -BindTextTo hotfixpath
                } #StackPanel
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion - UI
#------------------------------------------------------
# PowerShell script complete