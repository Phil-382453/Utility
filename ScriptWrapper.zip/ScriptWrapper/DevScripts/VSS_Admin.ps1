﻿<#
.SYNOPSIS
    (Input tab) Provide a user interface for VSSadmin cmds (List, Add, Delete, Resize). 
.ROLE
    Backup
.FUNCTIONALITY  
    Vss,Shadow,Storage,disk,drive,backup,space,free,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$VssMaster = New-UIObject
$VssMaster.ScriptName       = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$VssMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$VssMaster.RadioList        = $true
$VssMaster.RadioAdd         = $false
$VssMaster.RadioDelete      = $false
$VssMaster.RadioResize      = $false
$VssMaster.For              = "*"
$VssMaster.On               = ""
$VssMaster.Max              = ""
$VssMaster.Min              = [uint64]30Gb
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$VssMaster.Scripts = @{}
$VssMaster.Scripts.List   = {
#$VssMaster.Scripts.Run   = {
    #if($VssMaster.RadioList)  {
        # Export settings for the next time the UI is loaded
        Export-Clixml -Path "$($VssMaster.WorkingDirectory)\$($VssMaster.ScriptName).xml" -InputObject @{
            RadioList   = $VssMaster.RadioList
            For         = $VssMaster.For
            On          = $VssMaster.On
            Max         = $VssMaster.Max
        } #Export-Clixml

        $SubScriptMessage = "$(($VssMaster.ScriptName) -replace ".ps1") - List ShadowStorage" # create console subscript message
        $ArgumentList     = $VssMaster.For,$VssMaster.On
        $Script = {
            Param($for,$on)

            # Filter
            Filter ConvertTo-KMG {
                    $bytecount = $_
                    switch ([math]::truncate([math]::log($bytecount,1024))) {
                        0 {"$bytecount Bytes"}
                        1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                        2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                        3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                        4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                        5 {"{0:n2} PB" -f ($bytecount / 1pb)}
                    } #switch
            } #filter
            
            # We are defining a new object and its properties...will be used to create a custom powershell object later.
            $template = 1 | Select-Object ComputerName, For, On, "AllocatedSpace(On)", "AllocatedPercent(On)", "UsedSpace(On)", 
                                            "MaxSpace(On)", "MaxSpace(On)", "MaxPercent(On)", "Capacity(On)"
            $template.ComputerName = $env:COMPUTERNAME
            $hasShadowStorage = $false # variable to track if shadowstorage exists.

            # We are creating a hash table to cross reference Win32_Volume and Win32_ShadowStorage
            # The matching entry in these different objects is => Win32_Volume.__RELPATH = Win32_ShadowStorage.Volume
                    
            # Win32_Volume properties include => __RELPATH, __PATH, Capacity, DeviceID, DriveLetter, FreeSpace, Name
            $volumePathToVolume = @{}
            Get-WmiObject Win32_Volume |
                %{ $volumePathToVolume[$_.__RELPATH] = $_ } # Foreach volume (name = Win32_Volume.__RELPATH, Value = Win32_Volume "object with properties")


            # Win32_ShadowStorage properties include => __RELPATH, __PATH, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace, Volume
            $ErrorActionPreference = 'SilentlyContinue'
            
            $Win32_ShadowStorage = Get-WmiObject Win32_ShadowStorage

            ForEach($ShadowStoragex in $Win32_ShadowStorage){
                $hasShadowStorage = $true # shadow storage exists
                $forVolume = $volumePathToVolume[$ShadowStoragex.Volume] # $forVolume contains the matching (full) object from Win32_Volume
                $onVolume = $volumePathToVolume[$ShadowStoragex.DiffVolume]
                $result = $template.PSObject.Copy()
                $result.For = $forVolume.Name
                $result.On = $onVolume.Name
                $result."AllocatedSpace(On)" = $ShadowStoragex.AllocatedSpace
                $result."AllocatedPercent(On)" = [Math]::Round(($ShadowStoragex.AllocatedSpace/$onVolume.Capacity)*100,0)
                $result."UsedSpace(On)" = $ShadowStoragex.UsedSpace
                $result."MaxSpace(On)" = [Math]::Round(($ShadowStoragex.UsedSpace/$onVolume.Capacity)*100,0)
                $result."MaxSpace(On)" = $ShadowStoragex.MaxSpace
                $result."MaxPercent(On)" = [Math]::Round(($ShadowStoragex.MaxSpace/$onVolume.Capacity)*100,0)
                if ($result."MaxSpace(On)" -eq [uint64]::MaxValue){
                    $result."MaxSpace(On)" = 'Unlimited'
                    $result."MaxPercent(On)" = 100
                } #if
                if($result."AllocatedSpace(On)"){$result."AllocatedSpace(On)" = ($ShadowStoragex.AllocatedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."AllocatedSpace(On)"){$result."UsedSpace(On)" = ($ShadowStoragex.UsedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."MaxSpace(On)" -ne 'Unlimited'){$result."MaxSpace(On)" = ($ShadowStoragex.MaxSpace) | ConvertTo-KMG}
                $result."Capacity(On)" = ($onVolume.Capacity) | ConvertTo-KMG
                $result
            } #foreach

            if (!$hasShadowStorage){
                $template.For = 'No VSS'
                $template
            } #if
        } #script
    #} #if
        & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$VssMaster.Scripts.Add    = {
    #if($VssMaster.RadioAdd)   {
        if($VssMaster.For -eq ""){
            Show-UIMessageBox -Message "The /For= box is empty. Please try again."
            return
        }
        elseif(($VssMaster.For -eq '*') -and ($VssMaster.On)){
            $VssMaster.On = "" # will be setting On=For
            $VssMaster.Max = "10%"
        } #if

        # Export settings for the next time the UI is loaded
        Export-Clixml -Path "$($VssMaster.WorkingDirectory)\$($VssMaster.ScriptName).xml" -InputObject @{
            RadioAdd    = $VssMaster.RadioAdd
            For         = $VssMaster.For
            On          = $VssMaster.On
            Max         = $VssMaster.Max
        } #Export-Clixml

        $SubScriptMessage = "$(($VssMaster.ScriptName) -replace ".ps1") - Add ShadowStorage" # create console subscript message
        $ArgumentList     = $VssMaster.For,$VssMaster.On,$VssMaster.Max,$VssMaster.Min
        $Script = {
                Param($for,$on,$max,$min)

                $hostname = $env:COMPUTERNAME # collect the local hostname

                ###################
                # To be used if % causes error ( either single disk or AllDrives )
                if($max -like "*%*") { $MaxSize1 = ([int]($max.TrimEnd("%")))/100}
                else                  { $MaxSize1 =        $max} # else $MaxSize -like xxGb
            
                ###################
                $diskx = @{}
                $logicalDisk1 = Get-CimInstance –ClassName Win32_logicaldisk -Filter “MediaType = 12" | select DeviceID,Size,FreeSpace
                $logicalDisk1 | %{$diskx[$_.DeviceID] = $_}

                ##########################
                # Add /For= /On= /Maxsize=
                if("$($for)" -eq '*'){
                    $max = '10%'
                    $logicalDisk1 | %{
                        $Size = ($diskx["$($_.DeviceID)"]).Size
                        if($Size -gt $min){
                            $null = vssadmin Add ShadowStorage /For="$($_.DeviceID)" /On="$($_.DeviceID)" /MaxSize="$($max)"
                        } #if
                    } #%

                    if (($x -like "*Error*") -and ($max -like "*%*")) { #if % caused error...use calculated %
                        $null = $logicalDisk1 | vssadmin Add ShadowStorage /For="$($_.DeviceID)" /On="$($_.DeviceID)" /MaxSize="$([int]($_.size/10))"
                    } #for
                }
                elseif($on){
                    $Size = ($diskx["$($on)`:"]).Size 
                    if($Size -gt $min){
                        $x = vssadmin Add ShadowStorage /For="$($for)`:" /On="$($on)`:" /MaxSize="$($max)"
                    } #if
                    else{"Disk capacity smaller than hardcoded minimun"}
                } # MaxSize can be either % or not
                elseif($for){
                    $Size = ($diskx["$($for)`:"]).Size
                    if($Size -gt $min){
                        $x = vssadmin Add ShadowStorage /For="$($for)`:" /On="$($for)`:"  /MaxSize="$($max)"
                    } #if
                    else{"Disk capacity smaller than hardcoded minimun"}
                } #else

                ##############
                # verification - vssadmin list shadowstorage

                # Filter
                Filter ConvertTo-KMG {
                        $bytecount = $_
                        switch ([math]::truncate([math]::log($bytecount,1024))) {
                            0 {"$bytecount Bytes"}
                            1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                            2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                            3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                            4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                            5 {"{0:n2} PB" -f ($bytecount / 1pb)}
                        } #switch
                } #filter
            
                # We are defining a new object and its properties...will be used to create a custom powershell object later.
                $template = 1 | Select-Object ComputerName, For, On, "AllocatedSpace(On)", "AllocatedPercent(On)", "UsedSpace(On)", 
                                                "MaxSpace(On)", "MaxSpace(On)", "MaxPercent(On)", "Capacity(On)"
                $template.ComputerName = $env:COMPUTERNAME
                $hasShadowStorage = $false # variable to track if shadowstorage exists.

                # We are creating a hash table to cross reference Win32_Volume and Win32_ShadowStorage
                # The matching entry in these different objects is => Win32_Volume.__RELPATH = Win32_ShadowStorage.Volume
                    
                # Win32_Volume properties include => __RELPATH, __PATH, Capacity, DeviceID, DriveLetter, FreeSpace, Name
                $volumePathToVolume = @{}
                Get-WmiObject Win32_Volume |
                    %{ $volumePathToVolume[$_.__RELPATH] = $_ } # Foreach volume (name = Win32_Volume.__RELPATH, Value = Win32_Volume "object with properties")


                # Win32_ShadowStorage properties include => __RELPATH, __PATH, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace, Volume
                $ErrorActionPreference = 'SilentlyContinue'
            
                $Win32_ShadowStorage = Get-WmiObject Win32_ShadowStorage

                ForEach($ShadowStoragex in $Win32_ShadowStorage){
                    $hasShadowStorage = $true # shadow storage exists
                    $forVolume = $volumePathToVolume[$ShadowStoragex.Volume] # $forVolume contains the matching (full) object from Win32_Volume
                    $onVolume = $volumePathToVolume[$ShadowStoragex.DiffVolume]
                    $result = $template.PSObject.Copy()
                    $result.For = $forVolume.Name
                    $result.On = $onVolume.Name
                    $result."AllocatedSpace(On)" = $ShadowStoragex.AllocatedSpace
                    $result."AllocatedPercent(On)" = [Math]::Round(($ShadowStoragex.AllocatedSpace/$onVolume.Capacity)*100,0)
                    $result."UsedSpace(On)" = $ShadowStoragex.UsedSpace
                    $result."MaxSpace(On)" = [Math]::Round(($ShadowStoragex.UsedSpace/$onVolume.Capacity)*100,0)
                    $result."MaxSpace(On)" = $ShadowStoragex.MaxSpace
                    $result."MaxPercent(On)" = [Math]::Round(($ShadowStoragex.MaxSpace/$onVolume.Capacity)*100,0)
                    if ($result."MaxSpace(On)" -eq [uint64]::MaxValue){
                        $result."MaxSpace(On)" = 'Unlimited'
                        $result."MaxPercent(On)" = 100
                    } #if
                    if($result."AllocatedSpace(On)"){$result."AllocatedSpace(On)" = ($ShadowStoragex.AllocatedSpace) | ConvertTo-KMG}
                    else {$result."AllocatedSpace(On)" = 0}
                    if($result."AllocatedSpace(On)"){$result."UsedSpace(On)" = ($ShadowStoragex.UsedSpace) | ConvertTo-KMG}
                    else {$result."AllocatedSpace(On)" = 0}
                    if($result."MaxSpace(On)" -ne 'Unlimited'){$result."MaxSpace(On)" = ($ShadowStoragex.MaxSpace) | ConvertTo-KMG}
                    $result."Capacity(On)" = ($onVolume.Capacity) | ConvertTo-KMG
                    $result
                } #foreach

                if (!$hasShadowStorage){
                    $template.For = 'No VSS'
                    $template
                } #if
        } #script
    #} #if
        & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$VssMaster.Scripts.Delete = {
    #if($VssMaster.RadioDelete){
        if($VssMaster.For -eq ""){
            Show-UIMessageBox -Message "The /For= is empty. Please try again."
            return
        }
        elseif($VssMaster.For -eq '*'){
            $VssMaster.On = ""
        } #if

        # Export settings for the next time the UI is loaded
        Export-Clixml -Path "$($VssMaster.WorkingDirectory)\$($VssMaster.ScriptName).xml" -InputObject @{
            RadioDelete = $VssMaster.RadioDelete
            For         = $VssMaster.For
            On          = $VssMaster.On
            Max         = $VssMaster.Max
        } #Export-Clixml

        $SubScriptMessage = "** Delete  ShadowStorage" # create console subscript message
        $ArgumentList     =  $VssMaster.For,$VssMaster.On
        $Script = { 
            Param($for,$on)
            
            $ErrorActionPreference = 'SilentlyContinue'
            $diskx = @{}
            $logicalDisk1 = Get-CimInstance –ClassName Win32_logicaldisk -Filter “MediaType = 12" | select DeviceID,Size,FreeSpace
            $logicalDisk1 | %{$diskx[$_.DeviceID] = $_}
            if("$($for)" -eq '*'){
                $logicalDisk1 | %{
                    Force Windows to dump any associated VSS Shadows and Orphaned Shadows.
                    $null = vssadmin Resize ShadowStorage /For="$($_.DeviceID)" /On="$($_.DeviceID)" /MaxSize=320MB
                    $null = vssadmin Delete shadowstorage /For="$($_.DeviceID)" /On="$($_.DeviceID)"
                    $null = vssadmin Resize ShadowStorage /For="$($_.DeviceID)" /On="$($_.DeviceID)" /MaxSize=300MB
                    $null = vssadmin Delete shadowstorage /For="$($_.DeviceID)" /On="$($_.DeviceID)" 
                } #%
            } #if
            elseif(($for) -and ($on)){
                #Force Windows to dump any associated VSS Shadows and Orphaned Shadows.
                $null = vssadmin Resize ShadowStorage /For="$($for)`:" /On="$($on)`:" /MaxSize=320MB
                $null = vssadmin Delete shadowstorage /For="$($for)`:" /On="$($on)`:"
                $null = vssadmin Resize ShadowStorage /For="$($for)`:" /On="$($on)`:" /MaxSize=300MB
                $null = vssadmin Delete shadowstorage /For="$($for)`:" /On="$($on)`:" 
            } #if
            $ErrorActionPreference = 'Continue'

            ##############
            # verification - vssadmin list shadowstorage
            $vssadmin = @()

            # Filter
            Filter ConvertTo-KMG {
                    $bytecount = $_
                    switch ([math]::truncate([math]::log($bytecount,1024))) {
                        0 {"$bytecount Bytes"}
                        1 {"{0:n2} KB" -f ($bytecount / 1kb)}
                        2 {"{0:n2} MB" -f ($bytecount / 1mb)}
                        3 {"{0:n2} GB" -f ($bytecount / 1gb)}
                        4 {"{0:n2} TB" -f ($bytecount / 1tb)}
                        5 {"{0:n2} PB" -f ($bytecount / 1pb)}
                    } #switch
            } #filter
            
            # We are defining a new object and its properties...will be used to create a custom powershell object later.
            $template = 1 | Select-Object ComputerName, For, On, "AllocatedSpace(On)", "AllocatedPercent(On)", "UsedSpace(On)", 
                                            "MaxSpace(On)", "MaxSpace(On)", "MaxPercent(On)", "Capacity(On)"
            $template.ComputerName = $env:COMPUTERNAME
            $hasShadowStorage = $false # variable to track if shadowstorage exists.

            # We are creating a hash table to cross reference Win32_Volume and Win32_ShadowStorage
            # The matching entry in these different objects is => Win32_Volume.__RELPATH = Win32_ShadowStorage.Volume
                    
            # Win32_Volume properties include => __RELPATH, __PATH, Capacity, DeviceID, DriveLetter, FreeSpace, Name
            $volumePathToVolume = @{}
            Get-WmiObject Win32_Volume |
                %{ $volumePathToVolume[$_.__RELPATH] = $_ } # Foreach volume (name = Win32_Volume.__RELPATH, Value = Win32_Volume "object with properties")


            # Win32_ShadowStorage properties include => __RELPATH, __PATH, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace, Volume
            $ErrorActionPreference = 'SilentlyContinue'
            
            $Win32_ShadowStorage = Get-WmiObject Win32_ShadowStorage

            ForEach($ShadowStoragex in $Win32_ShadowStorage){
                $hasShadowStorage = $true # shadow storage exists
                $forVolume = $volumePathToVolume[$ShadowStoragex.Volume] # $forVolume contains the matching (full) object from Win32_Volume
                $onVolume = $volumePathToVolume[$ShadowStoragex.DiffVolume]
                $result = $template.PSObject.Copy()
                $result.For = $forVolume.Name
                $result.On = $onVolume.Name
                $result."AllocatedSpace(On)" = $ShadowStoragex.AllocatedSpace
                $result."AllocatedPercent(On)" = [Math]::Round(($ShadowStoragex.AllocatedSpace/$onVolume.Capacity)*100,0)
                $result."UsedSpace(On)" = $ShadowStoragex.UsedSpace
                $result."MaxSpace(On)" = [Math]::Round(($ShadowStoragex.UsedSpace/$onVolume.Capacity)*100,0)
                $result."MaxSpace(On)" = $ShadowStoragex.MaxSpace
                $result."MaxPercent(On)" = [Math]::Round(($ShadowStoragex.MaxSpace/$onVolume.Capacity)*100,0)
                if ($result."MaxSpace(On)" -eq [uint64]::MaxValue){
                    $result."MaxSpace(On)" = 'Unlimited'
                    $result."MaxPercent(On)" = 100
                } #if
                if($result."AllocatedSpace(On)"){$result."AllocatedSpace(On)" = ($ShadowStoragex.AllocatedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."AllocatedSpace(On)"){$result."UsedSpace(On)" = ($ShadowStoragex.UsedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."MaxSpace(On)" -ne 'Unlimited'){$result."MaxSpace(On)" = ($ShadowStoragex.MaxSpace) | ConvertTo-KMG}
                $result."Capacity(On)" = ($onVolume.Capacity) | ConvertTo-KMG
                $result
            } #foreach

            if (!$hasShadowStorage){
                $template.For = 'No VSS'
                $template
            } #if
        } #script
    #} #if
        & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
$VssMaster.Scripts.Resize = {
    #if($VssMaster.RadioResize){
        # Export settings for the next time the UI is loaded
        Export-Clixml -Path "$($VssMaster.WorkingDirectory)\$($VssMaster.ScriptName).xml" -InputObject @{
            RadioResize = $VssMaster.RadioResize
            For         = $VssMaster.For
            On          = $VssMaster.On
            Max         = $VssMaster.Max
        } #Export-Clixml

        $SubScriptMessage = "** Resize ShadowStorage" # create console subscript message
        $ArgumentList     = $VssMaster.For,$VssMaster.On,$VssMaster.Max,$VssMaster.Min
        
        # $Script = Convert-ScriptOutputToText { # this will switch the output to text
        $Script = {
            Param($for,$on,$max,$min)

            $hostname = $env:COMPUTERNAME # collect the local hostname

            ###################
            # To be used if % causes error ( either single disk or AllDrives )
            if ($max -like "*%*") { $MaxSize1 = ([int]($max.TrimEnd("%")))/100}
            else                  { $MaxSize1 =        [int]$max} # else $MaxSize -like xxGb
            
            ###################
            $diskx = @{}
            $logicalDisk1 = Get-CimInstance –ClassName Win32_logicaldisk -Filter “MediaType = 12" | select DeviceID,Size,FreeSpace
            $logicalDisk1 | %{$diskx[$_.DeviceID] = $_}

            #####
            # Add $Size = ($diskx[$for]).size
            if($on){
                $Size = ($diskx["$($on)`:"]).Size

                if($Size -ge $min){
                    $x = vssadmin Resize ShadowStorage /For="$($for)`:" /On="$($on)`:" /Maxsize="$($max)"
                } #if
                else{"Disk capacity smaller than hardcoded minimun"}
            } #if
            elseif("$($for)" -eq '*'){
                foreach($disk in $logicalDisk1){
                    $Size = ($diskx["$($on)`:"]).size
                    if($Size -ge $min){
                        $x = vssadmin Resize ShadowStorage /For="$($disk.DeviceID)" /On="$($_.DeviceID):" /MaxSize="$($max)"
                    } #if
                    if ($x -like "*Error*") { #if % caused error...use calculated %
                        $null = $logicalDisk1 | vssadmin Resize ShadowStorage /For="$($_.DeviceID)" /On="$($_.DeviceID):" /MaxSize="$([int]($_.size*$MaxSize1))"
                    } #for
                } #for
            } #elseif

            ##############
            # verification - vssadmin list shadowstorage


            
            # We are defining a new object and its properties...will be used to create a custom powershell object later.
            $template = 1 | Select-Object ComputerName, For, On, "AllocatedSpace(On)", "AllocatedPercent(On)", "UsedSpace(On)", 
                                            "MaxSpace(On)", "MaxSpace(On)", "MaxPercent(On)", "Capacity(On)"
            $template.ComputerName = $env:COMPUTERNAME
            $hasShadowStorage = $false # variable to track if shadowstorage exists.

            # We are creating a hash table to cross reference Win32_Volume and Win32_ShadowStorage
            # The matching entry in these different objects is => Win32_Volume.__RELPATH = Win32_ShadowStorage.Volume
                    
            # Win32_Volume properties include => __RELPATH, __PATH, Capacity, DeviceID, DriveLetter, FreeSpace, Name
            $volumePathToVolume = @{}
            Get-WmiObject Win32_Volume |
                %{ $volumePathToVolume[$_.__RELPATH] = $_ } # Foreach volume (name = Win32_Volume.__RELPATH, Value = Win32_Volume "object with properties")

            # Win32_ShadowStorage properties include => __RELPATH, __PATH, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace, Volume
            $ErrorActionPreference = 'SilentlyContinue'
            
            $Win32_ShadowStorage = Get-WmiObject Win32_ShadowStorage

            ForEach($ShadowStoragex in $Win32_ShadowStorage){
                $hasShadowStorage = $true # shadow storage exists
                $forVolume = $volumePathToVolume[$ShadowStoragex.Volume] # $forVolume contains the matching (full) object from Win32_Volume
                $onVolume = $volumePathToVolume[$ShadowStoragex.DiffVolume]
                $result = $template.PSObject.Copy()
                $result.For = $forVolume.Name
                $result.On = $onVolume.Name
                $result."AllocatedSpace(On)" = $ShadowStoragex.AllocatedSpace
                $result."AllocatedPercent(On)" = [Math]::Round(($ShadowStoragex.AllocatedSpace/$onVolume.Capacity)*100,0)
                $result."UsedSpace(On)" = $ShadowStoragex.UsedSpace
                $result."MaxSpace(On)" = [Math]::Round(($ShadowStoragex.UsedSpace/$onVolume.Capacity)*100,0)
                $result."MaxSpace(On)" = $ShadowStoragex.MaxSpace
                $result."MaxPercent(On)" = [Math]::Round(($ShadowStoragex.MaxSpace/$onVolume.Capacity)*100,0)
                if ($result."MaxSpace(On)" -eq [uint64]::MaxValue){
                    $result."MaxSpace(On)" = 'Unlimited'
                    $result."MaxPercent(On)" = 100
                } #if
                if($result."AllocatedSpace(On)"){$result."AllocatedSpace(On)" = ($ShadowStoragex.AllocatedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."AllocatedSpace(On)"){$result."UsedSpace(On)" = ($ShadowStoragex.UsedSpace) | ConvertTo-KMG}
                else {$result."AllocatedSpace(On)" = 0}
                if($result."MaxSpace(On)" -ne 'Unlimited'){$result."MaxSpace(On)" = ($ShadowStoragex.MaxSpace) | ConvertTo-KMG}
                $result."Capacity(On)" = ($onVolume.Capacity) | ConvertTo-KMG
                $result
            } #foreach

            if (!$hasShadowStorage){
                $template.For = 'No VSS'
                $template
            } #if
        } #script
    #} #if
    & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() #
#endregion
#------------------------------------------------------
#region - UI Data Loading ... list of scripts, Synopsis, Functionality, ScriptText, Outputs, IsFavorite, Color
Write-Host "Loading Cache.....please wait"

# Get Server List from cache file if it exists.
# $VssMaster.ServerText = (Get-Content -Path "$($VssMaster.ServerListFilePath)" -ErrorAction Ignore) -join "`r`n"

# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($VssMaster.WorkingDirectory)\$($VssMaster.ScriptName).xml" -ErrorAction Stop
    $list = 'RadioList','RadioAdd','RadioDelete','RadioResize','For','On','Max','Min'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $VssMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

Write-Host "Complete" 
Write-Host "===============================" -f Green
Write-Host ""

#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *,auto,auto,auto -DataContext $VssMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -GridColSpan 3 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 30,15,0,0 -Foreground Blue -FontWeight Bold
            New-UITextBlock "Shadow Storage:" -Margin 30,0,0,0 -AlsoSet @{FontSize=18} -FontWeight Bold #-Foreground black
            New-UITextBlock "Choose a VssAdmin command" -Margin 30,10,0,0 -AlsoSet @{FontSize=16} -Foreground black -FontWeight Bold
            New-UIGrid -ColDefinition auto,auto,3* {
                New-UIStackPanel -GridRow 1 -GridCol 0 -Margin 30,0,0,0 -Orientation Vertical {
                    New-UITextBlock "VssAdmin List Shadowstorage"   -Margin 0,15,0,0 -AlsoSet @{FontSize=14} -Foreground Blue
                    New-UITextBlock "Show all ShadowStorage" -Margin 114,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                    New-UITextBlock ("*" * 62) -Margin 0,14,0,0 -Foreground Blue -FontWeight Bold
                    New-UITextBlock "VssAdmin Add /For=E: /On=E: /Maxsize=10%" -Margin 0,15,0,0 -AlsoSet @{FontSize=14} -Foreground Blue
                    New-UITextBlock "/For=E: /On=E: /Maxsize=20GB" -Margin 114,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                    New-UITextBlock "/For=E: /On=G: /Maxsize=10%" -Margin 114,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                    New-UITextBlock "VssAdmin Delete /For=E: /On=E: ... /For=E: /On=G:" -Margin 0,15,0,0 -AlsoSet @{FontSize=14} -Foreground Blue
                    New-UITextBlock "If unable to delete ..." -Margin 118,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                    New-UITextBlock "1st Resize it to /MaxSize=320MB" -Margin 118,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                    New-UITextBlock "VssAdmin Resize /For=E: /On=E: /Maxsize=10%" -Margin 0,15,0,0 -AlsoSet @{FontSize=14} -Foreground Blue
                    New-UITextBlock "/For=E: /On=E: /MaxSize=320MB." -Margin 126,0,0,0 -AlsoSet @{FontSize=14} -Foreground black
                } #StackPanel
                New-UIStackPanel -GridRow 1 -GridCol 1 -Margin 0,0,0,0 -Orientation Vertical {
                    New-UIStackPanel -Orientation Horizontal -Margin 10,00,0,0 {
                        New-UIButton "List" -Padding 10,4,10,6 -Margin 0,20,0,0 -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $VssMaster.Scripts.List #addclick
                    } #StackPanel
                    New-UITextBlock ("*" * 14) -Margin 0,15,0,0 -Foreground Blue -FontWeight Bold
                    New-UIStackPanel -Orientation Horizontal -Margin 10,0,0,0 {
                        New-UIButton "Add" -Padding 10,4,10,6 -Margin 0,30,0,0 -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $VssMaster.Scripts.Add #addclick
                    } #StackPanel
                    New-UIStackPanel -Orientation Horizontal -Margin 10,30,0,0 {
                        New-UIButton "Delete" -Padding 10,4,10,6 -Margin 0,10,0,0 -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $VssMaster.Scripts.Delete #addclick
                    } #StackPanel
                    New-UIStackPanel -Orientation Horizontal -Margin 10,20,0,0 {
                        New-UIButton "Resize" -Padding 10,4,10,6 -Margin 0,10,0,0 -Foreground Red -AlsoSet @{FontSize=14} `
                        -AddClick $VssMaster.Scripts.Resize #addclick
                    } #StackPanel
                } #StackPanel
                New-UIStackPanel -GridRow 1 -GridCol 2 -Margin 0,60,0,0 -Orientation Vertical {
                    New-UITextBlock ("*" * 32) -Margin 0,6,0,0 -Foreground Blue -FontWeight Bold
                    New-UIStackPanel -Orientation Horizontal -Margin 4,20,0,0 {
                        New-UITextBlock "/For= "     -Margin 90,0,0,0 -AlsoSet @{FontSize=18}
                        New-UITextBox -Width 24 -Height 20 -Margin 0,4,0,0 -BindTextTo For
                        New-UITextBlock " :" -Margin 0,0,0,0 -AlsoSet @{FontSize=18}
                    } #StackPanel
                    New-UIStackPanel -Orientation Horizontal -Margin 4,20,0,0 {
                        New-UITextBlock "/On= "      -Margin 90,0,0,0 -AlsoSet @{FontSize=18}
                        New-UITextBox -Width 24 -Height 20 -Margin 0,4,0,0 -BindTextTo On
                        New-UITextBlock " :" -Margin 0,0,0,0 -AlsoSet @{FontSize=18}
                    } #StackPanel
                    New-UIStackPanel -Orientation Horizontal -Margin 4,20,0,0 {
                        New-UITextBlock "/Maxsize= " -Margin 30,4,0,0 -AlsoSet @{FontSize=18}
                        New-UITextBox -Width 50 -Height 20 -Margin 0,4,0,0 -BindTextTo Max
                    } #StackPanel
                } #StackPanel
       } #UIGrid
            New-UIGrid -Margin 30,15,0,0 -GridRow 2 -GridColSpan 3 {
                New-UITextBlock ("*" * 200) -Foreground Blue -FontWeight Bold
            } #UIGrid
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 3 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 