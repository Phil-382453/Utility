﻿<#
.SYNOPSIS  
    Verify Symantec Endpoint Protection is reporting.
.ROLE
    Utility
.FUNCTIONALITY
    Sep,Symantec,virus,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

#####################################################
######## Script To Check SEP Reporting Status ####### 
#####################################################
#Single Servers

#$servers = Read-Host "Enter Servername"

#Multi Servers - Please remove # and use.

#$servers = GC -Path C:\TEMP\Servers.txt

#####################################################
### Script Starts ###

$scriptx1 = {Get-ItemProperty 'HKLM:\SOFTWARE\Symantec\Symantec Endpoint Protection\CurrentVersion\public-opstate'}
$scriptx2 = {Get-ItemProperty 'HKLM:\SOFTWARE\Symantec\Symantec Endpoint Protection\CurrentVersion\public-opstate'}
$scriptx3 = {Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Symantec\Symantec Endpoint Protection\SMC\SYLINK\SyLink'}
# this invoke will run on the local server...since no -Computername $Server...
$CurrentVersion = Invoke-Command -ScriptBlock $scriptx1 | Select-Object DeployRunningVersion                  
$LastUpdate     = Invoke-Command -ScriptBlock $scriptx2 | Select-Object LatestVirusDefsDate                   
$LastStatus     = Invoke-Command -ScriptBlock $scriptx3 | Select-Object LastConnectedTime,CommunicationStatus 

<#
"################################"
"Hostname = $($env:Computername)"
""
"Currently Installed SEP Version = $($CurrentVersion.DeployRunningVersion)"
"Last Virus Definition Update    = $($LastUpdate.LatestVirusDefsDate)"
"Last Connected Time             = $($LastStatus.LastConnectedTime)"
"Last Communication Status       = $($LastStatus.CommunicationStatus)"
#>

# create a pscustomobject - to return the item we select and put output into a table format.
$component = [ordered]@{}
$component.Hostname                          = "$($env:Computername)"
$component.'Currently Installed SEP Version' = "$($CurrentVersion.DeployRunningVersion)"
$component.'Last Virus Definition Update'    = "$($LastUpdate.LatestVirusDefsDate)"
$component.'Last Connected Time'             = "$($LastStatus.LastConnectedTime)"
$component.'Last Communication Status'       = "$($LastStatus.CommunicationStatus)"
[pscustomobject]$component #echo to output.

#####################################################
### Script Ends ###