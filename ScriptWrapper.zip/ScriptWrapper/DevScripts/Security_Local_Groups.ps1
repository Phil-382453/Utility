﻿<#
.SYNOPSIS  
    Get Local Users and Computers - groups and members
.ROLE
    Security
.FUNCTIONALITY
    groups,members,access,logon,account,username,Security_Local_Groups
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

# This will give a list of all group names in the local users and computers tool
$LocalGroups = Get-WmiObject Win32_Group -Filter "LocalAccount=True" | Select-Object -ExpandProperty Name

# A more compact form of creating and adding to a custom PSObject
$template = 1 | Select-Object ComputerName,GroupName,AccountName # Define an object and its properties. Fill in the object later.
$template.ComputerName = $env:COMPUTERNAME # add the computername property here because it is the same for all.
            
foreach($LocalGroup in $LocalGroups){
    #if($LocalGroup -like "*admin*"){
        # This will give a list of the members for a given local group
        $wmi = Get-WmiObject -Query "SELECT * FROM Win32_GroupUser WHERE GroupComponent=`"Win32_Group.Domain='$env:COMPUTERNAME',Name='$LocalGroup'`""  

        # Parse out the username from each result and append it to the array.  
        if ($wmi) {
            $x = $null
            foreach ($item in $wmi) {
                $data = ($item.PartComponent -split "\,").replace('"','') # seperate out the text/data we want to keep
                $domain = ($data[0] -split "=")[1] 
                $name = ($data[1] -split "=")[1]
                
                $result             = $template.PSObject.Copy() # create a custom PSobject based on template
                $result.GroupName   = $LocalGroup               # fill in the return object
                $result.AccountName = "$($domain)\$($name)"     # fill in the return object
                [array]$x += $result # collect all accounts in the current group 
            } #for
            $x | sort AccountName # sort the accounts ascending
        } #if
        else {
            $result             = $template.PSObject.Copy() # create a custom PSobject based on template
            $result.GroupName   = $LocalGroup               # fill in the return object
            $result.AccountName = "No members"              # fill in the return object
            $result # echo to output 
        } #else
    #} #if
} #for