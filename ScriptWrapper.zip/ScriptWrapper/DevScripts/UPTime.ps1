﻿<#
.SYNOPSIS  
    Get time of last Boot
.ROLE
    Operating System
.FUNCTIONALITY
    reboot,patching,UpTime,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

#""
#"#####################################################################"

$x = systeminfo
foreach($line in $x){ if($line -like "*System Boot Time:*"){$uptimex = $line} }
$uptimex = ($uptimex -split "System Boot Time:").Trim()

#$Return = $uptimex[1] | select @{Name="Hostname";Expression={$env:COMPUTERNAME}}, @{Name="System Boot Time";Expression={$_}}


New-TimeSpan -Start (Get-Date) -End (            
        [System.Management.ManagementDateTimeConverter]::ToDateTime(            
            (Get-WmiObject -Class Win32_OperatingSystem).LastBootUpTime            
        )
    ) | select @{Name="Hostname";Expression={$env:COMPUTERNAME}},Days,Hours,Minutes,Seconds,@{Name="System Boot Time";Expression={$uptimex[1]}}
