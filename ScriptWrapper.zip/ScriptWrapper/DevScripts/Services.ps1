﻿<#
.Synopsis
    (Input tab) Remote Service Query, Start, Stop, Restart, Required Services, Dependent Services, Set Startup Type
.ROLE
    Operating System
.FUNCTIONALITY
    Services,QUERY,START,STOP,RESTART,Dependent,Startup,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
$ServicesMaster = New-UIObject

$ServicesMaster.RadioSName       = $true
$ServicesMaster.RadioDName       = $false
$ServicesMaster.ServiceName      = "*"
$ServicesMaster.ServiceDName     = "*"
$ServicesMaster.StartupType      = $null
$ServicesMaster.ModeQuery        = $true
$ServicesMaster.ModeStart        = $false
$ServicesMaster.ModeStop         = $false
$ServicesMaster.ModeRestart      = $false
$ServicesMaster.ModeStartupType  = $false
$ServicesMaster.ModeKillService  = $false
$ServicesMaster.ScriptName       = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$ServicesMaster.WorkingDirectory = $UIMaster.WorkingDirectory
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$ServicesMaster.Scripts = @{}
$ServicesMaster.Scripts.CloseTab = {
    $tabItem = Find-UIParent -Type TabItem
    $tabItem.Parent.Items.Remove($tabItem)
} # close script tabs
$ServicesMaster.Scripts.StartupTypeChanged = { $ServicesMaster.ModeStartupType = $true }
$ServicesMaster.Scripts.Run = {
    #Write-Host "$($ServicesMaster.WorkingDirectory)\$($CopyUnzipDelete.ScriptName).xml"
   # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($ServicesMaster.WorkingDirectory)\$($ServicesMaster.ScriptName).xml" -InputObject @{
        RadioSName      = $ServicesMaster.RadioSName
        RadioDName      = $ServicesMaster.RadioDName
        ServiceName     = $ServicesMaster.ServiceName
        ServiceDName    = $ServicesMaster.ServiceDName
        StartupType     = $ServicesMaster.StartupType
        ModeKillService = $ServicesMaster.ModeKillService
    } #Export-Clixml

    # Prepare the list of service names (display names)
    $ServiceName = $ServicesMaster.RadioSName # $ServiceName = (true if Servicename radiobutton selected)
    if ($ServiceName){ $Name = $ServicesMaster.ServiceName  -split "`r`n" | ForEach-Object Trim | Where-Object { $_ }} 
    else             { $Name = $ServicesMaster.ServiceDName -split "`r`n" | ForEach-Object Trim | Where-Object { $_ }}

    # Verify valid choices
    if (-not($ServicesMaster.ModeQuery)) {
        if (($Name | ?{ $_.Contains("*") })) { Show-UIMessageBox "Wildcards are only allowed with Query."; return }
        if (!$ServiceName){Show-UIMessageBox "DisplayNames are only allowed with Query.`r`nPlease choose the Service Name radio button."; return}
    } #if

    # Query
    if ($ServicesMaster.ModeQuery) {
        $SubScriptMessage = "$(($ServicesMaster.ScriptName) -replace ".ps1") - Query"
        $ArgumentList = $Name, $ServiceName
        $script = {
            Param ([string[]]$Name, [bool]$ServiceName)

            # serviceName vs displayname
            $nameProperty = "DisplayName"
            if ($ServiceName) {$nameProperty = "Name"}

            # create a hash to use in RequiredServices,DependentServices
            $GetService = @{}
            
            # Get all services
            if($Name -eq "*"){
                $Cimservice = Get-CimInstance -Class Win32_Service | select *
            }
            else{
                $Cimservice = Get-CimInstance -Class Win32_Service | where{$_."$nameProperty" -like "$($Name)"} | select *
            }
            
            # Collect output
            foreach($svc_item in $Cimservice){
                $Service = [ordered]@{}
                $Service.Name              = $svc_item.Name
                $Service.DisplayName       = $svc_item.DisplayName
    
                # check for (Delayed Start)
                $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc_item.Name)"
                if((Get-ItemProperty -Path $key -Name DelayedAutostart -ea SilentlyContinue).DelayedAutostart -eq "1"){
                    $Service.StartMode = "$($svc_item.StartMode)" + ' (Delayed Start)'
                }
                else{$Service.StartMode    = $svc_item.StartMode}
                if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)\TriggerInfo\") {
                    $Service.StartMode = "$($Service.StartMode)" + ' (Trigger Start)'
                }
                $Service.Started           = $svc_item.Started
                $Service.State             = $svc_item.State
                $Service.PathName          = $svc_item.PathName
                $Service.ProcessId         = $svc_item.ProcessId
                $Service.RequiredServices  = ($GetService[$svc_item.Name] | select -expand RequiredServices) -join ', '
                $Service.DependentServices = ($GetService[$svc_item.Name] | select -expand DependentServices) -join ', '
                $Service.StartName         = $svc_item.StartName
                #$Service.Description       = $svc_item.Description
                [pscustomobject]$Service #echo
            } #%
        } #script
        & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    } #if

    # Start/Stop/Restart
    if ($ServicesMaster.ModeStart -or $ServicesMaster.ModeStop -or $ServicesMaster.ModeRestart -or $ServicesMaster.ModeKillService) {
        Switch ($true) {
            $ServicesMaster.ModeStart       {$action = 'Start'; Break}
            $ServicesMaster.ModeStop        {$action = 'Stop'; Break}
            $ServicesMaster.ModeRestart     {$action = 'Restart'; Break}
            $ServicesMaster.ModeKillService {$action = 'Kill'; Break}
        } #switch
        $ArgumentList = $Name, $ServiceName, $action
        $SubScriptMessage = "$(($ServicesMaster.ScriptName) -replace ".ps1") - $($action)"
        $Script = {
            Param ([string[]]$Name, [bool]$ServiceName, [string]$Action)
            
            $serviceNameToWmi = @{}
            Get-WmiObject -Class Win32_Service | ForEach-Object { $serviceNameToWmi[$_.Name] = $_ }


            $filteredServiceList = Get-Service -Name $Name 


            foreach ($service in $filteredServiceList) {
                $previousStatus = $service.Status
                $wmiObject = $serviceNameToWmi[$service.ServiceName]
                
                switch ($Action) {
                    'Start'   { Start-Service   -Name "$($service.Name)" }
                    'Stop'    { Stop-Service    -Name "$($service.Name)" }
                    'Restart' { Restart-Service -Name "$($service.Name)" -Force }
                    "Kill"    { Stop-Process -id $wmiObject.ProcessId -Force }
                } #switch

                $result = $service | Get-Service | Select-Object ServiceName,PreviousStatus,Status,DisplayName,StartMode,RunAs,PathName,RequiredServices,DependentServices
                $result.Status    = "$($result.Status)"
                $result.PreviousStatus = "$($previousStatus)"
                $result.StartMode = $wmiObject.StartMode
                $result.RunAs     = $wmiObject.StartName
                $result.PathName  = $wmiObject.PathName
                $result.RequiredServices  = $result.RequiredServices -join ', '
                $result.DependentServices = $result.DependentServices -join ', '
                $result
            } #foreadh
        } #script
        & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    } #if

    # Startup Type
    if ($ServicesMaster.ModeStartupType) {
        $ArgumentList = $Name, $ServiceName, $ServicesMaster.StartupType
        $SubScriptMessage = "$(($ServicesMaster.ScriptName) -replace ".ps1") - StartupType"
        $Script = {
            Param ([string[]]$Name, [bool]$ServiceName, [string]$StartupType)

            # set the service startup type
            foreach ($service in $Name) { 
                Switch ($StartupType) {
                    'Automatic'             {sc.exe config $Service start= Auto         | out-null;break}
                    'Manual'                {sc.exe config $Service start= demand       | out-null;break}
                    'Disabled'              {sc.exe config $Service start= disabled     | out-null;break}
                    'AutomaticDelayedStart' {sc.exe config $Service start= delayed-auto | out-null;break}
                } #switch
            } #foreach
            

            # Collect output
            $Cimservice = Get-CimInstance -Class Win32_Service -Filter “Name = '$Name'" | select *
            foreach($svc_item in $Cimservice){
                $Service = [ordered]@{}
                $Service.Name              = $svc_item.Name
                $Service.DisplayName       = $svc_item.DisplayName
    
                # check for (Delayed Start)
                $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc_item.Name)"
                if((Get-ItemProperty -Path $key -Name DelayedAutostart -ea SilentlyContinue).DelayedAutostart -eq "1"){
                    $Service.StartMode = "$($svc_item.StartMode)" + ' (Delayed Start)'
                }
                else{$Service.StartMode    = $svc_item.StartMode}
                if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)\TriggerInfo\") {
                    $Service.StartMode = "$($Service.StartMode)" + ' (Trigger Start)'
                }
                $Service.Started           = $svc_item.Started
                $Service.State             = $svc_item.State
                $Service.PathName          = $svc_item.PathName
                $Service.ProcessId         = $svc_item.ProcessId
                $Service.RequiredServices  = ($GetService[$svc_item.Name] | select -expand RequiredServices) -join ', '
                $Service.DependentServices = ($GetService[$svc_item.Name] | select -expand DependentServices) -join ', '
                $Service.StartName         = $svc_item.StartName
                #$Service.Description       = $svc_item.Description
                [pscustomobject]$Service #echo
            } #%

        } #Script
        & $UIMaster.Scripts.RunScriptBlock $Script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage 
    } #if
}.GetNewClosure() # .Run1

#endregion
#------------------------------------------------------
#region - UI Data Loading

# Read in the script settings file and populate radio buttons, textboxes, etc.
try {
    $SettingsClixml = Import-Clixml "$($ServicesMaster.WorkingDirectory)\$($ServicesMaster.ScriptName).xml" -ErrorAction Stop
    $list1 = 'RadioSName','RadioDName','ServiceName','ServiceDName','StartupType'
    foreach ($setting in $list1) {
        if ($SettingsClixml.Contains($setting)) { $ServicesMaster.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }

#endregion
#------------------------------------------------------
#region - UI Layout / Show UI

New-UIGrid -RowDefinition *,auto -DataContext $ServicesMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 4,10,0,0 -FontWeight Bold
            New-UITextBlock "Overview:" -FontWeight Bold -Margin 4,6,4,0
            New-UITextBlock "`tTextbox `t- one per line" -Margin 4,6,4,0
            New-UITextBlock "`tQuery `t- service name(s) or disiplay name(s) - wildcards accepted" -Margin 4,6,4,0
            New-UITextBlock "`tStart `t- service name(s) only" -Margin 4,6,4,0
            New-UITextBlock "`tStop `t- service name(s) only" -Margin 4,6,4,0
            New-UITextBlock "`tRestart `t- service name(s) only" -Margin 4,6,4,0
            New-UITextBlock "`tSU Type `t- service name(s) only    - set the service startup type" -Margin 4,6,4,0
            New-UITextBlock "`tKill `t- service name(s) only    - kill the service process" -Margin 4,6,4,0
            New-UITextBlock "Enter Service Name/DisplayName" -FontWeight Bold -Margin 4,16,4,10
            
            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical {
                    New-UIRadioButton "Service Name(s)" -Margin 14,10,4,0 -Align Centerleft -BindIsCheckedTo RadioSName
                    New-UIRadioButton "Display Name(s) " -Margin 14,50,4,0 -Align CenterLeft -BindIsCheckedTo RadioDName
                } #StackPanel
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBox -AcceptsReturn $true  -Margin 8,6,4,0  -BindTextTo ServiceName -Width 250 -Height 60 -VerticalScrollBarVisibility Auto
                    New-UITextBox -AcceptsReturn $true   -Margin 4,6,4,0 -BindTextTo ServiceDName -Width 250 -Height 60 -VerticalScrollBarVisibility Auto
                } #StackPanel
            } #StackPanel

            New-UITextBlock "Action:" -FontWeight Bold -Margin 4,6,4,0
            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical {
                    New-UIRadioButton "Query" -Margin 14,10,4,0 -BindIsCheckedTo ModeQuery
                    New-UIRadioButton "Start" -Margin 14,10,4,0 -BindIsCheckedTo ModeStart
                    New-UIRadioButton "Stop" -Margin 14,10,4,0 -BindIsCheckedTo ModeStop
                    New-UIRadioButton "Restart" -Margin 14,10,4,0 -BindIsCheckedTo ModeRestart
                    New-UIRadioButton "Change Startup Type to:" -Margin 14,10,4,0 -BindIsCheckedTo ModeStartupType
                    New-UIComboBox 'Automatic','Manual','Disabled','AutomaticDelayedStart' -Margin 32,10,4,0 -width 150 -Align TopLeft -BindSelectedValueTo StartupType
                    New-UIRadioButton "Kill Service" -Margin 14,10,4,0 -BindIsCheckedTo ModeKillService
                } #StackPanel
                New-UIStackPanel -Orientation Vertical {
                    New-UIButton "Run" -Margin 20,25,0,10 -Padding 14,4,14,6 -Foreground Red -AlsoSet @{FontSize=14}`
                        -AddClick $ServicesMaster.Scripts.Run
                } #StackPanel
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,0 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer

    # GridRow 1
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion - UI Window
#------------------------------------------------------
# PowerShell script complete
<#
Try { Get-Service -Name $service.Name -ErrorAction Stop }
Catch{
    $error[0].exception
    #$error[0].InnerException
    #$error[0].CategoryInfo
    #$error[0].ErrorDetails
    #$error[0].Exception
    #$error[0].FullyQualifiedErrorId
    #$error[0].InvocationInfo
    #$error[0].TargetObject
    #$error[0].PSMessageDetails
    return

   $result.Status    = "Not found"
    $result.StartMode = "N/A"
    $result.RunAs     = "N/A"
    $result.PathName  = "N/A"
    $result.RequiredServices  = "N/A"
    $result.DependentServices = "N/A"
    $result 
} #catch
#>