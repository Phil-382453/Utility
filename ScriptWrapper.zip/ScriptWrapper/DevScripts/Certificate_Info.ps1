﻿<#
.SYNOPSIS  
    Get certificate info - Name and Expires In Days
.ROLE
    Security
.FUNCTIONALITY
    expires,security,Certificate_Info,Table
.NOTES
     Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

# Here is a quick way to list the days remaining before the certificates on your server are about to expire. 
#$array = Get-ChildItem -Path Cert:\LocalMachine\My | Select-Object *
#$array = Get-ChildItem -Path Cert:\LocalMachine\My | Select-Object -Property @{name='Hostname';expression={$env:computername}}, Subject, @{name='ExpireInDays';expression={($_.notafter - (Get-Date)).Days}}, PSChildName
$array = Get-ChildItem -Path Cert:\LocalMachine\My | 
    Select-Object -Property Subject, @{name='ExpireInDays';expression={($_.notafter - (Get-Date)).Days}}, PSChildName
if(($array -eq $null) -or ($array -eq "")){Return "No Data"}
else{Return $array}

<#
Get-ChildItem cert:\ -Recurse | Where-Object {$_ -is [System.Security.Cryptography.X509Certificates.X509Certificate2] } | 
select FriendlyName,NotAfter,NotBefore,SerialNumber,Thumbprint,Issuer,Subject
#> 