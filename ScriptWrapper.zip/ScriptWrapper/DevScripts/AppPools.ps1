﻿<#
.SYNOPSIS
    (Input tab) Query or recycle IIS application pools
.ROLE
    Software
.FUNCTIONALITY  
    App,Pools,AppPools,IIS,web,site,website,InputTab,Warning
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$AppPoolMaster = New-UIObject

$AppPoolMaster.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$AppPoolMaster.WorkingDirectory = $UIMaster.WorkingDirectory
$AppPoolMaster.AppPoolNames = $null

$AppPoolMaster.Scripts = @{}
$AppPoolMaster.Scripts.RunQuery = {
    $script = Convert-ScriptOutputToText { # query
        $myAppPools = Get-WmiObject -Namespace root\WebAdministration -Class ApplicationPool | select PsComputerName,Name
        $myAppPools # echo to output
    } #$script
    $SubScriptMessage = "$(($AppPoolMaster.ScriptName) -replace ".ps1") - Query" # create console subscript message
    & $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage

}.GetNewClosure() # .RunQuery
$AppPoolMaster.Scripts.RunRecycle = {
    $AppPoolNames = $null
    $AppPoolNames = $AppPoolMaster.AppPoolNames.Split("`r`n").Trim() | Where {$_} | Select -Unique #trim & remove empty rows

    if(($AppPoolNames.Contains('*')) -or ($AppPoolNames.Contains('?'))){ #cannot contain * for recycle 
        Show-UIMessageBox "App Pool Names cannot contain wildcards"
        return
    } #if
    elseif(!$AppPoolNames){
        Show-UIMessageBox "App Pool Names cannot be blank"
        return
    } #if

    $ArgumentList = $AppPoolNames -join "`r`n" # join needed or only 1st item passed to $ArgumentList

    $script = Convert-ScriptOutputToText { #Recycle
        Param($AppPoolNames)

        ""
        "############################################################################################################"
        "Hostname: $($env:COMPUTERNAME)"
        ""
        $AppPoolNamesx = ($AppPoolNames -split "`r`n").Trim()
        Foreach ($AppPoolName in $AppPoolNamesx){
                $myAppPools = $null
                $myAppPools = Get-WmiObject -Namespace root\WebAdministration -Class ApplicationPool -Filter "Name = '$AppPoolName'"
                if ($myAppPools){
                    "Recycling app pool = $myAppPools"
                    $myAppPool.Recycle()
                }
                else{
                    "App pool not found - $AppPoolName"
                }
        }
        ""
        "Application pool recycling complete."

    } #$script
    $SubScriptMessage = "$(($AppPoolMaster.ScriptName) -replace ".ps1") - Recycle" # create console subscript message
    #######################################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
}.GetNewClosure() # .RunRecycle

#endregion
#------------------------------------------------------
#region - UI Data Loading
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $AppPoolMaster {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UIStackPanel -Margin 20,20,0,0 {
                New-UITextBlock ("*" * 200) -Margin 0,4,0,0 -FontWeight Bold
                New-UITextBlock "Purpose:" -FontWeight Bold -Margin 0,10,4,0 -AlsoSet @{FontSize=14}
                New-UITextBlock "This script allows you to Query or Recycle IIS Application Pools on a remote server(s)." -Margin 20,6,0,0 -AlsoSet @{FontSize=14}
                New-UITextBlock "Query - Returns ALL application pools found. Output is sent to a new tab."-Margin 20,6,0,0 -AlsoSet @{FontSize=14}
                New-UITextBlock "Recycle - Recycles one or more application pool names listed in the textbox below." -Margin 20,6,0,0 -AlsoSet @{FontSize=14}
                New-UITextBlock "Most useful when application pools are causing high cpu and you're unable to logon." -Margin 20,6,0,0 -AlsoSet @{FontSize=14} -foreground "Green"
                New-UITextBlock ("*" * 100) -Margin 0,10,0,4 -FontWeight Bold
            } #StackPanel

            New-UIStackPanel -Margin 20,20,0,0 {
                New-UITextBlock "Action:" -FontWeight Bold -Margin 0,6,0,0 -AlsoSet @{FontSize=14}
                New-UIStackPanel -Orientation Horizontal -Margin 20,20,0,0 {
                    New-UIButton "Query" -Padding 10,6,10,6 -Margin 0,0,0,0 -AddClick $AppPoolMaster.Scripts.RunQuery
                    New-UITextBlock "Get a list of all application pool names found (per server)." -Margin 10,6,0,0 -AlsoSet @{FontSize=14}
                } #StackPanel
            } #StackPanel
            New-UIStackPanel -Margin 40,30,0,0 {
                New-UITextBlock "Enter App Pool Name (one per line) - wildcards not allowed:" -Margin 0,6,0,10 -FontWeight Bold -AlsoSet @{FontSize=14}
                New-UITextBox -AcceptsReturn $true -BindTextTo AppPoolNames -Align TopLeft -Width 400 -Height 150
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal -Margin 40,20,0,0 {
                New-UIButton "Recycle" -Padding 10,6,10,6 -Margin 0,0,0,0 -AddClick $AppPoolMaster.Scripts.RunRecycle -foreground "Red"
                New-UITextBlock "Recycle the App pools listed in the text box above." -Margin 10,6,0,0 -AlsoSet @{FontSize=14} -foreground "Red"
            } #StackPanel
            New-UITextBlock ("*" * 200) -Margin 20,10,0,4 -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1 -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 

        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete 