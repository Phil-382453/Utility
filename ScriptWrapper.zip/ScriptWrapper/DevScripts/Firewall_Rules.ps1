﻿<#
.SYNOPSIS  
    Get firewall rules - Name, DisplayName, Action, Direction, Protocol, Profile, Local-Ports, ApplicationName
.ROLE
    Security
.FUNCTIONALITY
    ports,access,Firewall,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

# Create HashTable - on .Name property
$HNetCFG_RwPolicy2 = @{}
(New-object -comObject HNetCfg.FwPolicy2).rules | %{ $HNetCFG_RwPolicy2[$_.Name] = $_ } # Create HashTable with Name = Name

$direction = @{1="In"   ;2="Out"  }
#$action = @{1="Allow";0="Block";2="Allow"} # I cant find this on google. I think 2="Allow" but cant prove it.

###########################################################################################
# Get-NetFirewallRule...select a few properties...adding some properties from other objects
Get-NetFirewallRule -Enabled True | select Name,DisplayName,`
    @{Name='Direction' ;Expression={($direction[[int]($_.Direction)])}},`
    DisplayGroup,`
    @{Name='Protocol'       ;Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}},`
    @{Name='LocalPort'      ;Expression={($_      | Get-NetFirewallPortFilter).LocalPort}},`
    @{Name='RemotePort'     ;Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}},`
    @{Name='RemoteAddress'  ;Expression={($_      | Get-NetFirewallAddressFilter).RemoteAddress}},`
    @{Name='ApplicationName';Expression={($HNetCFG_RwPolicy2[$_.DisplayName]).ApplicationName }},`
    @{Name='ServiceName'    ;Expression={($HNetCFG_RwPolicy2[$_.DisplayName]).serviceName }},`
    Action
    #@{Name='Action' ;Expression={($action[[int]($_.Action)])}}
###########################################################################################