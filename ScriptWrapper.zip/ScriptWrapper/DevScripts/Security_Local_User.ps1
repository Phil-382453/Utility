﻿<#
.SYNOPSIS 
    Get local User account names - LocalUserName
.ROLE
    Security
.FUNCTIONALITY
    Local,users,accounts,usernames,access,security_Local_Users,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

Get-WmiObject Win32_UserAccount -Filter "LocalAccount = True" |
    ForEach-Object {
        $result = [ordered]@{}
        $result.ComputerName = $env:COMPUTERNAME
        $result.LocalUserName = $_.Name
        $result.Description = $_.Description
        [pscustomobject]$result
    }