﻿<#
.SYNOPSIS  
    Get Multipath information (mpio)
.ROLE
    Drive
.FUNCTIONALITY
    mpio,multipath,san,hba,drives,disks,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

(gwmi -Namespace root\wmi -Class mpio_disk_info).driveinfo | %{
    $MPIO = [ordered]@{}
    $MPIO.DsmName      = $_.DsmName
    $MPIO.Name         = $_.Name
    $MPIO.NumberPaths  = $_.NumberPaths
    $MPIO.SerialNumber = $_.SerialNumber
    [pscustomobject]$MPIO
} #%

