﻿<#
.SYNOPSIS 
    Get User Profile Info - LocalPath, SID, LastUsed - size not included
.ROLE
    Users
.FUNCTIONALITY
    Profiles,username,account,SID,access,User_Profiles_2,disk,drive,Table
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    Table
#>

$usedSids = @{}
Get-WmiObject Win32_UserProfile |
    Where-Object { $_.SID.Length -gt 8 } |
    ForEach-Object {
        $lastUsed = try { $_.ConvertToDateTime($_.LastUseTime) } catch { $null }
        $usedSids[$_.SID] = $true
        [pscustomobject][ordered]@{
            ComputerName = $env:COMPUTERNAME
            SID = $_.SID
            LocalPath = $_.LocalPath
            LastUsed = $lastUsed
        }
    }

$substringStart = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'.Length + 1
Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList' |
    Select-Object @{Name='LocalPath'; Expression={ $_.GetValue('ProfileImagePath') }},
        @{Name='SID'; Expression={ $_.Name.Substring($substringStart) }} |
    Where-Object { $_.SID.Length -gt 8 -and -not $usedSids[$_.SID] } |
    ForEach-Object {
        [pscustomobject][ordered]@{
            ComputerName = $env:COMPUTERNAME
            SID = $_.SID
            LocalPath = $_.LocalPath
            LastUsed = $null
        }
    }