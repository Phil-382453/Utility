﻿<#
.SYNOPSIS  
    (Input tab) Compare 2 csv files based on common header name (HostName).
.ROLE
    Excel
.FUNCTIONALITY
    files,compare,excel,csv,InputTab,NoServersNeeded
.NOTES
    Author - Philip.Bellanca@Outlook.com
.OUTPUTS
    InputTab
#>
#------------------------------------------------------
#region - initialize variables
######################
$Xlsx1master = New-UIObject
$Xlsx1master.ScriptName = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS scriptname
$Xlsx1master.WorkingDirectory = $UIMaster.WorkingDirectory

$Xlsx1master.RadioOriginal     = $true
$Xlsx1master.RadioNew          = $false
$Xlsx1master.TextboxOrgcsv     = "c:\temp\original.csv" # csv path and filename
$Xlsx1master.TextboxNewcsv     = "c:\temp\new.csv"      # csv path and filename
$Xlsx1master.BrowseDir         = "c:\temp"   # default starting location for browse
$Xlsx1master.TextboxReadStatus = ""
$Xlsx1master.DataOrg           = $null       # csv contents
$Xlsx1master.DataNew           = $null       # csv contents
$Xlsx1master.HeaderOrg         = ""          # csv header row
$Xlsx1master.HeaderNew         = ""          # csv header row
$Xlsx1master.TextboxOrgHeader  = 'HostName1' # csv comparison header chosen
$Xlsx1master.TextboxNewHeader  = 'Hostname2' # csv comparison header chosen
$Xlsx1master.Outputcsv         = "$($Xlsx1master.WorkingDirectory)\Output.csv" # clean results saved here
$Xlsx1master.Final             = $null # clean final results to output
#endregion
#------------------------------------------------------
#region - UI Action Scripts
$Xlsx1master.Scripts = @{}
$Xlsx1master.Scripts.Browse        = {
    # starting dir for browse (UNC path)
    if(($Xlsx1master.RadioOriginal) -and ($Xlsx1master.TextboxOrgcsv)){
        $temp1 = ($Xlsx1master.TextboxOrgcsv -split '\\')[-1]
        $temp2 = $Xlsx1master.TextboxOrgcsv -replace ($temp1,'')
        $Xlsx1master.BrowseDir = $temp2.trimend('\\')
    }
    elseif (($Xlsx1master.RadioNew) -and ($Xlsx1master.TextboxNewcsv)){
        $temp1 = ($Xlsx1master.TextboxNewcsv -split '\\')[-1]
        $temp2 = $Xlsx1master.TextboxNewcsv -replace ($temp1,'')
        $Xlsx1master.BrowseDir = $temp2.trimend('\\')
    }

    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $dialog = New-Object System.Windows.Forms.OpenFileDialog #.......create a file open form
    $dialog.InitialDirectory = $Xlsx1master.BrowseDir #...set the starting directory for browsing
    $dialog.Multiselect = $false #...............allow choosing multiple files
    $result = $dialog.ShowDialog() #............make the dialog box visible

    if ($result -ne 'OK') {
        write-Host ""
        write-Host "Cancel" -f Red
        $Xlsx1master.FileNameSource = ""
        return # Try again
    } #if

    # Get the source filename list (and source folder path)...populate zip file if match
    if($Xlsx1master.RadioOriginal){$Xlsx1master.TextboxOrgcsv = $dialog.FileName}
    else {$Xlsx1master.TextboxNewcsv = $dialog.FileName}
}.GetNewClosure()
$Xlsx1master.Scripts.Readx         = {
    $Xlsx1master.TextboxReadStatus = ''
    start-sleep -Milliseconds 200
    # Read in the csv file - select * because I dont know the Comparison column has not been named yet
    $Xlsx1master.DataOrg = import-csv $Xlsx1master.TextboxOrgcsv #| select *,@{Name="Match";Expression={''}},@{Name="New";Expression={''}} # Match - will allow marking matches
    $Xlsx1master.DataNew = import-csv $Xlsx1master.TextboxNewcsv #| select *,@{Name="New";Expression={''}} # New - will allow marking not in original (append at the end)
    $Xlsx1master.TextboxReadStatus = 'Complete'
}.GetNewClosure()
$Xlsx1master.Scripts.VerifyOrgHdrs = {
    # get the header row
    $Xlsx1master.Header1   = $Xlsx1master.DataOrg | Get-Member -MemberType NoteProperty | Select -ExpandProperty Name 
    $Xlsx1master.HeaderOrg = $Xlsx1master.Header1 | %{"$($_),"}
    $messagex = "Select the column header from Original.csv:`r`nThis will be used for comparison.`r`n`r`n$($Xlsx1master.HeaderOrg)"
    $ShowUIMsgBox = Show-UIMessageBox -Message "$($messagex)" -button Ok
}.GetNewClosure()
$Xlsx1master.Scripts.Runx          = {
    $SubScriptMessage = "$(($Xlsx1master.ScriptName) -replace ".ps1")"
    $Xlsx1master.Final = $null # clean final results to output
    $Header = $null
    $Header = $Xlsx1master.TextboxOrgHeader # comparison Header (HostName)

    # Export settings for the next time the UI is loaded
    Export-Clixml -Path "$($Xlsx1master.WorkingDirectory)\$($Xlsx1master.ScriptName).xml" -InputObject @{
        TextboxOrgcsv    = $Xlsx1master.TextboxOrgcsv # Textbox for csv filename
        TextboxNewcsv    = $Xlsx1master.TextboxNewcsv # Textbox for csv filename
        TextboxOrgHeader = $Header                    # Textbox for csv file Header
    } #Export-Clixml

    $DataOrg = $Xlsx1master.DataOrg | sort "$Header"
    # Select (Hostname) from "DataNew" - sort
    $DataNew = $Xlsx1master.DataNew | select "$Header" | sort # Original rows sorted (Hostname)
    $Xlsx1master.Final = Compare-Object -ReferenceObject $DataOrg `
        -DifferenceObject $DataNew -Property $Header -PassThru -IncludeEqual
    # Save clean output to csv
    $Xlsx1master.Final | export-csv $Xlsx1master.Outputcsv -NoTypeInformation

    $ArgumentList = $Xlsx1master.Outputcsv # send to the param of the $script
    $SubScriptMessage = "** Merge csv files" # create console subscript message
    ########################
    $script = {
       Param($Outputcsv)
        Import-csv $Outputcsv
    } #script
     ########################
    & $UIMaster.Scripts.RunScriptBlock $script -ArgumentList $ArgumentList -SubScriptMessage $SubScriptMessage
    #& $UIMaster.Scripts.RunScriptBlock $script -SubScriptMessage $SubScriptMessage
}.GetNewClosure()
#endregion
#------------------------------------------------------
#region - UI Data Loading
# Read in the script settings file and populate the controls.
try {
    $SettingsClixml = Import-Clixml "$($Xlsx1master.WorkingDirectory)\$($Xlsx1master.ScriptName).xml" -ErrorAction Stop
    $list = 'TextboxOrgcsv','TextboxNewcsv','TextboxOrgHeader'
    foreach ($setting in $list) {
        if ($SettingsClixml.Contains($setting)) { $Xlsx1master.$setting = $SettingsClixml.$setting } # update the popup fields
    } #foreach
}
catch { }
#endregion
#------------------------------------------------------
#region - UI Layout / Show UI
New-UIGrid -RowDefinition *, auto -DataContext $Xlsx1master {
    New-UIScrollViewer -VerticalScrollBarVisibility Auto -HorizontalScrollBarVisibility Auto {
        New-UIStackPanel -GridRow 0 -Orientation Vertical {
            New-UITextBlock ("*" * 200) -Margin 20,5,0,0 -Foreground Blue -FontWeight Bold 
            New-UITextBlock "Purpose:" -FontWeight Bold -Margin 20,0,0,0 -AlsoSet @{FontSize=18}
            New-UITextBlock "Compare 2 csv files by matching a column in both.  Ex: Hostname" -Margin 20,10,0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "Output = A copy of the original.csv with 'Match' column added." -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "`tAll servers from both csv's will be present in the output." -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "Match column key:" -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "`t(==) Match both Original.csv and New.csv" -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "`t(<=) Original.csv only, no match with New.csv" -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock "`t(=>) New.csv only, no match with Original.csv" -Margin 20,4, 0,0 -AlsoSet @{FontSize=14} -Foreground Black
            New-UITextBlock ("*" * 116) -Margin 20,20,0,0 -Foreground Blue -FontWeight Bold 
            # Browse
            New-UITextBlock "Browse for Original and New csv files:" -Margin 20,0,0,0 -FontWeight Bold -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal -Margin 20,10,0,10 {
                New-UIButton "Browse" -Padding 10,4,10,4 -Align BottomLeft -AlsoSet @{FontSize=14}`
                    -AddClick $Xlsx1master.Scripts.Browse
                New-UITextBlock "Browse starts at textbox location." -Margin 20,15,0,0 -Foreground Black -AlsoSet @{FontSize=14}
            } #StackPanel
            New-UIStackPanel -Orientation Horizontal {
                New-UIStackPanel -Orientation Vertical {
                    New-UIRadioButton 'Original csv filepath' -Margin 20,10,0,0 -BindIsCheckedTo RadioOriginal -Foreground Green
                    New-UIRadioButton 'New csv filepath'       -Margin 20,15,0,0 -BindIsCheckedTo RadioNew -Foreground Red
                } #StackPanel
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBox -Width 500 -Height 20 -Margin 8,6,0,0   -BindTextTo TextboxOrgcsv -Foreground Green
                    New-UITextBox -Width 500 -Height 20 -Margin 10,12,0,0 -BindTextTo TextboxNewcsv -Foreground Green
                } #StackPanel
            } #StackPanel
            New-UITextBlock ("*" * 116) -Margin 20,20,0,0 -Foreground Blue -FontWeight Bold
            # Headers
            New-UITextBlock "Enter the Match column header:"  -Margin 20,0,0,5 -FontWeight Bold -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal {
                New-UITextBlock "Must be the same in both files:" -Margin 20,10,20,0 -AlsoSet @{FontSize=14} -Foreground Black
                New-UITextBox -Width 200 -Height 20 -Foreground Green -Margin 0,10,0,0  -BindTextTo TextboxOrgHeader
            } #StackPanel
            New-UITextBlock ("*" * 116) -Margin 20,20,0,0 -Foreground Blue -FontWeight Bold
            # Read in files
            New-UITextBlock "Read in the 2 files, verify headers, and sort:" -Margin 20,0,0,5 -FontWeight Bold -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal -Margin 20,10,0,0 {
                New-UIButton "Read" -Padding 10,4,10,4 -Align BottomLeft -AlsoSet @{FontSize=14}`
                    -AddClick $Xlsx1master.Scripts.Readx
                New-UITextBlock "Import-CSV files" -Margin 20,10,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                New-UITextBox -Width 150 -Height 20 -Margin 20,10,0,0 -BindTextTo TextboxReadStatus -Foreground Green
            } #StackPanel
            New-UITextBlock ("*" * 116) -Margin 20,20,0,0 -Foreground Blue -FontWeight Bold
            # Calculate Output
            New-UITextBlock "Calculate the output:" -Margin 20,0,0,5 -FontWeight Bold -AlsoSet @{FontSize=14}
            New-UIStackPanel -Orientation Horizontal -Margin 20,10,0,0 {
                New-UIButton "Run" -Padding 10,4,10,4 -Align BottomLeft -Foreground Red -AlsoSet @{FontSize=14}`
                    -AddClick $Xlsx1master.Scripts.Runx
                New-UITextBlock "Analyze and Combine output" -Margin 20,10,0,0 -AlsoSet @{FontSize=14}
            } #StackPane
            New-UITextBlock ("*" * 200) -Margin 20,20,0,0 -Foreground Blue -FontWeight Bold
        } #StackPanel
    } #ScrollViewer
    New-UIStackPanel -GridRow 1  -Margin 0,5,0,0 -Orientation Horizontal {
        New-UIButton "cls"       -Margin 20,10,0,10 -Padding 14,4,14,4 -AddClick {cls; return} 
        New-UIButton "Close"     -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseTab} 
        New-UIButton "Close All" -Margin 10,10,0,10 -Padding 14,4,14,4 -AddClick {& $UIMaster.Scripts.CloseAllTabs} #-Tag $run
    } #StackPanel
} #UIGrid
#endregion
#------------------------------------------------------
# PowerShell script complete