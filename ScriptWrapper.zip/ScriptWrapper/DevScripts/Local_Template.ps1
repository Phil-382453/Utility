<#
.SYNOPSIS
    one line description of what this script does...
.ROLE
    Utility
.FUNCTIONALITY
    Template,Test,Local,Table,NewScript,Phil
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    Text Local
#>
################################################
# Output Type for Local_Svrs - Defaults to Table
# Your script must echo only table data
################################################ 

# Everything past this point is treated as a scriptblock .. and sent to your list of servers .. for remote execution.

""
"#########################"
"HostName: $($env:COMPUTERNAME)"
"User: $($env:USERNAME)"
"-------------------------"
""

Get-Date
