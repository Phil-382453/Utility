start PowerShell.exe "F:\ScriptWrapper\ScriptWrapper.ps1"
rem start PowerShell_ise.exe "F:\ScriptWrapper\ScriptWrapper.ps1"