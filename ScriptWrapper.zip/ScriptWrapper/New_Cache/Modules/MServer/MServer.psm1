﻿
#$Script:MServerRegistryPath = 'HKCU:\Software\MyCorp\PowerShell\MyServer\LastCredWrite'

Function Initialize-MServerCache
{
    Param
    (
        [Parameter()] [switch] $Force
    )
    End
    {
        $Script:MServerCache = "$env:ProgramData\ServerCache"

        if ($Force) { Remove-Item -Path $Script:MServerCache -Recurse -Force }

        if (-not (Test-Path $Script:MServerCache))
        {
            New-Item -ItemType Directory -Path $Script:MServerCache -Force -ErrorAction Stop | Out-Null
        }

        if (!$Global:MServerCache.Keys.Count)
        {
            $Global:MServerCache = @{}
            $Global:MServerCache.ServerCredentialSet = @{}
        }

        if (!$Global:MServerCache.ServerWin32ProcessClass.Keys.Count)
        {
            $Global:MServerCache.ServerWin32ProcessClass = @{}
        }
        
        if (!$Global:MServerCache.ServerDomain.Keys.Count)
        {
            $Global:MServerCache.ServerDomain = @{}
            if (Test-Path "$Script:MServerCache\ServerDomain.xml" -ErrorAction Ignore)
            {
                $Global:MServerCache.ServerDomain = Import-Clixml "$Script:MServerCache\ServerDomain.xml" -ErrorAction Ignore
            }
        }

        if (-not $Script:FirstRunComplete)
        {

            if (-not (Test-Path $Script:MServerRegistryPath))
            {
                New-Item $Script:MServerRegistryPath -Force | Out-Null
            }

            if (-not (Test-Path "$Script:MServerCache\PreCached.xml"))
            {
                Copy-Item "$PSScriptRoot\PreCached.xml" "$Script:MServerCache\PreCached.xml" -Force
            }

            $Global:MServerCache.PreCached = (Import-Clixml "$Script:MServerCache\PreCached.xml").PreCached

            $propertyList = Get-ItemProperty $Script:MServerRegistryPath
            
            if($propertyList.PSObject.Properties){
                $propertyList.PSObject.Properties |
                    Where-Object { $_.Name -notlike 'PS*' } |
                    Where-Object { trap { return $PSItem } [DateTime]$_.Value -lt [DateTime]::Now.AddDays(-7) } |
                    ForEach-Object {
                        trap { continue }
                        Remove-ItemProperty $Script:MServerRegistryPath -Name $_.Name -ErrorAction Ignore
                        Remove-MGenericCredential -CredentialName $_.Name -Type DOMAIN_PASSWORD # funct call
                    }
            }
            $Script:FirstRunComplete = $true
        }
    }
}

Function Get-MServerDomain
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)] [string] $Server
    )
    End
    {
        Initialize-MServerCache # funct call

        $Server = $Server -replace '\..+'

        if ($Global:MServerCache.PreCached.$Server)
        {
            return $Global:MServerCache.PreCached.$Server
        }

        if ($Global:MServerCache.ServerDomain.$Server)
        {
            return $Global:MServerCache.ServerDomain.$Server
        }

#customize        $domainList = 'ent.MyStuff.corp', 'ent.MyStuff.qa', 'ent.MyStuff.dev'

        foreach ($domain in $domainList)
        {
            trap { continue }
            $result = $null
            $result = [System.Net.Dns]::GetHostByName("$server.$domain")

            if ($result.HostName)
            {
                $Global:MServerCache.ServerDomain.$Server = $domain
                try
                {
                    $Global:MServerCache.ServerDomain | Export-Clixml "$Script:MServerCache\ServerDomain.xml"
                }
                catch { }
                return $domain
            }
        }

        Write-Error "No domain found for server: $Server."
    }
}

Function Set-MServerDomain
{
    Param
    (
        [Parameter(ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true, Position=0)] [string] $ComputerName,
        [Parameter(Mandatory=$true, Position=1)] [string] $Domain
    )
    Begin
    {
        Initialize-MServerCache # funct call
    }
    Process
    {
        $Global:MServerCache.ServerDomain.$ComputerName = $domain
    }
    End
    {
        $Global:MServerCache.ServerDomain | Export-Clixml "$Script:MServerCache\ServerDomain.xml"
    }
}

Function Get-MServerCredential
{
    Param
    (
        [Parameter(ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true, Mandatory=$true, Position=0)]
            [Alias('ComputerName')] [string] $Server,
        [Parameter()] [switch] $PassArgHash
    )
    Begin
    {
        Initialize-MServerCache  # funct call
    }
    Process
    {
        $Server = $Server -replace '\..+' # replace period and everything that follows

        $domain = Get-MServerDomain $Server # funct call

# custom settings for unique name resolution scenarios.
#        if ($domain -eq 'MyUniqueStuff.corp')      { $domain = 'Enterprise.MyStuff.corp' }
#        if ($Server -like 'DRX*' -and $Server -notlike 'DRXYN*') { $type = 'Workstation' } else { $type = 'Server' }
        $type = 'Server'


        $credential = $null

        if ($domain)
        {
            $credential = Get-MCredential -Domain $domain -Type $type
            if (!$credential) { Write-Error "No credential found for server: $Server." }
            else
            {
                if ($PassArgHash)
                {
                    @{
                        Credential = $credential
                        ComputerName = "$server.$domain"
                    }
                }
                else
                {
                    $credential
                }
            }
        }
    }
}

Function Join-MServerFqdn
{
    [CmdletBinding(DefaultParameterSetName='String')]
    Param
    (
        [Parameter(ValueFromPipeline=$true, ParameterSetName='String')]
            [Parameter(ValueFromPipelineByPropertyName=$true, ParameterSetName='Object')]
            [Alias('ComputerName')] [string] $Server,
        [Parameter(ValueFromPipeline=$true, ParameterSetName='Object')] [object] $InputObject,
        [Parameter()] [switch] $GetCredential,
        [Parameter()] [switch] $ShowDomain
    )
    Begin
    {
        Initialize-MServerCache
    }
    Process
    {
        $Server = $Server -replace '\..+'

        if ($PSCmdlet.ParameterSetName -eq 'String')
            { $InputObject = [pscustomobject]@{Server=$Server} }

        $domain = $null
        $domain = Get-MServerDomain $Server

        if ($domain)
        {
            $fqdn = "$Server.$domain".ToLower()
        }
        else
        {
            $fqdn = $null
        }

        $selectList = '*', @{Name='ServerFqdn'; Expression={$fqdn}}

        if ($GetCredential)
        {
            $credential = $null
            if ($domain)
            {
                $credential = Get-MServerCredential $Server
            }
            $selectList += @{Name='ServerCredential'; Expression={$credential}}
        }

        if ($ShowDomain)
        {
            $selectList += @{Name='ServerDomain'; Expression={$domain}}
        }
        
        $InputObject | Select-Object $selectList
    }
}

Function Join-MServerDomain
{
    Param
    (
        [Parameter(ValueFromPipeline=$true)] [object] $InputObject,
        [Parameter(ValueFromPipelineByPropertyName=$true)] [Alias('Server')] [string] $ComputerName
    )
    Process
    {
        $domain = $null
        try
        {
            $domain = Get-MServerDomain $ComputerName -ErrorAction Stop
        }
        catch { }
        $InputObject | Set-PropertyValue Domain $domain
    }
}

Function Update-MServerCredential
{
    [CmdletBinding(DefaultParameterSetName='String')]
    Param
    (
        [Parameter(ValueFromPipeline=$true, ParameterSetName='String', Position=0)]
            [Parameter(ValueFromPipelineByPropertyName=$true, ParameterSetName='Object')]
            [Alias('ComputerName')] [string] $Server,
        [Parameter(ValueFromPipeline=$true, ParameterSetName='Object')] [object] $InputObject,
        [Parameter()] [switch] $NoFqdn,
        [Parameter()] [switch] $Force,
        [Parameter()] [switch] $PassThru,
        [Parameter()] [switch] $PassFqdn
    )
    Begin
    {
        Initialize-MServerCache
    }
    Process
    {
        $Server = $Server -replace '\..+'

        if ($PSCmdlet.ParameterSetName -eq 'String') { $InputObject = $Server }

        $serverObj = $Server | Join-MServerFqdn -GetCredential -ErrorAction Stop

        $networkName = if ($NoFqdn.IsPresent) { $Server } else { $serverObj.ServerFqdn }

        if ($serverObj.ServerCredential.UserName -ne "$env:USERDOMAIN\$env:USERNAME")
        {
            $credExists = Get-MGenericCredential -CredentialName $networkName -DomainPassword -GetObject -ErrorAction SilentlyContinue
            if ($Force.IsPresent -or -not $credExists)
            {
                Add-MGenericCredential -CredentialName $networkName -Credential $serverObj.ServerCredential `
                    -Type DOMAIN_PASSWORD -DeleteOnLogin
                $Global:MServerCache.ServerCredentialSet.$networkName = $true
                Start-Sleep -Milliseconds 250
            }

            Set-ItemProperty -Path $Script:MServerRegistryPath -Name $networkName -Value ([DateTime]::Now.ToString()) -Force | Out-Null
        }

        if ($PassThru) { $InputObject }
        elseif ($PassFqdn) { $serverObj.ServerFqdn }
    }
}

Function Remove-MServerCredential
{
    [CmdletBinding(DefaultParameterSetName='String')]
    Param
    (
        [Parameter(ValueFromPipeline=$true, ParameterSetName='String')]
            [Parameter(ValueFromPipelineByPropertyName=$true, ParameterSetName='Object')]
            [Alias('ComputerName')] [string] $Server,
        [Parameter(ValueFromPipeline=$true, ParameterSetName='Object')] [object] $InputObject,
        [Parameter()] [switch] $NoFqdn,
        [Parameter()] [switch] $Force,
        [Parameter()] [switch] $PassThru,
        [Parameter()] [switch] $PassFqdn
    )
    Begin
    {
        Initialize-MServerCache
    }
    Process
    {
        $Server = $Server -replace '\..+'

        if ($PSCmdlet.ParameterSetName -eq 'String') { $InputObject = $Server }

        $serverObj = $Server | Join-MServerFqdn -ErrorAction Stop

        $networkName = if ($NoFqdn.IsPresent) { $Server } else { $serverObj.ServerFqdn }

        if (-not $Force.IsPresent -and -not $Global:MServerCache.ServerCredentialSet.$networkName)
        {
            return
        }

        Remove-MGenericCredential -CredentialName $networkName -Type DOMAIN_PASSWORD

        if ($Global:MServerCache.ServerCredentialSet.ContainsKey($networkName))
        {
            $Global:MServerCache.ServerCredentialSet.Remove($networkName)
            Remove-ItemProperty -Path $Script:MServerRegistryPath -Name $networkName -ErrorAction Ignore | Out-Null
        }

        if ($PassThru) { $InputObject }
        elseif ($PassFqdn) { $serverObj.ServerFqdn }
    }
}

Function Start-MServerProcess
{
    [CmdletBinding(DefaultParameterSetName='String', SupportsShouldProcess=$true)]
    Param
    (
        [Parameter(ValueFromPipeline=$true, ParameterSetName='String')]
            [Parameter(ValueFromPipelineByPropertyName=$true, ParameterSetName='Object')]
            [Alias('ComputerName')] [string] $Server,
        [Parameter(ValueFromPipeline=$true, ParameterSetName='Object')] [object] $InputObject,
        [Parameter(Mandatory=$true, Position=0)] [string] $CommandLine,
        [Parameter()] [string] $CurrentDirectory,
        [Parameter()] [switch] $IsPowerShellScript,
        [Parameter()] [switch] $IsBatchScript,
        [Parameter()] [switch] $WithPsExec,
        [Parameter()] [switch] $PassThru,
        [Parameter()] [switch] $PassFqdn,
        [Parameter()] [switch] $CaptureOutput,
        [Parameter()] [switch] $CapturePowerShell,
        [Parameter()] [switch] $PassRef
    )
    Begin
    {
        Initialize-MServerCache

        $resultGuid = [System.Guid]::NewGuid().ToString()
    }
    Process
    {
        $Server = $Server -replace '\..+'

        if ($PSCmdlet.ParameterSetName -eq 'String') { $InputObject = $Server }
        
        Write-Verbose "Executing process on '$Server'."

        if ($IsPowerShellScript -or $IsBatchScript -or $CapturePowerShell -or $WithPsExec)
        {
            try
            {
                $fqdn = $Server | Update-MServerCredential -PassFqdn -ErrorAction Stop
                [void][System.IO.Directory]::CreateDirectory("\\$fqdn\c$\Temp\MProcess")
            }
            catch
            {
                Write-Error "Unable to create C:\Temp\MProcess directory on '$Server'.`r`n$_"
                return
            }
        }

        $finalCommandLine = $CommandLine
        if ($IsPowerShellScript -or $CapturePowerShell)
        {
            if ($CapturePowerShell)
            {
                $wrapScript = {
                    $text = & { $finalCommandLine } | ConvertTo-Csv
                    '==== OUTPUT ===='
                    [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($text -join "`r`n"))
                }

                $finalCommandLine = "$wrapScript".Replace('$finalCommandLine', $finalCommandLine)
            }

            try
            {
                [System.IO.File]::WriteAllText("\\$fqdn\c$\Temp\MProcess\$resultGuid.ps1", $finalCommandLine)
            }
            catch
            {
                Write-Error "Unable to access \\$fqdn\c$\Temp\"
                return
            }
            $finalCommandLine = "powershell.exe -ExecutionPolicy Bypass -File C:\Temp\MProcess\$resultGuid.ps1"
        }
        elseif ($IsBatchScript)
        {
            try
            {
                [System.IO.File]::WriteAllText("\\$fqdn\c$\Temp\MProcess\$resultGuid.bat", $finalCommandLine)
            }
            catch
            {
                Write-Error "Unable to access \\$fqdn\c$\Temp\"
                return
            }
            $finalCommandLine = "C:\Temp\MProcess\$resultGuid.bat"
        }

        if ($CaptureOutput -or $CapturePowerShell)
        {
            $finalCommandLine = "cmd.exe /c $finalCommandLine > C:\temp\MProcess\$resultGuid.txt"
        }

        if (-not $WithPsExec.IsPresent)
        {

            $serverObj = $Server | Join-MServerFqdn -GetCredential -ErrorAction Stop

            $setProcessClass = 
            {
                $processClass = Get-WmiObject -ComputerName $serverObj.ServerFqdn `
                    -Credential $serverObj.ServerCredential -Class 'Win32_Process' -List

                $Global:MServerCache.ServerWin32ProcessClass.Add($Server, $processClass)
            }

            if (-not ($Global:MServerCache.ServerWin32ProcessClass.Contains($Server)))
            {
                . $setProcessClass
            }

            $processClass = $Global:MServerCache.ServerWin32ProcessClass.$Server

            $executeScript = 
            {
                if ($CurrentDirectory)
                {
                    $result = $processClass.Create($finalCommandLine, $CurrentDirectory)
                }
                else
                {
                    $result = $processClass.Create($finalCommandLine)
                }
            }

            $result = $null
            if ($PSCmdlet.ShouldProcess($Server, "Execute Command Line: $finalCommandLine"))
            {
                try
                {
                    . $executeScript
                }
                catch
                {
                    $Global:MServerCache.ServerWin32ProcessClass.Remove($Server)
                    . $setProcessClass

                    if (-not $processClass) { Write-Error "Unable to connect to '$Server'."; return }

                    . $executeScript
                }
            }
        }
        else
        {
            $result = $null
            $finalArgs = $finalCommandLine -split ' '
            $psExecResult = & "$env:ProgramData\MyStuff\Tools\PsExec.exe" /accepteula \\$fqdn -s -d $finalArgs 2>&1
            if ($psExecResult -split "`r`n" | Where-Object { $_ -match "with process ID (\d+)" })
            {
                $result = @{ProcessId = $Matches[1]}
            }
        }

        if ($PassThru) { $InputObject }
        elseif ($PassFqdn) { $serverObj.ServerFqdn }
        elseif ($PassRef.IsPresent -or $CaptureOutput.IsPresent -or $CapturePowerShell.IsPresent)
        {
            $outputObj = [ordered]@{}
            $outputObj.Server = $Server
            $outputObj.ProcessId = $result.ProcessId

            if ($CaptureOutput -or $CapturePowerShell)
            {
                $outputObj.ResultGuid = $resultGuid
            }
            if ($CapturePowerShell)
            {
                $outputObj.CapturePowerShell = $true
            }

            [pscustomobject]$outputObj
        }
    }
}

Function Wait-MServerProcess
{
    Param
    (
        [Parameter(ValueFromPipeline=$true)] [object] $ProcessReference
    )
    Begin
    {
        $processList = New-Object System.Collections.Generic.List[object]
    }
    Process
    {
        if (-not $ProcessReference) { return }
        $processList.Add($ProcessReference)
    }
    End
    {
        Write-Verbose "Waiting for $($processList.Count) processes."

        while ($processList.Count -gt 0)
        {
            $newProcessList = New-Object object[] $processList.Count
            $processList.CopyTo($newProcessList)

            foreach ($process in $newProcessList)
            {
                trap {
                    Write-Error $_
                    continue
                }
                $server = $process.Server
                $processId = $process.ProcessId
                Write-Verbose "Checking Process $processId on $server."
                $domain = Get-MServerDomain $server
                $credential = Get-MServerCredential $server

                $wmiObject = $null
                $wmiObject = Get-WmiObject -Property ProcessId -Class Win32_Process -Filter "ProcessId = $processId" -ComputerName "$server.$domain" -Credential $credential

                if (-not $wmiObject)
                {
                    Write-Verbose "Process $processId on $server has completed."
                    [void]$processList.Remove($process)

                    Remove-Item "\\$server.$domain\c$\temp\MProcess\$($process.ResultGuid).ps1" -ErrorAction SilentlyContinue
                    Remove-Item "\\$server.$domain\c$\temp\MProcess\$($process.ResultGuid).bat" -ErrorAction SilentlyContinue

                    if ($process.ResultGuid)
                    {
                        $resultGuid = $process.ResultGuid
                        $server | Update-MServerCredential
                        $resultText = Get-Content "\\$server.$domain\c$\temp\MProcess\$resultGuid.txt"
                        Remove-Item "\\$server.$domain\c$\temp\MProcess\$resultGuid.txt"
                        if ($process.CapturePowerShell)
                        {
                            $pastOutput = $false
                            $text = foreach ($line in $resultText)
                            {
                                if ($pastOutput) { $line }
                                if ($line -eq '==== OUTPUT ====') { $pastOutput = $true }
                            }
                            
                            $text = $text -join ''

                            if (-not [String]::IsNullOrWhiteSpace($text))
                            {
                                [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($text)) |
                                    ConvertFrom-Csv |
                                    Set-PropertyValue ComputerName $server
                            }
                        }
                        else
                        {
                            $process | Select-Object *, @{Name='ResultText'; Expression={$resultText}}
                        }
                    }
                }
            }

            if ($processList.Count -ne 0)
            {
                Write-Verbose "Waiting 5 seconds and checking again."
                Start-Sleep -Seconds 5
            }
        }
    }
}

Function Show-MServerExplorer
{
    Param
    (
        [Parameter(Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName)]
            [Alias('Server')] [string] $ComputerName,
        [Parameter(Position=1)] [Alias('Drive')] [string] $Path = 'c:'
    )
    Process
    {
        if (!$ComputerName) { return }
        $newPath = if ($Path -like '*:*') { $Path.Replace(':', '$') }
            elseif ($Path) { "$Path$" }
            else { '' }
        $fqdn = $ComputerName | Update-MServerCredential -PassFqdn
        explorer.exe "\\$fqdn\$newPath"
    }
}

Function Invoke-MServerPowerShell
{
    Param
    (
        [Parameter(ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)] [string] $ComputerName,
        [Parameter(Mandatory=$true, Position=0)] [scriptblock] $Script,
        [Parameter()] [switch] $ReturnsText,
        [Parameter()] [ValidateSet('WinRM', 'HPSA', 'WMI')] [string] $Method = 'WinRM',
        [Parameter()] [int] $Timeout = 3,
        [Parameter()] [object[]] $ArgumentList
    )
    Begin
    {
        $serverHash = [ordered]@{}
    }
    Process
    {
        $serverHash.$ComputerName = $true
    }
    End
    {
        try { [System.IO.File]::Delete("$env:ProgramData\MyStuff\Tools\PsExec.exe") } catch { }
        $serverList = $serverHash.Keys | Select-Object
        $resultList = @()

        if ($Method -in 'WinRM', 'WMI' -and $ReturnsText.IsPresent)
        {
            $scriptText = $Script.ToString()
            $Script = [ScriptBlock]::Create({
                $Error.Clear()
                $result = [ordered]@{}
                $result.ComputerName = $env:COMPUTERNAME
                $result.Output = & { $scriptText } | Out-String
                $result.Errors = $Error
                [pscustomobject]$result
            }.ToString().Replace('$scriptText', $scriptText))
        }

        if ($Method -eq 'WinRM')
        {
            $existingSessions = @{}
            Get-PSSession | ForEach-Object { $existingSessions.($_.ComputerName) = $_ }

            $getSession = {
                $obj = [ordered]@{}
                $obj.ComputerName = $_
                $obj.Domain = Get-MServerDomain $_ -ErrorAction SilentlyContinue
                if ($obj.Domain) { $obj.Fqdn = "$_.$($obj.Domain)" }
                else { $obj.Fqdn = $_ }
                $obj.Session = $existingSessions.($obj.Fqdn)
                [pscustomobject]$obj
            }

            $serverList |
                ForEach-Object $getSession |
                Where-Object { -not $_.Session } |
                Group-Object Domain |
                ForEach-Object {
                    $credArgs = @{}
                    if ($_.Name -and ($_.Name -ne $env:USERDNSDOMAIN -or $env:USERNAME -notlike "R*")) { $credArgs.Credential = Get-MCredential $_.Name Server }
                    $_.Group.Fqdn | New-PSSession @credArgs | Out-Null
                }

            $existingSessions = @{}
            Get-PSSession | ForEach-Object { $existingSessions.($_.ComputerName) = $_ }

            $jobList = $serverList |
                ForEach-Object $getSession |
                Where-Object Session |
                ForEach-Object {
                    Invoke-Command -Session $_.Session -ScriptBlock $Script -ThrottleLimit 100 -AsJob -ArgumentList $ArgumentList
                }

            $jobCount = @($jobList).Count
            $stillRunning = $jobList
            $endTime = [DateTime]::Now.AddMinutes($Timeout)

            $resultList = while ($stillRunning)
            {
                $justCompleted = $stillRunning |
                    Where-Object State -ne Running

                $stillRunning = $stillRunning |
                    Where-Object State -eq Running

                if ($justCompleted)
                {
                    $justCompleted | Receive-Job -Wait -AutoRemoveJob
                }
                if ([DateTime]::Now -gt $endTime)
                {
                    Write-Warning "Gave up waiting."
                    break
                }
                if ($stillRunning)
                {
                    $count = @($stillRunning).Count
                    $serverNames = $stillRunning.Location

                    Write-Verbose "Waiting on jobs for $serverNames ($count servers), max waiting time: $([int]($endTime - [DateTime]::Now).TotalSeconds) seconds."
                    Start-Sleep -Seconds 5
                }
            }

            $resultList = $resultList |
                ForEach-Object {
                    $computerNameProp = New-Object System.Management.Automation.PSNoteProperty 'ComputerName', ($_.PSComputerName -replace '\..+')
                    $_.PSObject.Properties.Add($computerNameProp)
                    $_
                } |
                Select-Object * -ExcludeProperty PSComputerName, RunspaceId, PSSourceJobInstanceId, PSShowComputerName
        }
        elseif ($Method -eq 'HPSA')
        {
            # Because HPSA certs are bad
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
            [System.Net.ServicePointManager]::Expect100Continue = $true
            [System.Net.ServicePointManager]::SecurityProtocol = 'Tls12'

            Set-Hpsa2SearchMode Enabled

            $hpsaSwitches = @{}
            if (!$ReturnsText) { $hpsaSwitches.PSObjectAs = 'XML' }

            $groups = $serverList |
                Where-Object { $_ -match "\AGroup\\(.+?)\\(.+)\Z" } |
                ForEach-Object {
                    [pscustomobject][ordered]@{
                        Mesh = $Matches[1]
                        Name = $Matches[2]
                    }
                }

            if ($groups)
            {
                $jobs = $groups |
                    Get-Hpsa2Group |
                    Start-Hpsa2AdHocScript -Script $Script -Type PowerShell @hpsaSwitches -Timeout $Timeout
            }
            else
            {
                $jobs = $serverList |
                    Start-Hpsa2AdHocScript -Script $Script -Type PowerShell @hpsaSwitches -Timeout $Timeout
            }

            $jobs |
                ForEach-Object {
                    Write-Verbose "Started job '$($_.JobRef.Id)' on '$($_.Mesh)'."
                }

            $resultList = $jobs |
                Wait-Hpsa2Job -Verbose |
                Get-Hpsa2JobResult
        }
        elseif ($Method -in 'PsExec', 'WMI')
        {
            $id = [Guid]::NewGuid().ToString('n')

            $scriptText = $Script.ToString()
            $finalScript = {
                $result = & { $scriptText }
                $xml = [System.Management.Automation.PSSerializer]::Serialize($result, 3)
                $xml | Out-File "C:\Windows\Temp\MServer\$id.xml"
                [System.IO.File]::Delete("C:\Windows\Temp\MServer\$id.ps1")
            }.ToString().Replace('$id', $id).Replace('$scriptText', $scriptText)

            $jobList = foreach ($server in $serverList)
            {
                try
                {
                    $fqdn = $server | Update-MServerCredential -PassFqdn
                }
                catch
                {
                    Write-Error "Unable to update credential for '$server'. $($_.Exception.Message)"
                    continue
                }
                try
                {
                    [void][System.IO.Directory]::CreateDirectory("\\$fqdn\c$\Windows\Temp\MServer")
                    [System.IO.File]::WriteAllText("\\$fqdn\c$\Windows\Temp\MServer\$id.ps1", $finalScript)
                }
                catch
                {
                    Write-Error "Unable to access c`$ to create job file for '$server'. $($_.Exception.Message)"
                    continue
                }

                if ($Method -eq 'WMI')
                {
                    try
                    {
                        $credArgs = Get-MServerCredential -Server $server -PassArgHash
                        Invoke-WmiMethod -Class Win32_Process -Name Create -ArgumentList "powershell.exe -ExecutionPolicy Bypass -File C:\Windows\Temp\MServer\$id.ps1" @credArgs -ErrorAction Stop | Out-Null
                    }
                    catch
                    {
                        Write-Error "Unable to start WMI process for '$server'. $($_.Exception.Message)"
                        continue
                    }
                }

                [pscustomobject][ordered]@{
                    ComputerName = $server
                    Fqdn = $fqdn
                    ScriptFile = "\\$fqdn\c$\Windows\Temp\MServer\$id.ps1"
                    ResultFile = "\\$fqdn\c$\Windows\Temp\MServer\$id.xml"
                    TextFile = "\\$fqdn\c$\Windows\Temp\MServer\$id.txt"
                }
            }

            $jobCount = @($jobList).Count
            $stillRunning = $jobList
            $endTime = [DateTime]::Now.AddMinutes($Timeout)

            $resultList = while ($stillRunning)
            {
                $justCompleted = $stillRunning |
                    Where-Object { [System.IO.File]::Exists($_.ResultFile) }

                $stillRunning = $stillRunning |
                    Where-Object ComputerName -notin $justCompleted.ComputerName

                if ($justCompleted)
                {
                    $justCompleted |
                        ForEach-Object {
                            $server = $_.ComputerName
                            $resultText = [System.IO.File]::ReadAllText($_.ResultFile)
                            [System.IO.File]::Delete($_.ResultFile)
                            [System.IO.File]::Delete($_.ScriptFile)
                            [System.IO.File]::Delete($_.TextFile)
                            [System.Management.Automation.PSSerializer]::Deserialize($resultText) |
                                Select-Object @{Name='ComputerName'; Expression={$server}}, * -ExcludeProperty ComputerName
                        }
                }
                if ([DateTime]::Now -gt $endTime)
                {
                    Write-Warning "Gave up waiting."
                    break
                }
                if ($stillRunning)
                {
                    $count = @($stillRunning).Count
                    $serverNames = $stillRunning.ComputerName

                    Write-Verbose "Waiting on jobs for $serverNames ($count servers), max waiting time: $([int]($endTime - [DateTime]::Now).TotalSeconds) seconds."
                    Start-Sleep -Seconds 5
                }
            }
        }

        $propertyList = [ordered]@{}
        $propertyList.Add('ComputerName', $true)
        $resultDict = @{}
        foreach ($result in $resultList)
        {
            foreach ($property in $result.PSObject.Properties.Name)
            {
                if (!($propertyList[$property]))
                {
                    $propertyList.Add($property, $true)
                }
            }
            $serverName = $result.ComputerName
            if ($resultDict.ContainsKey($serverName))
            {
                $resultDict[$serverName].Add($result)
            }
            else
            {
                $resultDict.Add($serverName, (New-Object System.Collections.Generic.List[object]))
                $resultDict[$serverName].Add($result)
            }
        }

        $propertyList = $propertyList.Keys | Select-Object

        $serverList |
            ForEach-Object {
                $results = $resultDict[$_]
                if ($results) { $results }
                else
                {
                    [pscustomobject]@{ComputerName=$_}
                }
            } |
            Select-Object $propertyList
    }
}

Function Enter-MPSSession
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)] [string] $ComputerName
    )
    End
    {
        $ComputerName | Update-MServerCredential -NoFqdn
        Enter-PSSession $ComputerName
    }
} 
