﻿# WFServer Module

Contains cmdlets for getting server domain information and running commands on remote servers.

Using `Start-WFServerProcess -WithPsExec` requires that the psexec.exe (renamed as psexec.bin)
exist in the module folder.


