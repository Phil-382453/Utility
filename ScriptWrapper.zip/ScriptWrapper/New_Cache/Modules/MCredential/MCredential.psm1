﻿Function Initialize-MCredential
{
    Param
    (
        [Parameter()] [switch] $Force
    )
    End
    {
        if ($Force.IsPresent -or (-not $Global:MCredential.Keys.Count))
        {
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement

            $Global:MCredential = @{}
            $Global:MCredential.Domain = @{}
            $Global:MCredential.StoreMode = 'All'

            $credManDef = @"
            using System;
            using System.Runtime.InteropServices;

            namespace PsUtils
            {
                public class CredMan
                {
                    #region Imports
                    // DllImport derives from System.Runtime.InteropServices
                    [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredDeleteW", CharSet = CharSet.Unicode)]
                    private static extern bool CredDeleteW([In] string target, [In] CRED_TYPE type, [In] int reservedFlag);

                    [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredEnumerateW", CharSet = CharSet.Unicode)]
                    private static extern bool CredEnumerateW([In] string Filter, [In] int Flags, out int Count, out IntPtr CredentialPtr);

                    [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredFree")]
                    private static extern void CredFree([In] IntPtr cred);

                    [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredReadW", CharSet = CharSet.Unicode)]
                    private static extern bool CredReadW([In] string target, [In] CRED_TYPE type, [In] int reservedFlag, out IntPtr CredentialPtr);

                    [DllImport("Advapi32.dll", SetLastError = true, EntryPoint = "CredWriteW", CharSet = CharSet.Unicode)]
                    private static extern bool CredWriteW([In] ref Credential userCredential, [In] UInt32 flags);
                    #endregion

                    #region Fields
                    public enum CRED_FLAGS : uint
                    {
                        NONE = 0x0,
                        PROMPT_NOW = 0x2,
                        USERNAME_TARGET = 0x4
                    }

                    public enum CRED_ERRORS : uint
                    {
                        ERROR_SUCCESS = 0x0,
                        ERROR_INVALID_PARAMETER = 0x80070057,
                        ERROR_INVALID_FLAGS = 0x800703EC,
                        ERROR_NOT_FOUND = 0x80070490,
                       ERROR_NO_SUCH_LOGON_SESSION = 0x80070520,
                        ERROR_BAD_USERNAME = 0x8007089A
                    }

                    public enum CRED_PERSIST : uint
                    {
                        SESSION = 1,
                       LOCAL_MACHINE = 2,
                        ENTERPRISE = 3
                    }

                    public enum CRED_TYPE : uint
                    {
                        GENERIC = 1,
                        DOMAIN_PASSWORD = 2,
                        DOMAIN_CERTIFICATE = 3,
                        DOMAIN_VISIBLE_PASSWORD = 4,
                        GENERIC_CERTIFICATE = 5,
                        DOMAIN_EXTENDED = 6,
                        MAXIMUM = 7,      // Maximum supported cred type
                        MAXIMUM_EX = (MAXIMUM + 1000),  // Allow new applications to run on old OSes
                    }

                    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
                    public struct Credential
                    {
                        public CRED_FLAGS Flags;
                        public CRED_TYPE Type;
                        public string TargetName;
                        public string Comment;
                        public DateTime LastWritten;
                        public UInt32 CredentialBlobSize;
                        public string CredentialBlob;
                        public CRED_PERSIST Persist;
                        public UInt32 AttributeCount;
                        public IntPtr Attributes;
                        public string TargetAlias;
                        public string UserName;
                    }

                    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
                    private struct NativeCredential
                    {
                        public CRED_FLAGS Flags;
                        public CRED_TYPE Type;
                        public IntPtr TargetName;
                        public IntPtr Comment;
                        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
                        public UInt32 CredentialBlobSize;
                        public IntPtr CredentialBlob;
                        public UInt32 Persist;
                        public UInt32 AttributeCount;
                        public IntPtr Attributes;
                        public IntPtr TargetAlias;
                        public IntPtr UserName;
                    }
                    #endregion

                    #region Child Class
                    private class CriticalCredentialHandle : Microsoft.Win32.SafeHandles.CriticalHandleZeroOrMinusOneIsInvalid
                    {
                        public CriticalCredentialHandle(IntPtr preexistingHandle)
                        {
                            SetHandle(preexistingHandle);
                        }

                        private Credential XlateNativeCred(IntPtr pCred)
                        {
                            NativeCredential ncred = (NativeCredential)Marshal.PtrToStructure(pCred, typeof(NativeCredential));
                            Credential cred = new Credential();
                            cred.Type = ncred.Type;
                            cred.Flags = ncred.Flags;
                            cred.Persist = (CRED_PERSIST)ncred.Persist;

                            long LastWritten = ncred.LastWritten.dwHighDateTime;
                            LastWritten = (LastWritten << 32) + ncred.LastWritten.dwLowDateTime;
                            cred.LastWritten = DateTime.FromFileTime(LastWritten);

                            cred.UserName = Marshal.PtrToStringUni(ncred.UserName);
                            cred.TargetName = Marshal.PtrToStringUni(ncred.TargetName);
                            cred.TargetAlias = Marshal.PtrToStringUni(ncred.TargetAlias);
                            cred.Comment = Marshal.PtrToStringUni(ncred.Comment);
                            cred.CredentialBlobSize = ncred.CredentialBlobSize;
                            if (0 < ncred.CredentialBlobSize)
                            {
                                cred.CredentialBlob = Marshal.PtrToStringUni(ncred.CredentialBlob, (int)ncred.CredentialBlobSize / 2);
                            }
                            return cred;
                        }

                        public Credential GetCredential()
                        {
                            if (IsInvalid)
                            {
                                throw new InvalidOperationException("Invalid CriticalHandle!");
                            }
                            Credential cred = XlateNativeCred(handle);
                            return cred;
                        }

                        public Credential[] GetCredentials(int count)
                        {
                            if (IsInvalid)
                            {
                                throw new InvalidOperationException("Invalid CriticalHandle!");
                            }
                            Credential[] Credentials = new Credential[count];
                            IntPtr pTemp = IntPtr.Zero;
                            for (int inx = 0; inx < count; inx++)
                            {
                                pTemp = Marshal.ReadIntPtr(handle, inx * IntPtr.Size);
                                Credential cred = XlateNativeCred(pTemp);
                                Credentials[inx] = cred;
                            }
                            return Credentials;
                        }

                        override protected bool ReleaseHandle()
                        {
                            if (IsInvalid)
                            {
                                return false;
                            }
                            CredFree(handle);
                            SetHandleAsInvalid();
                            return true;
                        }
                    }
                    #endregion

                    #region Custom API
                    public static int CredDelete(string target, CRED_TYPE type)
                    {
                        if (!CredDeleteW(target, type, 0))
                        {
                            return Marshal.GetHRForLastWin32Error();
                        }
                        return 0;
                    }

                    public static int CredEnum(string Filter, out Credential[] Credentials)
                    {
                        int count = 0;
                        int Flags = 0x0;
                        if (string.IsNullOrEmpty(Filter) ||
                            "*" == Filter)
                        {
                            Filter = null;
                            if (6 <= Environment.OSVersion.Version.Major)
                            {
                                Flags = 0x1; //CRED_ENUMERATE_ALL_CREDENTIALS; only valid is OS >= Vista
                            }
                        }
                        IntPtr pCredentials = IntPtr.Zero;
                        if (!CredEnumerateW(Filter, Flags, out count, out pCredentials))
                        {
                            Credentials = null;
                            return Marshal.GetHRForLastWin32Error(); 
                        }
                        CriticalCredentialHandle CredHandle = new CriticalCredentialHandle(pCredentials);
                        Credentials = CredHandle.GetCredentials(count);
                        return 0;
                    }

                    public static int CredRead(string target, CRED_TYPE type, out Credential Credential)
                    {
                        IntPtr pCredential = IntPtr.Zero;
                        Credential = new Credential();
                        if (!CredReadW(target, type, 0, out pCredential))
                        {
                            return Marshal.GetHRForLastWin32Error();
                        }
                        CriticalCredentialHandle CredHandle = new CriticalCredentialHandle(pCredential);
                        Credential = CredHandle.GetCredential();
                        return 0;
                    }

                    public static int CredWrite(Credential userCredential)
                    {
                        if (!CredWriteW(ref userCredential, 0))
                        {
                            return Marshal.GetHRForLastWin32Error();
                        }
                        return 0;
                    }

                    #endregion

                    private static int AddCred()
                    {
                        Credential Cred = new Credential();
                        string Password = "Password";
                        Cred.Flags = 0;
                        Cred.Type = CRED_TYPE.GENERIC;
                        Cred.TargetName = "Target";
                        Cred.UserName = "UserName";
                        Cred.AttributeCount = 0;
                        Cred.Persist = CRED_PERSIST.ENTERPRISE;
                        Cred.CredentialBlobSize = (uint)Password.Length;
                        Cred.CredentialBlob = Password;
                        Cred.Comment = "Comment";
                        return CredWrite(Cred);
                    }

                    private static bool CheckError(string TestName, CRED_ERRORS Rtn)
                    {
                        switch(Rtn)
                        {
                            case CRED_ERRORS.ERROR_SUCCESS:
                                Console.WriteLine(string.Format("'{0}' worked", TestName));
                                return true;
                            case CRED_ERRORS.ERROR_INVALID_FLAGS:
                            case CRED_ERRORS.ERROR_INVALID_PARAMETER:
                            case CRED_ERRORS.ERROR_NO_SUCH_LOGON_SESSION:
                            case CRED_ERRORS.ERROR_NOT_FOUND:
                            case CRED_ERRORS.ERROR_BAD_USERNAME:
                                Console.WriteLine(string.Format("'{0}' failed; {1}.", TestName, Rtn));
                                break;
                            default:
                                Console.WriteLine(string.Format("'{0}' failed; 0x{1}.", TestName, Rtn.ToString("X")));
                                break;
                        }
                        return false;
                    }

                    /*
                        * Note: the Main() function is primarily for debugging and testing in a Visual 
                        * Studio session.  Although it will work from PowerShell, it's not very useful.
                        */
                    public static void Main()
                    {
                        Credential[] Creds = null;
                        Credential Cred = new Credential();
                        int Rtn = 0;

                        Console.WriteLine("Testing CredWrite()");
                        Rtn = AddCred();
                        if (!CheckError("CredWrite", (CRED_ERRORS)Rtn))
                        {
                            return;
                        }
                        Console.WriteLine("Testing CredEnum()");
                        Rtn = CredEnum(null, out Creds);
                        if (!CheckError("CredEnum", (CRED_ERRORS)Rtn))
                        {
                            return;
                        }
                        Console.WriteLine("Testing CredRead()");
                        Rtn = CredRead("Target", CRED_TYPE.GENERIC, out Cred);
                        if (!CheckError("CredRead", (CRED_ERRORS)Rtn))
                        {
                            return;
                        }
                        Console.WriteLine("Testing CredDelete()");
                        Rtn = CredDelete("Target", CRED_TYPE.GENERIC);
                        if (!CheckError("CredDelete", (CRED_ERRORS)Rtn))
                        {
                            return;
                        }
                        Console.WriteLine("Testing CredRead() again");
                        Rtn = CredRead("Target", CRED_TYPE.GENERIC, out Cred);
                        if (!CheckError("CredRead", (CRED_ERRORS)Rtn))
                        {
                            Console.WriteLine("if the error is 'ERROR_NOT_FOUND', this result is OK.");
                        }
                    }
                }
            }
"@
            Add-Type $credManDef -ErrorAction Ignore
        }
    }
}

Function Set-MCredentialStoreMode
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)] [ValidateSet('All', 'NoGeneric', 'None')] [string] $Mode
    )
    End
    {
        Initialize-MCredential

        $Global:MCredential.StoreMode = $Mode
    }
}

Function Remove-MCredential
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
            [ValidateSet('ent.MyStuff.corp','ent.MyStuff.qa','ent.MyStuff.dev')]
            [string] $Domain,
        [Parameter(Mandatory=$true, Position=1)]
            [ValidateSet('User', 'Workstation', 'Server')] [string] $Type
    )
    End
    {
        Initialize-MCredential

        trap { continue }

        $Global:MCredential.Domain.$Domain.Remove($Type)
        Remove-MGenericCredential "$Domain\$Type"
    }
}

Function Set-MCredential
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
            [ValidateSet('ent.MyStuff.corp','ent.MyStuff.qa','ent.MyStuff.dev')]
            [string] $Domain,
        [Parameter(Mandatory=$true, Position=1)]
            [ValidateSet('User', 'Workstation', 'Server')] [string] $Type,
        [Parameter(Mandatory=$true, Position=2)] [pscredential] $Credential
    )
    End
    {
        Initialize-MCredential

        if ($Global:MCredential.Domain.$Domain -eq $null) { $Global:MCredential.Domain.$Domain = @{} }

        $Global:MCredential.Domain.$Domain.$Type = $Credential
        Add-MGenericCredential "$Domain\$Type" $Credential -Encrypt
    }
}

Function Get-MCredential
{ 
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
            [ValidateSet('ent.MyStuff.corp','ent.MyStuff.qa','ent.MyStuff.dev')]
            [string] $Domain,
        [Parameter(Mandatory=$true, Position=1)]
            [ValidateSet('User', 'Workstation', 'Server')] [string] $Type,
        [Parameter()] [switch] $PassArgHash
    )
    End
    {
        Initialize-MCredential

        if ($Global:MCredential.Domain.$Domain -eq $null) { $Global:MCredential.Domain.$Domain = @{} }
        if ($Global:MCredential.Domain.$Domain.$Type)
        {
            $cred = $Global:MCredential.Domain.$Domain.$Type
            if ($PassArgHash) { return @{Server = $Domain; Credential = $cred } }
            else { return $cred }
        }

        $canTest = $Domain -notin 'xyzStuff' -or $Domain -eq $env:USERDNSDOMAIN

        if ($canTest)
        {
            $directoryServices = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain', $Domain)

            try
            {
                $credObj = Get-MGenericCredential "$Domain\$Type" -GetObject -Decrypt
                $lastModified = $credObj.LastModified
                $cred = $credObj.Credential
                if ($credObj)
                {
                    $test = $directoryServices.ValidateCredentials($cred.GetNetworkCredential().Username, $cred.GetNetworkCredential().Password, 'Negotiate')
                    if ($test -ne $true) { throw "Invalid credentials." }
                    $Global:MCredential.Domain.$Domain.$Type = $cred
                    if ($PassArgHash) { return @{Server = $Domain; Credential = $cred } }
                    else { return $cred }
                }
            }
            catch { }
        }

        $username = $env:USERNAME.ToLower()
        if ($username -match "\Ar([A-Z]\d+)\Z") { $username = $Matches[1] }
        $getCredArgs = switch ("$Domain\$Type")
        {
            'ent.MyStuff.corp\User'         { @{Message='CORP'  ; UserName="corp\$username"   } }
            'ent.MyStuff.qa\User'           { @{Message='QA'    ; UserName="qa\$username"   } }
            'ent.MyStuff.dev\User'          { @{Message='DEV'   ; UserName="dev\$username"  } }
            'ent.MyStuff.corp\Server'       { @{Message='CORP R' ; UserName="corp\r$username"  } }
            'ent.MyStuff.qa\Server'         { @{Message='QA R'   ; UserName="qa\r$username"  } }
            'ent.MyStuff.dev\Server'        { @{Message='DEV R'  ; UserName="dev\r$username" } }
            'ent.MyStuff.corp\Workstation'  { @{Message='CORP GS_'; UserName="corp\gs_$username"} }
            'ent.MyStuff.qa\Workstation'    { @{Message='QA GS_'; UserName="qa\gs_$username"} }
            default                          { @{Message="$Domain\$Type"                             } }
        }

        $message = $getCredArgs.Message
        if ($lastModified) { $getCredArgs.Message = "$message (Last Modified $lastModified)" }
        $test = $false
        $count = 0
        while (-not $test)
        {
            if ($count -gt 0)
            {
                $getCredArgs.Message = "$message ($count failed attempts)"
            }
            $cred = Get-Credential @getCredArgs
            if (-not $cred) { throw "No credential provided." }
            $test = -not $canTest -or $directoryServices.ValidateCredentials($cred.GetNetworkCredential().Username, $cred.GetNetworkCredential().Password, 'Negotiate')
            $count += 1
        }
        $Global:MCredential.Domain.$Domain.$Type = $cred
        if ($canTest) { Add-MGenericCredential "$Domain\$Type" $cred -Encrypt }
        if ($PassArgHash) { return @{Server = $Domain; Credential = $cred } }
        else { return $cred }
    }
}

Function Get-MCredentialKey
{
    End
    {
        $key = $null
        if ([System.IO.File]::Exists("$env:APPDATA\MCredential.xml"))
        {
            trap { Write-Warning "Error reading existing credential key; creating new one."; continue }
            $key = Import-Clixml "$env:APPDATA\MCredential.xml"
            if ($key.Length -ne 32) { $key = $null }
        }
        if (-not $key)
        {
            $key = New-Object Byte[] 32
            [Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($key)
            $key | Export-Clixml "$env:APPDATA\MCredential.xml"
        }
        $key
    }
}

Function Add-MGenericCredential
{
    Param
    (
        [Parameter(Mandatory=$true, Position=0)] [string] $CredentialName,
        [Parameter(Mandatory=$true, Position=1, ParameterSetName='Credential')] [pscredential] $Credential,
        [Parameter(Mandatory=$true, Position=1, ParameterSetName='String')] [string] $Username,
        [Parameter(Mandatory=$true, Position=2, ParameterSetName='String')] [string] $Password,
        [Parameter()] [ValidateSet('GENERIC', 'DOMAIN_PASSWORD')] [string] $Type = 'GENERIC',
        [Parameter()] [switch] $DeleteOnLogin,
        [Parameter()] [switch] $Encrypt
    )
    End
    {
        Initialize-MCredential

        if ($Global:MCredential.StoreMode -eq 'None') { return }
        if ($Global:MCredential.StoreMode -eq 'NoGeneric' -and $Type -eq 'GENERIC') { return }

        if ($PSCmdlet.ParameterSetName -eq 'Credential')
        {
            $Username = $Credential.UserName
            $Password = $Credential.GetNetworkCredential().Password
        }

        if ($Encrypt)
        {
            $key = Get-MCredentialKey
            $Password = $Password | ConvertTo-SecureString -AsPlainText -Force |
                ConvertFrom-SecureString -Key $key
        }

        $newCred = New-Object PsUtils.CredMan+Credential

        $newCred.TargetName = $CredentialName
        $newCred.Flags = [PsUtils.CredMan+CRED_FLAGS]::NONE
        $newCred.Type = [PsUtils.CredMan+CRED_TYPE]::$Type
        $newCred.UserName = $Username
        $newCred.AttributeCount = 0
        $newCred.Persist = [PsUtils.CredMan+CRED_PERSIST]::ENTERPRISE
        $newCred.CredentialBlobSize = [System.Text.Encoding]::Unicode.GetBytes($Password).Length
        $newCred.CredentialBlob = $Password
        $newCred.Comment = ''

        $writeResult = [PsUtils.CredMan]::CredWrite($newCred)

        if (0 -ne $writeResult)
        {
            throw "An error occurred writing credentials. Code: $writeResult."
        }

        if ($DeleteOnLogin)
        {
            $deleteScript = "$env:APPDATA\DeleteSavedCredentials.bat"
            $deleteLine = "@cmdkey.exe /delete:""$CredentialName""`r`n@del ""$deleteScript"""
            if ([System.IO.File]::Exists($deleteScript))
            {
                $deleteLineList = [System.IO.File]::ReadAllLines($deleteScript)
                $deleteLineList[$deleteLineList.Count - 1] = "$deleteLine"
                [System.IO.File]::WriteAllLines($deleteScript, $deleteLineList)
            }
            else
            {
                [System.IO.File]::WriteAllText($deleteScript, "@echo Deleting saved credentials...`r`n$deleteLine")
            }

            New-Item -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce -ErrorAction SilentlyContinue | Out-Null
            New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce -Name "DeleteSavedCredentials" -Value $deleteScript -ErrorAction SilentlyContinue |
                Out-Null
        }
    }
}

Function Get-MGenericCredential
{
    [CmdletBinding(DefaultParameterSetName='Named')]
    Param
    (
        [Parameter(Mandatory=$true, Position=0, ParameterSetName='Named')] [string] $CredentialName,
        [Parameter(Mandatory=$true, ParameterSetName='List')] [switch] $List,
        [Parameter()] [switch] $GetObject,
        [Parameter()] [switch] $Decrypt,
        [Parameter()] [switch] $DomainPassword
    )
    End
    {
        Initialize-MCredential

        if ($List.IsPresent)
        {
            $credList = [PsUtils.CredMan+Credential[]]@()
            [void][PsUtils.CredMan]::CredEnum('', [ref]$credList)
            foreach ($cred in $credList | Sort-Object Type, TargetName)
            {
                $isMatch = $cred.TargetName -match '(.+)\:target=(.+)'
                if (-not $isMatch)
                {
                    Write-Warning "Unrecognized TargetName: $($cred.TargetName)"
                    continue
                }
                [pscustomobject][ordered]@{
                    CredentialName = $Matches[2]
                    Type = $cred.Type.ToString()
                    UserName = $cred.UserName
                    LastModified = $cred.LastWritten
                }
            }
            return
        }

        $cred = New-Object PsUtils.CredMan+Credential
        $type = [PsUtils.CredMan+CRED_TYPE]::GENERIC
        if ($DomainPassword)
        {
            $type = [PsUtils.CredMan+CRED_TYPE]::DOMAIN_PASSWORD
            $credential = $null
        }
        $result = [PsUtils.CredMan]::CredRead($CredentialName, $type, [Ref]$cred)

        if (0 -ne $result)
        {
            if ($DomainPassword) { return }
            throw "An error occurred reading credentials. Code: $result."
            return
        }
        
        $credentialBlob = $cred.CredentialBlob

        if (!$DomainPassword)
        {
            if ($Decrypt)
            {
                trap {
                    Write-Warning "Unable to decrypt password for '$CredentialName'."
                    return
                }
                $key = Get-MCredentialKey
                $securePassword = $credentialBlob | ConvertTo-SecureString -Key $key -EA SilentlyContinue
            }
            else
            {
                $securePassword = ConvertTo-SecureString $credentialBlob -AsPlainText -Force
            }
            $credential = New-Object System.Management.Automation.PSCredential ($cred.UserName, $securePassword)
        }
        if (-not $GetObject) { return $credential }
        [pscustomobject][ordered]@{
            CredentialName = $cred.TargetName -replace '.+\:target='
            Type = $cred.Type.ToString()
            UserName = $cred.UserName
            LastModified = $cred.LastWritten
            Credential = $credential
        }
    }
}

Function Remove-MGenericCredential
{
    Param
    (
        [Parameter(ValueFromPipelineByPropertyName=$true, Mandatory=$true, Position=0)] [string] $CredentialName,
        [Parameter(ValueFromPipelineByPropertyName=$true)] [ValidateSet('GENERIC', 'DOMAIN_PASSWORD', 'DOMAIN_CERTIFICATE', 'DOMAIN_VISIBLE_PASSWORD', 'GENERIC_CERTIFICATE', 'DOMAIN_EXTENDED', 'MAXIMUM', 'MAXIMUM_EX')]
            [string] $Type = 'GENERIC'
    )
    Begin
    {
        Initialize-MCredential
    }
    Process
    {
        $result = [PsUtils.CredMan]::CredDelete($CredentialName, [PsUtils.CredMan+CRED_TYPE]::$Type)
        if (0 -ne $result)
        {
            throw "An error occurred deleting credentials. Code: $result."
        }
    }
}

Export-ModuleMember Add-MGenericCredential, Get-MCredential, Get-MGenericCredential,
    Remove-MCredential, Remove-MGenericCredential, Set-MCredential, Set-MCredentialStoreMode 
