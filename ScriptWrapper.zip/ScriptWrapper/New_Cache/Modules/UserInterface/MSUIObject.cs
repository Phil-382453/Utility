﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Management.Automation;
using System.Windows;
using System.Windows.Data;

namespace MyStuff.SystemsEngineering.Msui
{
    public sealed class MsuiObjectAdapter : PSPropertyAdapter
    {
        public override Collection<PSAdaptedProperty> GetProperties(object baseObject)
        {
            var MsuiObject = baseObject as MsuiObject;
            if (MsuiObject == null) return null;

            var result = new Collection<PSAdaptedProperty>();
            foreach (var propertyDescriptor in MsuiObject._propertyDescriptors)
            {
                result.Add(new PSAdaptedProperty(propertyDescriptor.Name, MsuiObject._currentValues[propertyDescriptor.Name]));
            }
            return result;
        }

        public override PSAdaptedProperty GetProperty(object baseObject, string propertyName)
        {
            var MsuiObject = baseObject as MsuiObject;
            if (MsuiObject == null) return null;

            if (!MsuiObject._currentValues.ContainsKey(propertyName))
            {
                return new PSAdaptedProperty(propertyName, null);
            }
            return new PSAdaptedProperty(propertyName, MsuiObject._currentValues[propertyName]);
        }

        public override string GetPropertyTypeName(PSAdaptedProperty adaptedProperty)
        {
            var MsuiObject = adaptedProperty.BaseObject as MsuiObject;
            if (MsuiObject == null) return null;

            var propertyDescriptor = MsuiObject._propertyDescriptorHash[adaptedProperty.Name];
            if (propertyDescriptor == null) return null;

            return propertyDescriptor.PropertyType.FullName.ToString();
        }

        public override object GetPropertyValue(PSAdaptedProperty adaptedProperty)
        {
            var MsuiObject = adaptedProperty.BaseObject as MsuiObject;
            if (MsuiObject == null) return null;

            return MsuiObject._currentValues[adaptedProperty.Name];
        }

        public override bool IsGettable(PSAdaptedProperty adaptedProperty)
        {
            return true;
        }

        public override bool IsSettable(PSAdaptedProperty adaptedProperty)
        {
            return true;
        }

        public override void SetPropertyValue(PSAdaptedProperty adaptedProperty, object value)
        {
            var MsuiObject = adaptedProperty.BaseObject as MsuiObject;
            if (MsuiObject == null) return;

            PropertyDescriptor propertyDescriptor = null;
            try
            {
                propertyDescriptor = MsuiObject._propertyDescriptorHash[adaptedProperty.Name];
            } catch { }

            if (propertyDescriptor == null)
            {
                Type type = typeof(object);
                try { value = ((PSObject)value).BaseObject; } catch { }
                try { type = value.GetType(); } catch { }
                MsuiObject.AddProperty(adaptedProperty.Name, type);
                MsuiObject._currentValues[adaptedProperty.Name] = value;
                return;
            }

            try
            {
                value = ((PSObject)value).BaseObject;
            }
            catch { }

            propertyDescriptor.SetValue(MsuiObject, value);
        }

        public override Collection<string> GetTypeNameHierarchy(object baseObject)
        {
            var result = new Collection<string>();
            result.Add("System.Management.Automation.PSCustomObject");
            result.Add("System.Object");
            return result;
        }
    }

    public class MsuiObject : CustomTypeDescriptor, INotifyPropertyChanged
    {
        internal readonly ICollection<PropertyDescriptor> _propertyDescriptors = new List<PropertyDescriptor>();

        internal readonly IDictionary<string, PropertyDescriptor> _propertyDescriptorHash = new System.Collections.Concurrent.ConcurrentDictionary<string, PropertyDescriptor>(StringComparer.OrdinalIgnoreCase);
        internal readonly IDictionary<string, object> _currentValues = new System.Collections.Concurrent.ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        public event PropertyChangedEventHandler PropertyChanged;

        public MsuiObject()
        {

        }
        
        public MsuiObject(PSObject PSObject)
        {
            foreach (var property in PSObject.Properties)
            {
                object value = property.Value;
                Type type = typeof(object);
                if (value is PSObject)
                {
                    PSObject objectAsPsObject = (PSObject)value;
                    if (objectAsPsObject.BaseObject != null && !(objectAsPsObject.BaseObject is PSCustomObject))
                        value = objectAsPsObject.BaseObject;
                }
                try { type = value.GetType(); } catch { }
                AddProperty(property.Name, type);
                _currentValues[property.Name] = value;
            }
        }

        public void AddProperty(string name, Type type)
        {
            var propertyDescriptor = new MsuiObjectPropertyDescriptor(name, type);
            _propertyDescriptors.Add(propertyDescriptor);
            _propertyDescriptorHash[name] = propertyDescriptor;
        }

        public override PropertyDescriptorCollection GetProperties()
        {
            return new PropertyDescriptorCollection(_propertyDescriptors.ToArray());
        }

        public override PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            return GetProperties();
        }

        public override EventDescriptorCollection GetEvents()
        {
            return null;
        }

        public override EventDescriptorCollection GetEvents(Attribute[] attributes)
        {
            return null;
        }

        internal void NotifyOfChange(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        private class MsuiObjectPropertyDescriptor : PropertyDescriptor
        {
            internal readonly Type _type;

            public MsuiObjectPropertyDescriptor(string name, Type type)
                : base(name, null)
            {
                _type = type;
            }

            public override bool CanResetValue(object component)
            {
                throw new NotImplementedException();
            }

            public override Type ComponentType
            {
                get { throw new NotImplementedException(); }
            }

            public override object GetValue(object component)
            {
                MsuiObject obj = (MsuiObject)component;
                object value = null;
                obj._currentValues.TryGetValue(Name, out value);
                return value;
            }

            public override bool IsReadOnly
            {
                get { return false; }
            }

            public override Type PropertyType
            {
                get { return _type; }
            }

            public override void ResetValue(object component)
            {
                throw new NotImplementedException();
            }

            public override void SetValue(object component, object value)
            {
                var oldValue = GetValue(component);

                if (oldValue != value)
                {
                    MsuiObject obj = (MsuiObject)component;
                    obj._currentValues[Name] = value;
                    OnValueChanged(component, new PropertyChangedEventArgs(Name));
                    obj.NotifyOfChange(Name);
                }
            }

            public override bool ShouldSerializeValue(object component)
            {
                throw new NotImplementedException();
            }
        }
    }

    public class MsuiObjectCollection : ObservableCollection<MsuiObject>,INotifyPropertyChanged
    {
        public new event PropertyChangedEventHandler PropertyChanged;

        public new void Add(MsuiObject item)
        {
            item.PropertyChanged += RaiseEvent;
            base.Add(item);
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Count"));
        }
        
        public void Add(MsuiObject item, System.Windows.Threading.Dispatcher dispatcher)
        {
            dispatcher.Invoke((System.Action)delegate
            {
                item.PropertyChanged += RaiseEvent;
                base.Add(item);
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Count"));
            });
        }

        public new void Insert(int index, MsuiObject item)
        {
            item.PropertyChanged += RaiseEvent;
            base.Insert(index, item);
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Count"));
        }

        public new void Remove(MsuiObject item)
        {
            item.PropertyChanged -= RaiseEvent;
            base.Remove(item);
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Count"));
        }

        public new void Clear()
        {
            while (base.Count > 0)
                Remove(base[0]);
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Count"));
        }

        public void RaiseEvent(Object sender, PropertyChangedEventArgs e)
        {
            RaiseEvent();
        }

        public void RaiseEvent()
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("List"));
        }
    }
}