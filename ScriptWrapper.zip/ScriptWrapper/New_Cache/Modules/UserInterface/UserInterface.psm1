﻿[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')
[void][System.Reflection.Assembly]::LoadWithPartialName('WindowsFormsIntegration')

Add-Type @"
namespace MyStuff.SystemsEngineering.Msui
{
    public enum ControlAlignment
    {
        TopLeft, TopCenter, TopRight, TopStretch,
            CenterLeft, Center, CenterRight, CenterStretch,
            BottomLeft, BottomCenter, BottomRight, BottomStretch,
            Stretch, StretchLeft, StretchRight, StretchCenter
    };
}
"@

# ======================================================================================================================
# Magic
# ======================================================================================================================

[void]{

    # Execute this script to update all '# Literally Like Everything' parameters.
    $lineList = $psISE.CurrentFile.Editor.Text -split "`r`n"
    
    $block = $null
    $blockList = for ($i = 0; $i -lt $lineList.Count; $i++)
    {
        $line = $lineList[$i]
        if ($line -match "\AFunction (.+)") { $function = $Matches[1] }
        elseif ($line -eq "        # Literally Like Everything")
        {
            $block = @{}
            $block.Begin = $i + 1
            $block.Lines = New-Object System.Collections.Generic.List[string]
        }
        elseif ($line -eq "    )" -and $block)
        {
            [pscustomobject]$block
            $block = $null
        }
        elseif ($block)
        {
            $block.Lines.Add($line)
        }
    }

    $firstBlockCode = $blockList | Select-Object -First 1 | ForEach-Object { $_.Lines -join "`r`n" }

    $blockList | Select-Object -Skip 1 | Sort-Object Begin -Descending | ForEach-Object {
        $block = $_
        $oldText = $block.Lines -join "`r`n"
        if ($oldText -ne $firstBlockCode)
        {
            Write-Host -ForegroundColor Red "Replacing"
            Write-Host -ForegroundColor Red $oldText
            Write-Host -ForegroundColor Green "With"
            Write-Host -ForegroundColor Green $firstBlockCode
            $lineCount = $block.Lines.Count
            $lastIndex = $block.Lines | Select-Object -Last 1 -ExpandProperty Length
            $psISE.CurrentFile.Editor.Select($block.Begin + 1, 1, $block.Begin + $lineCount, $lastIndex + 1)
            $psISE.CurrentFile.Editor.InsertText($firstBlockCode)
        }
    }

}

# ======================================================================================================================
# Set Property Cmdlet
# ======================================================================================================================
Function Set-UIProperty
{
    Param
    (
        [Parameter(Position=0)] [object] $Control,
        [Parameter(Position=1)] [hashtable] $Properties
    )
    End
    {
        $genericPropertyList = 'Width', 'MinWidth', 'MaxWidth', 'Height', 'MinHeight', 'MaxHeight',
            'AcceptsReturn', 'VerticalScrollBarVisibility', 'HorizontalScrollBarVisibility',
            'DataContext', 'ItemsSource', 'DisplayMemberPath', 'SelectedValuePath',
            'Text', 'Header', 'Orientation', 'IsExpanded', 'TextWrapping', 'Title', 'FontWeight',
            'Background', 'Foreground', 'Rows', 'Columns', 'SelectionMode', 'IsCheckable', 'BorderBrush',
            'Minimum', 'Maximum', 'Tag', 'ShowGridLines', 'Source'

        foreach ($genericProperty in $genericPropertyList)
        {
            if ($Properties.Contains($genericProperty))
            {
                $Control.$genericProperty = $Properties[$genericProperty]
            }
        }

        $isFactory = $Properties.Contains('AsFactory') -and $Properties['AsFactory']

        if (!$isFactory)
        {
            if ($Properties.Contains('Content'))
            {
                $content = $Properties['Content']
                if ($content -is [scriptblock]) { $content = & $content }
                $Control.Content = $content
            }
            if ($Properties.Contains('Children')) { & $Properties['Children'] | ForEach-Object { $Control.AddChild($_) } }
            if ($Properties.Contains('Child')) { & $Properties['Child'] | ForEach-Object { $Control.AddChild($_) } }
            if ($Properties.Contains('Items')) { & $Properties['Items'] | ForEach-Object { $Control.AddChild($_) } }
        }

        if ($Properties.Contains('LayoutTransform'))
        {
            $transform = $Properties['LayoutTransform']
            if ($transform -is [scriptblock]) { $transform = & $transform }
            $Control.LayoutTransform = $transform
        }
        if ($Properties.Contains('ContextMenu'))
        {
            $contextMenu = $Properties['ContextMenu']
            if ($contextMenu -is [scriptblock]) { $contextMenu = & $contextMenu }
            $Control.ContextMenu = $contextMenu
        }

        if ($Properties.Contains('Margin')) { $Control.Margin = New-Object System.Windows.Thickness $Properties['Margin'] }
        if ($Properties.Contains('Padding')) { $Control.Padding = New-Object System.Windows.Thickness $Properties['Padding'] }
        if ($Properties.Contains('BorderThickness')) { $Control.BorderThickness = New-Object System.Windows.Thickness $Properties['BorderThickness'] }
        if ($Properties.Contains('CornerRadius')) { $Control.CornerRadius = New-Object System.Windows.CornerRadius $Properties['CornerRadius'] }
        if ($Properties.Contains('GridRow')) { [System.Windows.Controls.Grid]::SetRow($Control, $Properties['GridRow']) }
        if ($Properties.Contains('GridRowSpan')) { [System.Windows.Controls.Grid]::SetRowSpan($Control, $Properties['GridRowSpan']) }
        if ($Properties.Contains('GridCol')) { [System.Windows.Controls.Grid]::SetColumn($Control, $Properties['GridCol']) }
        if ($Properties.Contains('GridColSpan')) { [System.Windows.Controls.Grid]::SetColumnSpan($Control, $Properties['GridColSpan']) }
        if ($Properties.Contains('Dock')) { [System.Windows.Controls.DockPanel]::SetDock($Control, $Properties['Dock']) }
        if ($Properties.Contains('Align'))
        {
            $align = $Properties['Align']
            if ($align -in 'TopLeft', 'TopRight', 'TopCenter', 'TopStretch') { $Control.VerticalAlignment = 'Top' }
            elseif ($align -in 'CenterLeft', 'CenterRight', 'Center', 'CenterStretch') { $Control.VerticalAlignment = 'Center' }
            elseif ($align -in 'BottomLeft', 'BottomRight', 'BottomCenter', 'BottomStretch') { $Control.VerticalAlignment = 'Bottom' }
            else { $Control.VerticalAlignment = 'Stretch' }
            if ($align -in 'TopLeft', 'CenterLeft', 'BottomLeft', 'StretchLeft') { $Control.HorizontalAlignment = 'Left' }
            elseif ($align -in 'TopCenter', 'Center', 'BottomCenter', 'StretchCenter') { $Control.HorizontalAlignment = 'Center' }
            elseif ($align -in 'TopRight', 'CenterRight', 'BottomRight', 'StretchRight') { $Control.HorizontalAlignment = 'Right' }
            else { $Control.HorizontalAlignment = 'Stretch' }
        }
        if ($Properties.Contains('AlsoSet'))
        {
            foreach ($pair in $Properties['AlsoSet'].GetEnumerator())
            {
                $Control.($pair.Key) = $pair.Value
            }
        }

        if (!$isFactory) { return $Control }

       $type = $Control.GetType()
        $factory = New-Object System.Windows.FrameworkElementFactory $type

        $copyPropertyList = @($genericPropertyList) + @('Margin', 'Padding', 'BorderThickness', 'CornerRadius', 'ContextMenu', 'LayoutTransform')
        if ($AlsoSet.Keys) { $copyPropertyList += @($AlsoSet.Keys) }
        foreach ($copyProperty in $copyPropertyList)
        {
            if (!$Properties.Contains($copyProperty)) { continue }
            $factory.SetValue($type::"${copyProperty}Property", $Control.$copyProperty)
        }

        if ($Properties.Contains('Align'))
        {
            $factory.SetValue($type::HorizontalAlignmentProperty, $Control.HorizontalAlignment)
            $factory.SetValue($type::VerticalAlignmentProperty, $Control.VerticalAlignment)
        }
        if ($Properties.Contains('GridRow')) { $factory.SetValue([System.Windows.Controls.Grid]::RowProperty, $Properties['GridRow']) }
        if ($Properties.Contains('GridRowSpan')) { $factory.SetValue([System.Windows.Controls.Grid]::RowSpanProperty, $Properties['GridRowSpan']) }
        if ($Properties.Contains('GridCol')) { $factory.SetValue([System.Windows.Controls.Grid]::ColumnProperty, $Properties['GridCol']) }
        if ($Properties.Contains('GridColSpan')) { $factory.SetValue([System.Windows.Controls.Grid]::ColumnSpanProperty, $Properties['GridColSpan']) }
        if ($Properties.Contains('Dock')) { $factory.SetValue([System.Windows.Controls.DockPanel]::DockProperty, $Properties['Dock']) }

        foreach ($childName in 'Children', 'Child', 'Content', 'Items')
        {
            if ($Properties[$childName])
            {
                if ($Properties[$childName] -is [scriptblock])
                {
                    $defaultParameterValues = New-Object System.Management.Automation.DefaultParameterDictionary @{"New-UI*:AsFactory"=$true}
                    $varList = New-Object System.Collections.Generic.List[PSVariable]
                    $varList.Add((New-Object PSVariable "PSDefaultParameterValues", $defaultParameterValues, ([System.Management.Automation.ScopedItemOptions]::Private)))
                    foreach ($child in $Properties[$childName].InvokeWithContext($null, $varList, $null))
                    {
                        $factory.AppendChild($child)
                    }
                }
                elseif ($childName -eq 'Content')
                {
                    $factory.SetValue($type::ContentProperty, $Properties['Content'])
                }
            }
        }

        $factory
    }
}

# ======================================================================================================================
# Containers
# ======================================================================================================================

Function Show-UIWindow
{
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Content,
        [Parameter()] [string] $Title,
        [Parameter()] [System.Windows.SizeToContent] $SizeToContent,
        [Parameter()] [System.Windows.ResizeMode] $ResizeMode,
        [Parameter()] [System.Windows.WindowStyle] $WindowStyle,
        [Parameter()] [scriptblock] $AddLoaded,
        [Parameter()] [scriptblock] $AddClosing,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $PassWindow
    )
    End
    {
        $window = New-Object System.Windows.Window
        [System.Windows.Controls.Grid]::SetIsSharedSizeScope($window, $true)
        if ($SizeToContent) { $window.SizeToContent = $SizeToContent }
        if ($ResizeMode) { $window.ResizeMode = $ResizeMode }
        if ($WindowStyle) { $window.WindowStyle = $WindowStyle }
        if ($AddLoaded) { $window.Add_Loaded($AddLoaded) }
        if ($AddClosing) { $window.Add_Closing($AddClosing) }

        Set-UIProperty $window $PSBoundParameters | Out-Null
        
        if ($PassWindow) { return $window }

        [void]$window.Dispatcher.InvokeAsync({ [void]$window.ShowDialog() }).Wait()
    }
}

Function New-UIGrid
{
    [OutputType([System.Windows.Controls.Grid])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [string[]] $RowDefinition,
        [Parameter()] [string[]] $RowSharedSizeGroups,
        [Parameter()] [string[]] $ColDefinition,
        [Parameter()] [string[]] $ColSharedSizeGroups,
        [Parameter()] [bool] $ShowGridLines,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $grid = New-Object System.Windows.Controls.Grid
        $r = 0; $c = 0
        foreach ($rowDefinitionText in $RowDefinition)
        {
            $rowDef = New-Object System.Windows.Controls.RowDefinition
            if ($rowDefinitionText -eq 'Auto') { $rowDef.Height = [System.Windows.GridLength]::Auto }
            elseif ($rowDefinitionText -eq '*') { $rowDef.Height = New-Object System.Windows.GridLength 1, Star }
            elseif ($rowDefinitionText -match '(\d+)\*') { $rowDef.Height = New-Object System.Windows.GridLength $Matches[1], Star }
            else { $rowDef.Height = New-Object System.Windows.GridLength $rowDefinitionText }
            if ($RowSharedSizeGroups) { $rowDef.SharedSizeGroup = $RowSharedSizeGroups[$r] }
            $grid.RowDefinitions.Add($rowDef)
            $r += 1
        }
        foreach ($colDefinitionText in $ColDefinition)
        {
            $colDef = New-Object System.Windows.Controls.ColumnDefinition
            if ($colDefinitionText -eq 'Auto') { $colDef.Width = [System.Windows.GridLength]::Auto }
            elseif ($colDefinitionText -eq '*') { $colDef.Width = New-Object System.Windows.GridLength 1, Star }
            elseif ($colDefinitionText -match '(\d+)\*') { $colDef.Width = New-Object System.Windows.GridLength $Matches[1], Star }
            else { $colDef.Width = New-Object System.Windows.GridLength $colDefinitionText }
            if ($ColSharedSizeGroups) { $colDef.SharedSizeGroup = $ColSharedSizeGroups[$c] }
            $grid.ColumnDefinitions.Add($colDef)
            $c += 1
        }

        if ($AsFactory)
        {
            $factory = Set-UIProperty $grid $PSBoundParameters
            foreach ($row in $grid.RowDefinitions)
            {
                $rowFactory = New-Object System.Windows.FrameworkElementFactory ([System.Windows.Controls.RowDefinition])
                $rowFactory.SetValue([System.Windows.Controls.RowDefinition]::HeightProperty, $row.Height)
                $rowFactory.SetValue([System.Windows.Controls.RowDefinition]::SharedSizeGroupProperty, $row.SharedSizeGroup)
                $factory.AppendChild($rowFactory)
            }
            foreach ($col in $grid.ColumnDefinitions)
            {
                $colFactory = New-Object System.Windows.FrameworkElementFactory ([System.Windows.Controls.ColumnDefinition])
                $colFactory.SetValue([System.Windows.Controls.ColumnDefinition]::WidthProperty, $col.Width)
                $colFactory.SetValue([System.Windows.Controls.RowDefinition]::SharedSizeGroupProperty, $col.SharedSizeGroup)
                $factory.AppendChild($colFactory)
            }
            $factory
        }
        else
        {
            Set-UIProperty $grid $PSBoundParameters
        }
    }
}

Function New-UIStackPanel
{
    [OutputType([System.Windows.Controls.StackPanel])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [System.Windows.Controls.Orientation] $Orientation,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $stackpanel = New-Object System.Windows.Controls.StackPanel

        Set-UIProperty $stackpanel $PSBoundParameters
    }
}

Function New-UIWrapPanel
{
    [OutputType([System.Windows.Controls.WrapPanel])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [System.Windows.Controls.Orientation] $Orientation,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.WrapPanel

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIDockPanel
{
    [OutputType([System.Windows.Controls.DockPanel])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.DockPanel

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIScrollViewer
{
    [OutputType([System.Windows.Controls.ScrollViewer])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Content,
        [Parameter()] [System.Windows.Controls.ScrollBarVisibility] $VerticalScrollBarVisibility,
        [Parameter()] [System.Windows.Controls.ScrollBarVisibility] $HorizontalScrollBarVisibility,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ScrollViewer

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UITabControl
{
    [OutputType([System.Windows.Controls.TabControl])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Items,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.TabControl

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UITabItem
{
    [OutputType([System.Windows.Controls.TabItem])]
    Param
    (
        [Parameter(Position=0)] [string] $Header,
        [Parameter(Position=1)] [scriptblock] $Content,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.TabItem

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIGroupBox
{
    [OutputType([System.Windows.Controls.GroupBox])]
    Param
    (
        [Parameter(Position=0)] [string] $Header,
        [Parameter(Position=1)] [scriptblock] $Content,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.GroupBox

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIUniformGrid
{
    [OutputType([System.Windows.Controls.Primitives.UniformGrid])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [int] $Rows,
        [Parameter()] [int] $Columns,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Primitives.UniformGrid

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIBorder
{
    [OutputType([System.Windows.Controls.Border])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Child,
        [Parameter()] [System.Windows.Media.Brush] $BorderBrush,
        [Parameter()] [double[]] $BorderThickness,
        [Parameter()] [double[]] $CornerRadius,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Border

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIViewbox
{
    [OutputType([System.Windows.Controls.Viewbox])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Child,
        [Parameter()] [System.Windows.Media.Stretch] $Stretch,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Viewbox
        if ($Stretch) { $control.Stretch = $Stretch }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIExpander
{
    [OutputType([System.Windows.Controls.Expander])]
    Param
    (
        [Parameter(Position=0)] [string] $Header,
        [Parameter(Position=1)] [scriptblock] $Content,
        [Parameter()] [bool] $IsExpanded,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Expander

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIContentControl
{
    [OutputType([System.Windows.Controls.ContentControl])]
    Param
    (
        [Parameter()] [string] $BindContentTo,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ContentControl
        if ($BindContentTo) { [void]$control.SetBinding([System.Windows.Controls.ContentControl]::ContentProperty, $BindContentTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIItemsControl
{
    [OutputType([System.Windows.Controls.ItemsControl])]
    Param
    (
        [Parameter()] [scriptblock] $ItemTemplate,
        [Parameter()] [string] $BindItemsSourceTo,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ItemsControl
        if ($BindItemsSourceTo) { [void]$control.SetBinding([System.Windows.Controls.ItemsControl]::ItemsSourceProperty, $BindItemsSourceTo) }
        if ($ItemTemplate)
        {
            $dataTemplate = New-Object System.Windows.DataTemplate
            $dataTemplate.VisualTree = & $ItemTemplate
            $control.ItemTemplate = $dataTemplate
        }
        Set-UIProperty $control $PSBoundParameters
    }
}

# ======================================================================================================================
# Simple Controls
# ======================================================================================================================

Function New-UITextBox
{
    [OutputType([System.Windows.Controls.TextBox])]
    Param
    (
        [Parameter()] [string] $BindTextTo,
        [Parameter()] [bool] $AcceptsReturn,
        [Parameter()] [string] $FontWeight,
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [System.Windows.TextWrapping] $TextWrapping,
        [Parameter()] [System.Windows.Controls.ScrollBarVisibility] $VerticalScrollBarVisibility,
        [Parameter()] [System.Windows.Controls.ScrollBarVisibility] $HorizontalScrollBarVisibility,
        [Parameter()] [bool] $SpellCheckIsEnabled,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.TextBox
        if ($SpellCheckIsEnabled) { $control.SpellCheck.IsEnabled = $true }
        if ($BindTextTo) { [void]$control.SetBinding([System.Windows.Controls.TextBox]::TextProperty, $BindTextTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIImage
{
    [OutputType([System.Windows.Controls.TextBlock])]
    Param
    (
        [Parameter(Position=0)] [string] $Source,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [object] $Tag
    )
    End
    {
        $control = New-Object System.Windows.Controls.Image
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIPasswordBox
{
    [OutputType([System.Windows.Controls.PasswordBox])]
    Param
    (
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.PasswordBox
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UITextBlock
{
    [OutputType([System.Windows.Controls.TextBlock])]
    Param
    (
        [Parameter()] [string] $Text,
        [Parameter()] [string] $BindTextTo,
        [Parameter()] [string] $FontWeight,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.TextBlock
        if ($BindTextTo) { [void]$control.SetBinding([System.Windows.Controls.TextBlock]::TextProperty, $BindTextTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIButton
{
    [OutputType([System.Windows.Controls.Button])]
    Param
    (
        [Parameter(Position=0)] [object] $Content,
        [Parameter()] [scriptblock] $AddClick,
        [Parameter()] [double[]] $Padding,
        [Parameter()] [bool] $IsDefault,
        [Parameter()] [bool] $IsCancel,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Button
        if ($IsDefault) { $control.IsDefault = $true }
        if ($IsCancel) { $control.IsCancel = $true }
        if ($AddClick) { $control.Add_Click($AddClick) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIToggleButton
{
    [OutputType([System.Windows.Controls.Primitives.ToggleButton])]
    Param
    (
        [Parameter(Position=0)] [object] $Content,
        [Parameter()] [double[]] $Padding,
        [Parameter()] [string] $BindIsCheckedTo,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Primitives.ToggleButton
        if ($BindIsCheckedTo) { [void]$control.SetBinding([System.Windows.Controls.Primitives.ToggleButton]::IsCheckedProperty, $BindIsCheckedTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIComboBox
{
    [OutputType([System.Windows.Controls.ComboBox])]
    Param
    (
        [Parameter()] [object] $ItemsSource,
        [Parameter()] [string] $DisplayMemberPath,
        [Parameter()] [string] $SelectedValuePath,
        [Parameter()] [scriptblock] $AddSelectionChanged,
        [Parameter()] [string] $BindSelectedValueTo,
        [Parameter()] [string] $BindItemsSourceTo,
        [Parameter()] [string] $BindIsEnabledTo,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ComboBox

        if ($AddSelectionChanged) { $control.Add_SelectionChanged($AddSelectionChanged) }
        if ($BindSelectedValueTo) { [void]$control.SetBinding([System.Windows.Controls.ComboBox]::SelectedValueProperty, $BindSelectedValueTo) }
        if ($BindItemsSourceTo) { [void]$control.SetBinding([System.Windows.Controls.ComboBox]::ItemsSourceProperty, $BindItemsSourceTo) }
        if ($BindIsEnabledTo) { [void]$control.SetBinding([System.Windows.Controls.ComboBox]::IsEnabledProperty, $BindIsEnabledTo) }

        if ($AddClick) { $control.Add_Click($AddClick) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIGridSplitter
{
    [OutputType([System.Windows.Controls.GridSplitter])]
    Param
    (
        [Parameter()] [System.Windows.Media.Brush] $Background,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.GridSplitter

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UICheckBox
{
    [OutputType([System.Windows.Controls.CheckBox])]
    Param
    (
        [Parameter(Position=0)] [object] $Content,
        [Parameter()] [string] $BindIsCheckedTo,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [scriptblock] $AddClick,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.CheckBox
        if ($BindIsCheckedTo) { [void]$control.SetBinding([System.Windows.Controls.CheckBox]::IsCheckedProperty, $BindIsCheckedTo) }
        if($AddClick){ $control.Add_Click($AddClick) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIRadioButton
{
    [OutputType([System.Windows.Controls.RadioButton])]
    Param
    (
        [Parameter(Position=0)] [object] $Content,
       [Parameter()] [string] $BindIsCheckedTo,
        [Parameter()] [bool] $Visibility,
        [Parameter()] [scriptblock] $AddClick,

        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.RadioButton
        if ($BindIsCheckedTo) { [void]$control.SetBinding([System.Windows.Controls.RadioButton]::IsCheckedProperty, $BindIsCheckedTo) }
        if ($AddClick) { $control.Add_Click($AddClick) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UILabel
{
    [OutputType([System.Windows.Controls.Label])]
    Param
    (
        [Parameter(Position=0)] [object] $Content,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Label

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIDatePicker
{
    [OutputType([System.Windows.Controls.DatePicker])]
    Param
    (
        [Parameter()] [string] $BindSelectedDateTo,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.DatePicker

        if ($BindSelectedDateTo) { [void]$control.SetBinding([System.Windows.Controls.DatePicker]::SelectedDateProperty, $BindSelectedDateTo) }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIRichTextBox
{
    [OutputType([System.Windows.Controls.RichTextBox])]
    Param
    (
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.RichTextBox

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIProgressBar
{
    [OutputType([System.Windows.Controls.ProgressBar])]
    Param
    (
        [Parameter()] [double] $Minimum,
        [Parameter()] [double] $Maximum,
        [Parameter()] [string] $BindMaximumTo,
        [Parameter()] [string] $BindValueTo,
        # Literally Like Everything
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        [Parameter()] [System.Windows.Media.Brush] $Background,
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ProgressBar

        if ($BindMaximumTo) { [void]$control.SetBinding([System.Windows.Controls.ProgressBar]::MaximumProperty, $BindMaximumTo) }
        if ($BindValueTo) { [void]$control.SetBinding([System.Windows.Controls.ProgressBar]::ValueProperty, $BindValueTo) }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UISlider
{
    [OutputType([System.Windows.Controls.Slider])]
    Param
    (
        [Parameter()] [System.Windows.Controls.Orientation] $Orientation,
        [Parameter()] [double] $Minimum,
        [Parameter()] [double] $Maximum,
        [Parameter()] [string] $BindValueTo,
        [Parameter()] [System.Windows.Controls.Primitives.TickPlacement] $TickPlacement,
        [Parameter()] [double] $TickFrequency,
        [Parameter()] [double[]] $Ticks,
        [Parameter()] [bool] $IsSnapToTickEnabled,
        [Parameter()] [System.Windows.Media.Brush] $Foreground,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.Slider
        if ($TickPlacement) { $control.TickPlacement = $TickPlacement }
        if ($TickFrequency) { $control.TickFrequency = $TickFrequency }
        if ($Ticks) { $control.Ticks = $Ticks }
        if ($IsSnapToTickEnabled) { $control.IsSnapToTickEnabled = $IsSnapToTickEnabled }
        if ($BindValueTo) { [void]$control.SetBinding([System.Windows.Controls.Slider]::ValueProperty, $BindValueTo) }

        Set-UIProperty $control $PSBoundParameters
    }
}

# ======================================================================================================================
# Complex Controls
# ======================================================================================================================

Function New-UIListView
{
    [OutputType([System.Windows.Controls.ListView])]
    Param
    (
        [Parameter()] [string] $BindItemsSourceTo,
        [Parameter()] [string] $BindSelectedItemTo,
        [Parameter()] [object[]] $Columns,
        [Parameter()] [object] $ItemsSource,
        [Parameter()] [System.Windows.Controls.SelectionMode] $SelectionMode,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.ListView

        if ($Columns)
        {
            $view = New-Object System.Windows.Controls.GridView
            if ($Columns[0] -is [scriptblock]){ $Columns = & $Columns[0] }
            foreach ($column in $Columns)
            {
                if ($column -is [string])
                {
                    $gridViewColumn = New-Object System.Windows.Controls.GridViewColumn
                    $gridViewColumn.Header = $column
                    $gridViewColumn.DisplayMemberBinding = New-Object System.Windows.Data.Binding $column
                    $view.Columns.Add($gridViewColumn)
                }
                elseif ($column -is [System.Windows.Controls.GridViewColumn])
                {
                    $view.Columns.Add($column)
                }
            }
            $control.View = $view
            [void]$PSBoundParameters.Remove('Columns')
        }

        if ($BindItemsSourceTo) { [void]$control.SetBinding([System.Windows.Controls.ListView]::ItemsSourceProperty, $BindItemsSourceTo) }
        if ($BindSelectedItemTo) { [void]$control.SetBinding([System.Windows.Controls.ListView]::SelectedItemProperty, $BindSelectedItemTo) }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIGridViewColumn
{
    [OutputType([System.Windows.Controls.GridViewColumn])]
    Param
    (
        [Parameter(Position=0)] [string] $Header,
        [Parameter(Position=1)] [scriptblock] $CellTemplate,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth
    )
    End
    {
        $control = New-Object System.Windows.Controls.GridViewColumn
        if ($CellTemplate)
        {
            $defaultParameterValues = New-Object System.Management.Automation.DefaultParameterDictionary @{"New-UI*:AsFactory"=$true}
            $varList = New-Object System.Collections.Generic.List[PSVariable]
            $varList.Add((New-Object PSVariable "PSDefaultParameterValues", $defaultParameterValues, ([System.Management.Automation.ScopedItemOptions]::Private)))
            $dataTemplate = New-Object System.Windows.DataTemplate
            $dataTemplate.VisualTree = $CellTemplate.InvokeWithContext($null, $varList, $null)[0]
            $control.CellTemplate = $dataTemplate
        }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIDataGrid
{
    [OutputType([System.Windows.Controls.DataGrid])]
    Param
    (
        [Parameter()] [string] $BindItemsSourceTo,
        [Parameter()] [string[]] $Columns,
        [Parameter()] [object] $ItemsSource,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.DataGrid
        $control.AutoGenerateColumns = $false
        $control.CanUserAddRows = $false
        $control.CanUserDeleteRows = $false

        if ($Columns)
        {
            foreach ($column in $Columns)
            {
                $newColumn = New-Object System.Windows.Controls.DataGridTextColumn
                $newColumn.Header = $column
                $newColumn.Binding = New-Object System.Windows.Data.Binding $column
                $control.Columns.Add($newColumn)
            }
            [void]$PSBoundParameters.Remove('Columns')
        }

        if ($BindItemsSourceTo) { [void]$control.SetBinding([System.Windows.Controls.ListView]::ItemsSourceProperty, $BindItemsSourceTo) }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UITreeView
{
    [OutputType([System.Windows.Controls.TreeView])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [scriptblock] $AddSelectedItemChanged,
        # Literally Like Everything
        [Parameter()] [MyStuff.SystemsEngineering.Msui.ControlAlignment] $Align,
        [Parameter()] [double[]] $Margin,
        [Parameter()] [double] $Width,
        [Parameter()] [double] $MinWidth,
        [Parameter()] [double] $MaxWidth,
        [Parameter()] [double] $Height,
        [Parameter()] [double] $MinHeight,
        [Parameter()] [double] $MaxHeight,
        [Parameter()] [int] $GridRow,
        [Parameter()] [int] $GridRowSpan,
        [Parameter()] [int] $GridCol,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [object] $Tag,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $ContextMenu,
        [Parameter()] [object] $LayoutTransform,
        [Parameter()] [hashtable] $AlsoSet,
        [Parameter()] [switch] $AsFactory
    )
    End
    {
        $control = New-Object System.Windows.Controls.TreeView

        if ($AddSelectedItemChanged) { $control.Add_SelectedItemChanged($AddSelectedItemChanged) }

        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UITreeViewItem
{
    [OutputType([System.Windows.Controls.TreeViewItem])]
    [CmdletBinding(DefaultParameterSetName='Header')]
    Param
    (
        [Parameter(Position=0,ParameterSetName='Header')] [string] $Header,
        [Parameter(Position=0,ParameterSetName='BindHeaderTo')] [string] $BindHeaderTo,
        [Parameter(Position=1)] [scriptblock] $Children,
        [Parameter()] [bool] $IsExpanded,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet

    )
    End
    {
        $control = New-Object System.Windows.Controls.TreeViewItem
        if ($BindHeaderTo) { [void]$control.SetBinding([System.Windows.Controls.TreeViewItem]::HeaderProperty, $BindHeaderTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIMenu
{
    [OutputType([System.Windows.Controls.Menu])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [object] $Tag,
        [Parameter()] [System.Windows.Controls.Dock] $Dock,
        [Parameter()] [int] $GridColSpan,
        [Parameter()] [hashtable] $AlsoSet
    )
    End
    {
        $control = New-Object System.Windows.Controls.Menu
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIContextMenu
{
    [OutputType([System.Windows.Controls.ContextMenu])]
    Param
    (
        [Parameter(Position=0)] [scriptblock] $Children,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet
    )
    End
    {
        $control = New-Object System.Windows.Controls.ContextMenu
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIMenuItem
{
    [OutputType([System.Windows.Controls.MenuItem])]
    Param
    (
        [Parameter(Position=0)] [string] $Header,
        [Parameter(Position=1)] [scriptblock] $Children,
        [Parameter()] [string] $BindIsCheckedTo,
        [Parameter()] [bool] $IsCheckable,
        [Parameter()] [scriptblock] $AddClick,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet
    )
    End
    {
        $control = New-Object System.Windows.Controls.MenuItem
        $control.Header = $Header
        if ($AddClick) { $control.Add_Click($AddClick) }
        if ($BindIsCheckedTo) { [void]$control.SetBinding([System.Windows.Controls.MenuItem]::IsCheckedProperty, $BindIsCheckedTo) }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIScaleTransform
{
    [OutputType([System.Windows.Media.ScaleTransform])]
    Param
    (
        [Parameter()] [double] $Scale,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet
    )
    End
    {
        $control = New-Object System.Windows.Media.ScaleTransform
        if ($Scale) { $control.ScaleX = $Scale; $control.Scaley = $Scale }
        Set-UIProperty $control $PSBoundParameters
    }
}

Function New-UIRotateTransform
{
    [OutputType([System.Windows.Media.RotateTransform])]
    Param
    (
        [Parameter()] [double] $Angle,
        [Parameter()] [object] $DataContext,
        [Parameter()] [object] $Tag,
        [Parameter()] [hashtable] $AlsoSet
    )
    End
    {
        $control = New-Object System.Windows.Media.RotateTransform
        if ($Angle) { $control.Angle = $Angle }
        Set-UIProperty $control $PSBoundParameters
    }
}

# ======================================================================================================================
# Utilities
# ======================================================================================================================

Function Show-UIMessageBox
{
    Param
    (
        [Parameter(ValueFromPipeline=$true,Position=0)] [string] $Message,
        [Parameter()] [string] $Caption,
        [Parameter()] [System.Windows.MessageBoxButton] $Button
    )
    Process
    {
        if ($Button)
        {
            [System.Windows.MessageBox]::Show($Message, "$Caption", $Button).ToString()
        }
        else
        {
            [void][System.Windows.MessageBox]::Show($Message, "$Caption")
        }
    }
}

Function Find-UIParent
{
    Param
    (
        [Parameter()] [string] $Type
    )
    Process
    {
        $parent = $PSCmdlet.SessionState.PSVariable.GetValue('this')
        while ($parent)
        {
            if ($parent.GetType().Name -eq $Type) { return $parent }
            $parent = $parent.Parent
        }
    }
}

Function Find-UISibling
{
    Param
    (
        [Parameter()] [string] $Type
    )
    Process
    {
        $parent = $PSCmdlet.SessionState.PSVariable.GetValue('this').Parent
        while ($parent)
        {
            $siblings = $parent.Children | Where-Object { $_ } | Where-Object { $_.GetType().Name -eq $Type }
            if ($siblings) { return $siblings }
            $parent = $parent.Parent
        }
    }
}

Function New-UIObject
{
    Param
    (
        [Parameter(ValueFromPipeline=$true, Position=0)] [object] $InputObject
    )
    Begin
    {
        if (!([Type]::GetType('MyStuff.SystemsEngineering.Msui.MsuiObject')))
        {
            Add-Type -TypeDefinition ([System.IO.File]::ReadAllText("$PSScriptRoot\MSUIObject.cs")) -ReferencedAssemblies PresentationCore, presentationframework, WindowsBase, System.Xaml
            Update-TypeData -TypeName MyStuff.SystemsEngineering.Msui.MsuiObject -TypeAdapter MyStuff.SystemsEngineering.Msui.MsuiObjectAdapter -Force
        }
    }
    Process
    {
        if ($InputObject)
        {
            New-Object MyStuff.SystemsEngineering.Msui.MsuiObject ([pscustomobject]$InputObject)
        }
        else
        {
            New-Object MyStuff.SystemsEngineering.Msui.MsuiObject
        }
    }
}

Function New-UIObjectCollection
{
   Param
    (
        [Parameter(ValueFromPipeline=$true, Position=0)] [object] $InputObject
    )
    Begin
    {
        if (!([Type]::GetType('MyStuff.SystemsEngineering.Msui.MsuiObject')))
        {
            Add-Type -TypeDefinition ([System.IO.File]::ReadAllText("$PSScriptRoot\MSUIObject.cs")) -ReferencedAssemblies PresentationCore, presentationframework, WindowsBase, System.Xaml
            Update-TypeData -TypeName MyStuff.SystemsEngineering.Msui.MsuiObject -TypeAdapter MyStuff.SystemsEngineering.Msui.MsuiObjectAdapter -Force
        }
        $collection = New-Object MyStuff.SystemsEngineering.Msui.MsuiObjectCollection
    }
    Process
    {
        if ($InputObject)
        {
            if ($InputObject -isnot [MyStuff.SystemsEngineering.Msui.MsuiObject])
            {
                $InputObject = New-Object MyStuff.SystemsEngineering.Msui.MsuiObject ([pscustomobject]$InputObject)
            }
            $collection.Add($InputObject)
        }
    }
    End
    {
        ,$collection
    }
}

Function New-UIPowerShell
{
    End
    {
        if (!([Type]::GetType('MyStuff.SystemsEngineering.Msui.MsuiObject')))
        {
            Add-Type -TypeDefinition ([System.IO.File]::ReadAllText("$PSScriptRoot\MSUIObject.cs")) -ReferencedAssemblies PresentationCore, presentationframework, WindowsBase, System.Xaml
            Update-TypeData -TypeName MyStuff.SystemsEngineering.Msui.MsuiObject -TypeAdapter MyStuff.SystemsEngineering.Msui.MsuiObjectAdapter -Force
        }

        $initialSessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
        $typeData = New-Object System.Management.Automation.Runspaces.TypeData ([MyStuff.SystemsEngineering.Msui.MsuiObject])
        $typeData.TypeAdapter = [MyStuff.SystemsEngineering.Msui.MsuiObjectAdapter]
        $typeEntry = New-Object System.Management.Automation.Runspaces.SessionStateTypeEntry $typeData, $false
        $initialSessionState.Types.Add($typeEntry)
        $typeData = New-Object System.Management.Automation.Runspaces.TypeData ([MyStuff.SystemsEngineering.Msui.MsuiObjectCollection])
        $typeEntry = New-Object System.Management.Automation.Runspaces.SessionStateTypeEntry $typeData, $false
        $initialSessionState.Types.Add($typeEntry)

        $runspace = [RunSpaceFactory]::CreateRunspace($initialSessionState)
        $runspace.ApartmentState = 'STA'
        $runspace.ThreadOptions = 'ReuseThread'
        $runspace.Open()

        $powershell = [PowerShell]::Create()
        $powershell.Runspace = $runspace
        $powershell
    }
}

Function Add-UIEvent
{
    Param
    (
        [Parameter(ValueFromPipeline=$true)] [object] $Control,
        [Parameter(Mandatory=$true,Position=0)] [string] $Event,
        [Parameter(Mandatory=$true,Position=1)] [scriptblock] $Script
    )
    Process
    {
        if (!$Control) { return }
        try
        {
            if ($Control -is [System.Windows.FrameworkElementFactory])
            {
                $delegate = [System.Windows.RoutedEventHandler]$Script
                $Control.AddHandler($Control.Type::"${Event}Event", $delegate)
            }
            else
            {
                $Control."Add_$Event"($Script)
            }
        }
        catch [System.Management.Automation.RuntimeException]
        {
            Write-Error "Event '$Event' is not available for '$($Control.GetType().Name)'."
        }
        
        $Control
    }
}

Register-ArgumentCompleter -CommandName 'Add-UIEvent' -ParameterName 'Event' -ScriptBlock {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)
    
    $pipelineAst = $commandAst.Parent
    if ($pipelineAst -isnot [System.Management.Automation.Language.PipelineAst]) { return }

    $firstCommand = $pipelineAst.PipelineElements[0].CommandElements[0].Value
    if ($firstCommand -eq 'New-UIFactory')
    {
        $firstCommand = "New-UI", $pipelineAst.PipelineElements[0].CommandElements[1].Value -join ''
    }

    if (!$Script:TypeEvents) { $Script:TypeEvents = @{} }
    if (!$Script:TypeEvents.Contains($firstCommand))
    {
        $type = (Get-Command $firstCommand).OutputType.Name
        $events = @()
        if ($type)
        {
            $events = New-Object "$type" | Get-Member -MemberType Event | ForEach-Object Name
        }
        $Script:TypeEvents[$firstCommand] = foreach ($event in $events)
        {
            [System.Management.Automation.CompletionResult]::new($event)
        }
    }
    $Script:TypeEvents[$firstCommand]
}

Function Add-UIBinding
{
    [CmdletBinding(DefaultParameterSetName='Property')]
    Param
    (
        [Parameter(ValueFromPipeline=$true)] [object] $Control,
        [Parameter(Mandatory=$true,Position=0,ParameterSetName='String')] [string] $Property,
        [Parameter(Mandatory=$true,Position=0,ParameterSetName='DependencyProperty')] [System.Windows.DependencyProperty] $DependencyProperty,
        [Parameter(Mandatory=$true,Position=1)] [string] $Path,
        [Parameter()] [System.Windows.Data.BindingMode] $Mode,
        [Parameter()] [ValidateSet('Self')] [string] $RelativeSource,
        [Parameter()] [object] $FallbackValue,
        [Parameter()] [scriptblock[]] $ConverterScript,
        [Parameter()] [hashtable[]] $ConverterDictionary
    )
    Process
    {
        if (!$Control) { return }
        if (!$DependencyProperty)
        {
            $type = $Control.GetType()
            if ($type -eq [System.Windows.FrameworkElementFactory]) { $type = $Control.Type }
            $DependencyProperty = $type::"${Property}Property"
            if (!$DependencyProperty)
            {
                Write-Error "Property '$Property' is not available for '$($type.Name)'."
                $Control
                return
            }
        }
        
        $binding = New-Object System.Windows.Data.Binding $Path
        if ($Mode) { $binding.Mode = $Mode }
        if ($RelativeSource -eq 'Self') { $binding.RelativeSource = [System.Windows.Data.RelativeSource]::Self }
        if ($PSBoundParameters.ContainsKey('FallbackValue')) { $binding.FallbackValue = $FallbackValue }
        if ($ConverterDictionary)
        {
            Add-Type -ReferencedAssemblies PresentationCore, presentationframework, WindowsBase, System.Xaml '
            using System;
            namespace MyStuff.SystemsEngineering.UI
            {
                public class DictionaryConverter: System.Windows.Data.IValueConverter
                {
                    private System.Collections.IDictionary _dictionary;
                    private System.Collections.IDictionary _dictionaryBack;
        
                    public DictionaryConverter(System.Collections.IDictionary dictionary, System.Collections.IDictionary dictionaryBack)
                    {
                        _dictionary = dictionary;
                        _dictionaryBack = dictionaryBack;
                    }
        
                    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
                    {
                        if (_dictionary.Contains(value))
                            return _dictionary[value];
                        else
                            return System.Windows.DependencyProperty.UnsetValue;
                    }

                    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
                    {
                        if (_dictionaryBack != null && _dictionaryBack.Contains(value))
                            return _dictionaryBack[value];
                        else
                            return System.Windows.DependencyProperty.UnsetValue;
                    }
                }
            }
            '
            $binding.Converter = New-Object MyStuff.SystemsEngineering.UI.DictionaryConverter $ConverterDictionary[0], $ConverterDictionary[1]
        }
        if ($ConverterScript)
        {
            Add-Type -ReferencedAssemblies PresentationCore, presentationframework, WindowsBase, System.Xaml '
            using System;
            namespace MyStuff.SystemsEngineering.UI
            {
                public class PowerShellConverter: System.Windows.Data.IValueConverter
                {
                    private System.Management.Automation.PowerShell powershell;
                    private System.Management.Automation.PowerShell powershellBack;

                    public PowerShellConverter(string ScriptBlock, string ScriptBlockBack)
                    {
                        powershell = System.Management.Automation.PowerShell.Create().AddScript(ScriptBlock);
                        if (ScriptBlockBack != null)
                            powershellBack = System.Management.Automation.PowerShell.Create().AddScript(ScriptBlockBack);
                    }
        
                    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
                    {
                        try
                        {
                            powershell.Runspace.SessionStateProxy.SetVariable("_", value);
                            var result = powershell.Invoke();
                            return result[0].BaseObject;
                        }
                        catch
                        {
                            return null;
                        }
                    }

                    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
                    {
                        if (powershellBack == null)
                            return System.Windows.DependencyProperty.UnsetValue;
                        try
                        {
                            powershellBack.Runspace.SessionStateProxy.SetVariable("_", value);
                            var result = powershellBack.Invoke();
                            return result[0].BaseObject;
                        }
                        catch
                        {
                            return null;
                        }
                    }
                }
            }
            '
            $binding.Converter = New-Object MyStuff.SystemsEngineering.UI.PowerShellConverter $ConverterScript[0], $ConverterScript[1]
        }

        if ($Control -is [System.Windows.FrameworkElementFactory])
        {
            $Control.SetBinding($DependencyProperty, $binding)
        }
        else
        {
            [void][System.Windows.Data.BindingOperations]::SetBinding($Control, $dependencyProperty, $binding)
        }

        $Control
    }
}

Register-ArgumentCompleter -CommandName 'Add-UIBinding' -ParameterName 'Property' -ScriptBlock {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)
    
    $pipelineAst = $commandAst.Parent
    if ($pipelineAst -isnot [System.Management.Automation.Language.PipelineAst]) { return }

    $firstCommand = $pipelineAst.PipelineElements[0].CommandElements[0].Value
    if ($firstCommand -eq 'New-UIFactory')
    {
        $firstCommand = "New-UI", $pipelineAst.PipelineElements[0].CommandElements[1].Value -join ''
    }

    if (!$Script:TypeProperties) { $Script:TypeProperties = @{} }
    if (!$Script:TypeProperties.Contains($firstCommand))
    {
        $type = (Get-Command $firstCommand).OutputType.Name
        $properties = @()
        if ($type)
        {
            $properties = New-Object $type | Get-Member -Static -MemberType Property |
                Where-Object Definition -Match "System\.Windows\.DependencyProperty" |
                ForEach-Object Name
        }
        $Script:TypeProperties[$firstCommand] = foreach ($property in $properties)
        {
            [System.Management.Automation.CompletionResult]::new($property -replace "Property\Z")
        }
    }
    $Script:TypeProperties[$firstCommand]
}

Function ConvertTo-Xaml
{
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0)] [object] $UIElement
    )
    Process
    {
        $stream = New-Object System.IO.MemoryStream
        [System.Windows.Markup.XamlWriter]::Save($UIElement, $stream)
        [xml][System.Text.Encoding]::UTF8.GetString($stream.ToArray())
        $stream.Dispose()
    }
}