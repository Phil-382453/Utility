﻿Function Invoke-PBRunAsJob {
    Param(
        [Parameter()] [string[]] $ServerList,
        [Parameter()] [scriptblock] $Script,
        [Parameter()] [object[]]$ArgumentList,
        [Parameter()] [int]$GroupSize = 10,
        [Parameter()] [int]$MaxRunningJobCount = 50
        #[Parameter()] [System.Management.Automation.PSCredential]$cred
    )
    #region - Initialize and get serverlist

    ###################
    $resultList = $null # This will be our return object (at the end)
    $i = 0
    $j = 0
    $srvCount = $serverList.Count
    $GroupCount = [math]::Ceiling($srvCount/$GroupSize) # use ceiling to always round up (13.01 => 14)
    $RemainderCount = ($srvCount%$GroupSize) # server count if the last group is a partial group
    Write-Host "Total server count = $($srvCount)" -f Yellow
    if($GroupCount -gt 1){
        Write-Host "Group size         = $($GroupSize)" -f Yellow
        Write-Host "Number of groups   = $($GroupCount)" -f Yellow
    }
    #endregion
    #----------------------------------------------------------------
    #region - send scriptblock to groups of servers...output to excel 
    $timeSpan  = $null
    $startTime = $(get-date)
    $allJobs   = $null
    $job       = $null
    $Success   = $null
    $fail      = $null
    $1stTime   = $true

    # This section will create groups of servers based on the $GroupSize
    ########################################################################
    # This is the outer most loop for sending blocks (groups) of server jobs
    # - Most runs will be one (or two) servers in a single block
    ########################################################################
    for($CurrentGroupNumber = 1; $CurrentGroupNumber -le $GroupCount; $CurrentGroupNumber++){
        # Calc Runtime and ETA
        $Nowx = Get-Date
        $ts = New-TimeSpan -Start $StartTime -End $Nowx
        $CurrentServerCountx = ($CurrentGroupNumber * $GroupSize)
        $SecPerServer = ($ts.Totalseconds)/$CurrentServerCountx
        $ETA = (($srvCount - $CurrentServerCountx)*($SecPerServer))
        $ETA = [int]($ETA/60) # convert seconds to minutes
        write-host ""
        write-host "================================="
        if($GroupCount -ne 1){
            Write-Host "GroupSize   = $($GroupSize)"
            Write-Host "Group count = " -NoNewline; Write-Host "$($CurrentGroupNumber) "     -f Cyan  -NoNewline; Write-Host "of $($GroupCount)"
            Write-Host "Elapsed     = " -NoNewline; Write-Host "$([int]($ts.TotalMinutes)) " -f Cyan  -NoNewline; Write-Host "Minutes"
            Write-Host "ETA         = " -NoNewline; Write-Host "$($ETA) "                    -f Green -NoNewline; Write-Host "Minutes"
        }

        $serverListx = $null
        $invok       = $null # clear the variable so it only fills with the current group of servers

        # Split ServerList into groups (flag first, middle, and last group)
        switch ($currentGroupNumber){
            1  { #...1st group of servers
                if($SrvCount -lt $GroupSize){ #.........................................this is a partial group
                    if($SrvCount -gt 1){$serverListx = $Serverlist[0..($SrvCount-1)]} 
                    else { $serverListx = $Serverlist }
                } else {$serverListx = $Serverlist[0..($GroupSize-1)]} #...................this is a full group
                break }
            ($GroupCount){ #...last group of servers
                if($RemainderCount -eq 0){ #...full group of servers
                    [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..(($currentGroupNumber*$GroupSize)-1)]
                } else { #...partial group of servers
                    [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..((($currentGroupNumber-1)*$GroupSize)+$RemainderCount-1)]
                } #else
                break }
            default {# Middle groups of servers
                [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..(($currentGroupNumber*$GroupSize)-1)]
                break }
        } #switch
        
        $UIMaster.JobsSentOk = $false
        write-host ""
        write-host "Sending jobs" -f Green -NoNewline
        write-host "...please wait"   

        # Send jobs to the "current group" of servers (split by SmartCard or Creds Manager)
        ###################################################################################
        ###################################################################################
        $Option = New-PSSessionOption -ProxyAccessType NoProxyServer # FQDN not required. 

        foreach ($Computer in $serverListx){ #....Loop - for each server in list
            Try {
                # Choose depending on credentials type
                if($UIMaster.RadioCredsManual -eq $true){ # if menu item checked...
                    if(!($UIMaster.Cred)){$UIMaster.Cred = Get-Credential "SmartCard or Priv"}
                    if(!($UIMaster.Cred)){ return }

                    [array]$invok += invoke-Command -ComputerName $Computer -Credential $UIMaster.Cred `
                            -ScriptBlock $script -SessionOption $Option -ArgumentList $ArgumentList -AsJob -JobName $Computer –ErrorAction Stop #-ErrorVariable customError
                    $anyGoodJobs = $true
                } #if
                else{ # use Credentials Manager
                    [array]$invok += invoke-Command -ComputerName $Computer -Credential (Get-WFServerCredential -Server $Computer) `
                            -ScriptBlock $script -SessionOption $Option -ArgumentList $ArgumentList -AsJob -JobName $Computer #–ErrorAction Stop
                    $JobsSentOk = $true
                } #else
            }
            Catch { #..Catch
                $err1 = $null
                #$err1 = "Error - Sending remote job to - $Computer"
                #$err1 = $Error.Exception
                #$err1 = $Error.Message
                $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message
                Write-Host $err1 -f Yellow               
                $failedObj = New-Object PSObject #...new psobject -help format output (row of data)
                $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $Computer
                $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $err1
                [array]$Fail += $failedObj
                $j++ #...count failed jobs
            } #...End Try/Catch           
        } #foreach

        #####################################################
        #####################################################
        if(-not($JobsSentOk)){
            return [array]$Fail #...................return
        }

        ################################
        # echo job status to the console
        $invok | select Id,Name,PSJobTypeName,State | ft -auto | out-host # echo jobs to console

        #################
        $timeSpan = [timespan]::fromseconds(($(get-date) - $startTime).TotalSeconds)
        Write-Host ("Elapsed time (hh\mm\ss) = {0:hh\:mm\:ss}" -f $timeSpan)

        #####################################################
        #####################################################
        # Monitor running jobs vs complete jobs
        # Confirm-Jobs will loop while waiting for remote jobs to complete.
        # It will auto exit if $RunningJobCount.count -le $MaxRunningJobCount (and not the last server group)
        write-host "Checking jobs" -NoNewline -f Green 
        Write-Host "...please wait"
        Confirm-Jobs $CurrentGroupNumber $MaxRunningJobCount $GroupCount #funct call
        Write-Host ""

        # Start collecting results
        if($UIMaster.ExcelMultiSheet -eq $true){ #comes from the individual script file
            ############################################################
            ###   Start Job Collection - for this pass of the loop   ###
            ############################################################
            $allJobs = Get-Job | Sort-Object state
            foreach ($job in $allJobs) {
                Switch ($job.state) {
                    Completed {
                        $jobx = $null
                        $jobx = Receive-Job -job $job #Get the completed object
                        #######################################################
                        [array]$Success += $jobx

                        Remove-Job $job #Remove this job
                        $i++ #...................................................................count completed jobs
                        break }
                    Failed { #.........................................................collect Job error information
                        $err1,$err1sub,$err1message,$failedObj = $null #...reset variables
                        $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                        ############################################
                        # created an object to hold error message(s) 
                        $failedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $err1
                        [array]$Fail += $failedObj
                        #Cleanup
                        Stop-Job $job; Remove-Job $job #.............................................................remove this job
                        $j++ #......................................................................count failed jobs
                        break}
                    Stopped {
                        ############################################
                        # create an object to hold error messages(s)
                        $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Job Stopped"
                        [array]$Fail += $failedObj
                        #Cleanup
                        Remove-Job $job #.............................................................remove this job
                        $j++ #......................................................................count failed jobs
                        break }
                } #switch
            } #foreach
        } #if ExcelMultiSheet
        else{ # Not ExcelMultiSheet
            
            ######################################
            # Get and Sort by job state
            $allJobs = Get-Job | Sort-Object state
            ######################################
            # Results collection (jobs collection)
            foreach ($job in $allJobs) {
                Switch ($job.state) {
                    Failed { #.........................................................collect Job error information
                        $err1,$err1sub,$err1message,$failedObj = $null #...reset variables
                        $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                        ############################################
                        # created an object to hold error message(s) 
                        $failedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $err1
                        [array]$Fail += $failedObj
                        #Cleanup
                        Stop-Job $job; Remove-Job $job #..............................................remove this job
                        $j++ #......................................................................count failed jobs
                        break}
                    Completed {
                        $jobx = $null
                        $jobx = Receive-Job -job $job #Get the completed object
                        #######################################################
                        [array]$Success += $jobx
                        #Cleanup
                        Remove-Job $job #Remove this job
                        $i++ #...................................................................count completed jobs
                        break }
                    Stopped {
                        ############################################
                        # create an object to hold error messages(s)
                        $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                        $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Job Stopped"
                        [array]$Fail += $failedObj
                        #Cleanup
                        Remove-Job $job #.............................................................remove this job
                        $j++ #......................................................................count failed jobs
                        break }
                } #switch
            } #foreach
        } #else Not ExcelMultiSheet
    } #for
    ########################################
    #endregion - send scriptblock to groups of servers
    #----------------------------------------------------------------
    #region - sort and collect final jobs (last chance before "Script Complete")
    if($UIMaster.ExcelMultiSheet -eq $true){
        ########################################
        # get and sort by job status
        Start-Sleep 2 # sleep 10 sec to allow final jobs to complete
        $allJobs = Get-Job | Sort-Object state
        foreach ($job in $allJobs) {
            Switch ($job.state) {
                Completed {
                    $jobx = $null
                    $jobx = Receive-Job -job $job #Get the completed object
                    #######################################################
                    [array]$Success += $jobx
                    #Cleanup
                    Remove-Job $job #Remove this job
                    $i++ #...................................................................count completed jobs
                    break }
                Failed { #.........................................................collect Job error information
                    $err1,$err1sub,$err1message,$failedObj = $null #...reset variables
                    $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                    ############################################
                    # created an object to hold error message(s) 
                    $failedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $err1
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #..............................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Stopped {
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Job Stopped"
                    [array]$Fail += $failedObj
                    #Cleanup
                    Remove-Job $job #.............................................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Running { #..............................Jobs still running, did not complete for unknown reasons
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $Computer
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Long running job did not complete"
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #.....................................stop and remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Default { #.........................................................collect Job error information
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $job.State
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #..............................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
           } #switch
        } #foreach
    } #if
    else{ # Create $resultList
        ########################################
        # get and sort by job status
        Start-Sleep 2 # sleep 10 sec to allow final jobs to complete
        $allJobs = Get-Job | Sort-Object state
        #############################################
        # Collect jobs again ... llowing final jobs to complete
        foreach ($job in $allJobs) {
            Switch ($job.state) {
                Completed {
                    $jobx = $null
                    $jobx = Receive-Job -job $job #Get the completed object
                    #######################################################
                    [array]$Success += $jobx
                    #Cleanup
                    Remove-Job $job #Remove this job
                    $i++ #...................................................................count completed jobs
                    break }
                Failed { #.........................................................collect Job error information
                    $err1,$err1sub,$err1message,$failedObj = $null #...reset variables
                    $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                    ############################################
                    # created an object to hold error message(s) 
                    $failedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $err1
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #..............................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Stopped {
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Job Stopped"
                    [array]$Fail += $failedObj
                    #Cleanup
                    Remove-Job $job #.............................................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Running { #..............................Jobs still running, did not complete for unknown reasons
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $Computer
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Long running job did not complete"
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #.....................................stop and remove this job
                    $j++ #......................................................................count failed jobs
                    break }
                Default { #.........................................................collect Job error information
                    $failedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Hostname" -Value $job.Location
                    $failedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value $job.State
                    [array]$Fail += $failedObj
                    #Cleanup
                    Stop-Job $job; Remove-Job $job #..............................................remove this job
                    $j++ #......................................................................count failed jobs
                    break }
            } #switch
        } #foreach

        write-host ""
        write-host "==============================="
        write-Host ""
        write-Host "Processing results" -f Green
        Write-Host ""
        Write-Host "Complete" -f Cyan
        Write-Host "========"
        Write-Host ""
    } #else

    ##############################################
    # echo stopwatch...the end of script execution
    $endTime = $(get-date)
    $timeSpan = [timespan]::fromseconds(($endTime - $startTime).TotalSeconds)
    if( $inturrupt -like "*exit=true*" ){ $serverListcount = $i+$j } # if we exited early...recalculate server count.
    else { $serverListcount = $serverList.Count }
    #...write to console

    # Create the Tab Name
    $TabName = "$($UIMaster.SelectedScript.Script)" #run.Name = "$($UIMaster.SelectedScript.Script)"
    #$TabName = $UIMaster.MainTabControl.SelectedItem.Header.Trim()
    $TabName = ($TabName -replace ('.ps1')).Trim() # Might have the file ext (or not)

    #------------------
    # Cleanup old files
    $x = "$($UIMaster.SelectedScript.Script)".Split('.')[0]
    # Before writing new output file ... remove files that match the script name (.csv, .txt, .xlsx)
    #Get-ChildItem -Path "$($UIMaster.WorkingDirectory)" | %{$_.FullName | ?{($_ -like "*$($x)*") -and ($_ -notlike "*$($x)*.xml")}} Out-String | Out-Host
    # is this even working to delete .csv and .txt files? 
    # Get-ChildItem -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)" | %{$_.FullName | ?{($_ -like "$($x)*") -and ($_ -notlike "*$($x)*.xml")}} | Remove-Item -Force

    # Summary ... and  [array]$UIMaster.Fail = failed data
    ("Total execution time (hh\mm\ss) = {0:hh\:mm\:ss}" -f $timeSpan) | out-host
    if ($serverListcount -gt 0)         {
        Write-Host "Total server count = " -NoNewline
        Write-Host "$($serverListcount)" -f Yellow
        
        if(!($UIMaster.ExcelMultiSheet)){$UIMaster.Csv_tabs = ($TabName)} # only 1 tab

        # $UIMaster.Csv_tabs | Out-String | Out-Host
        #---------------------------------------------------------------------------------
        # Export Success to csv|txt file - Required when sendign multi-tab output tab to xlsx...otherwise only output tab...no xlsx file
        ForEach($tab in $UIMaster.Csv_tabs){ # $UIMaster.Csv_tabs - This is set by the individual multi-tab script
            #'1.2'
            # $tab | Out-String | Out-Host
            #'1.3'
            # $Success | gm | Out-String | Out-Host

            # Matche the header name minus time stamp and .ps1 extension.
            # check if success return object has a property name 'Text'
            $testText = $null
            $testText = $Success | gm | ?{($_.MemberType -like "*Property") -and ($_.Name -eq 'Text')} #?

            if($testText){$Ext = 'txt'} else{$Ext = 'csv'}

            if($UIMaster.ExelMultiSheet){
                $Sucx = $Success | select -Expand $tab # data
                $SucOutputPath = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($TabName)-$($tab)"
            } #if
            else{
                $Sucx = $Success # data
                $SucOutputPath = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($TabName)"
            } #else

            #'1.4'
            #$Ext  | Out-String | Out-Host
            #$Sucx | Out-String | Out-Host
            #$SucOutputPath | Out-String | Out-Host
            #----------------------------------------------------------------------------------------------
            # get 1st available output filename (needed if the existing file is open and cannot be deleted).
            $OutFileExt = "$($SucOutputPath).$($Ext)" #This is the starting filename.ext
            $foundit = $false
            Do{ # files have been deleted (that can be). Now find the next available filename.
                if(Test-Path $OutFileExt){ $OutFileExt = $OutFileExt -replace "$($Ext)","1.$($Ext)" }
                else { $foundit = $true }
            } Until ($foundit) #get next available filename for $OutFileCsv
            #----------------------------------------------------------------------------------------------
            # Export to file
            if($Ext -eq 'csv'){ $Sucx | Export-Csv -Path $OutFileExt -NoTypeInformation -Append } #Write to file
            else{ $Sucx.Text | Set-Content -Path $OutFileExt -Force } #Write to file
            #'1.5'
            #pause
        } #for

        [array]$resultList += $Success #Return the data (even though we wrote to csv)
    } #if Success
    if ($j -gt 0){ #if failed
        Write-Host "Failed job count   = $($j)" -f Red
        $UIMaster.Error = $true
        [array]$UIMaster.ErrorData = $Fail #This is the failed data
        $FailOutputPath = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($TabName)-Error"
        #----------------------------------------------------------------------------------------------
        # get 1st avail output file name (needed if the existing file is open and cannot be deleted).
        $OutFileExt = "$($FailOutputPath).csv" #This is the starting filename.ext
        $foundit = $false
        Do{ # files have been deleted (that can be). Now find the next available filename.
            if(Test-Path $OutFileExt){ $OutFileExt = $OutFileExt -replace "csv","1.csv" }
            else { $foundit = $true }
        } Until ($foundit) #get next available filename for $OutFileCsv
        #----------------------------------------------------------------------------------------------
        # Export the file
        $Fail | Export-Csv -Path $OutFileExt -NoTypeInformation -Append # write to file
        #'2.1'
        #$OutFileExt | Out-String | Out-Host
        #'2.2'       | Out-String | Out-Host
        #$Ext        | Out-String | Out-Host
        #$Fail       | Out-String | Out-Host
        #'2.3'       | Out-String | Out-Host
        #$Fail | gm  | Out-String | Out-Host 
    } #if
    if (($serverListcount-$i-$j) -gt 0) {Write-Host "Warning - Success + Failed jobs does NOT Equal Total!" -f Magenta; pause}

    #####################################
    #endregion
    #----------------------------------------------------------------
    Write-Host ""
    Write-Host "PowerShell Script ... " -NoNewline
    Write-Host "Complete" -f Cyan # write to console
    
    ##################################
    #####     Return Results     #####
    ##################################
    $Success = $null
    $Fail = $null
    return $resultList # return data
} #funct Invoke-PBRunAsJob
Function Confirm-Jobs {
    Param($CurrentGroupNumber,$MaxRunningJobCount,$GroupCount)
    $exitLoop = $null
    # This function  will loop while waiting for remote jobs to complete.
    #--------------------------------------------------------------------
    # The popup is to allow Loop Exit while jobs are still "running state" (long running or hung job).
    $wshell = New-Object -ComObject Wscript.Shell -ErrorAction Stop
    $Time = 10             # seconds before "exit loop" popup fades
    $Title = "Exit Loop"
    $Message = "Continue waiting?"
    $ButtonValue = 4      # 0  = OK, 4 = Yes/No
    $DefaultButton = 0    # 0 = 1st button, 256 = 2nd button, 512 = 3rd button
    $iconValue = 32       # 32 = Question symbol
    $k = 0
    $L = 0 # set the initially L counter value.
    #--------------------------------------------------------------------
    # loop while jobs are running...echo status every 20 passes of the loop.
    do {
        $k++ #increment the do loop counter
        if ($k%20 -eq 0) { # echo status every 20 passes of the loop
            $RunningJobCount = Get-Job -State "Running"
            # Keep looping to allow time for running job count to drop below max setting.
            #   ...also if the CurrentGroupNumber IS the last group ... keep looping until stragglers finish. 
            if(($RunningJobCount.count -le $MaxRunningJobCount) -and ($CurrentGroupNumber -ne $GroupCount)){
                $exitLoop = 7 # exit loop ... allows sending the next group of jobs out to remaining servers.
                # echo job count to console
                if(($RunningJobCount.count -eq $null) -or ($RunningJobCount.count -eq "")){
                    Write-Host "    Jobs Running = 0 " -f Yellow
                } 
                elseif($RunningJobCount.count -lt 10){ # show Hostnames instead of Host count if below 10
                    $x = [string]::Join(" ","$($RunningJobCount.Location)")
                    Write-Host "    Jobs Running = $($RunningJobCount.count) " -f Yellow
                    Write-Host " ... $($x)" #show servername - "$($RunningJobCount.Location)"
                } #elseif
                else { Write-Host "    Jobs Running = $($RunningJobCount.count) " -f Yellow } # show Hostname count if -ge 10
            } #if
            else { # this is the last group of servers
                if($RunningJobCount.count -lt 10){ # show Hostnames instead of Host count once below 10
                    $x = [string]::Join(" ","$($RunningJobCount.Location)")
                    Write-Host "    Jobs Running = $($RunningJobCount.count)" -f Yellow -NoNewline
                    Write-Host " ... $($x)"
                } #if
                else{Write-Host "    Jobs Running = $($RunningJobCount.count) " -f Yellow} # show Hostname count if -ge 10
            } #else
        } #if

        # give popup to exit on long running jobs (800 is an arbitrary number that worked for my environment)
        if ($k%800 -eq 0) { # if loop count divided by 800 = 0 ... show the "loop exit" popup.
            $exitLoop = $wshell.Popup($Message,$Time,$Title,$ButtonValue+$iconValue+$DefaultButton)
        } #if
        Start-Sleep -m 100 # 1/100 seconds
    } while ((Get-Job -State "Running") -and ($exitLoop -ne 7)) # controls when to exit loop
    #write-host "Monitoring complete" #................................................write to console
} #funct Confirm-Jobs
Function Convert-ScriptOutputToText {
    Param (
        [Parameter(ValueFromPipeline=$true, ParameterSetName='ScriptBlock', Position=0)] [ScriptBlock] $ScriptBlock,
        [Parameter(ValueFromPipeline=$true, ParameterSetName='ScriptText', Position=0)] [String] $ScriptText
    )
    Process {
        # We need both ScriptText (to insert into the new script)
        # and ScriptBlock (to check for a Param block) so create
        # the one that doesn't exist yet
        if ($ScriptText) { $ScriptBlock = [ScriptBlock]::Create($ScriptText) }
        elseif ($ScriptBlock) { $ScriptText = [string]$ScriptBlock }

        # Create new ScriptText that copies the param block from
        # the ScriptBlock. Also make a $Private:Parameters hashtable
        # that contains the paramaters passed to pass them back
        # to the wrapped script.
        $ScriptText = "$($ScriptBlock.Ast.ParamBlock.Extent.Text)
            `$Private:Parameters = @{} + `$PSBoundParameters
            [pscustomobject]@{Text = & { $ScriptText } @Private:Parameters | Out-String }
        "

        # Return the same type of object passed to this function
        if ($PSCmdlet.ParameterSetName -eq 'ScriptBlock') {
            return [ScriptBlock]::Create($ScriptText)
        } else {
            return $ScriptText
        }
    }
} #funct Convert-ScriptOutputToText
Function Script:Resolve-HelperFunctions {
            <#
            function Script:Get-SubObjects {
                [cmdletbinding()]
                param(
                    [Parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
                    $Object)
                process {
                    if ($object.psobject.Properties.Name -Contains 'SyncRoot') {
                        $subjObjs = $object|Get-Member -MemberType NoteProperty |Where-Object {$_.Definition -match 'System.Object\[\]'}
                        $object.$($subjObjs.Name)
                    } else {
                        $object.psobject.Properties|ForEach-Object {
                          if ($_.TypeNameOfValue -eq 'System.Object[]') {
                                Write-Verbose -Message "Object Found: $($_.Name)"
                                $_.Value
                            }
                        }
                    }
                }
            }
            #>
            function Script:Resolve-DateTimeFromString {
              param([Parameter(Mandatory=$true)]$InputString)
              try {
                [datetime]::Parse($InputString)
              } catch {
                $InputString
              }
            }
            function Script:IfTrue {
                #< #
            #.SYNOPSIS
            #    A helper function to emulate the C# Conditional Operator
            #.DESCRIPTION
            #    When the Function is called it returns one of two values depending on the value of a Boolean expression. Following is the syntax for the conditional operator.
            #
            #.EXAMPLE
               #    PS C:\> $x = 0.2
               #    PS C:\> ($x -ne 0.0) | ?: ([math]::Sin($x) / $x) 1.0
               #    0.993346653975306
            #.EXAMPLE
               #    PS C:\> $false | IfTrue "WooHoo" "Darn!"
               #    Darn!
            # >

                [cmdletbinding()]
                param(
                    [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
                    [object]$Condition,
                    [Parameter(Mandatory = $true, Position = 0)]
                    [object]$firstExpression,
                    [Parameter(Mandatory = $false, Position = 1)]
                    [object]$secondExpression
                )
                process {
                    if ($Condition) { $firstExpression } else { $secondExpression }
                }
            }
            New-Alias -Name ?: -Value IfTrue -Force
            function Script:ConvertFrom-JsonToPsobject {
                [CmdletBinding()]
                param(
                    [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
                    [string]$InputObject,
                    [switch]$NormalizePropertyNames
                )
                process {
                    $jsonOutput = ConvertFrom-Json -InputObject $InputObject
                    $output = @()
                    $jsonOutput |ForEach-Object {
                        $ObjOutput = New-Object -TypeName Psobject
                        $currObj = $_
                        $currObj.psobject.Properties.name |ForEach-Object {
                            $currProp = $_
                            if ($NormalizePropertyNames) {
                                $ObjOutput|Add-Member -MemberType NoteProperty -Name $currProp -Value $currObj.$currProp
                            } else {
                                $ObjOutput|Add-Member -MemberType NoteProperty -Name $currProp -Value $currObj.$currProp
                            }
                        }
                        $output += $ObjOutput
                    }
                    $output
                }
            }
            function Script:Resolve-JsonReferences {
                [Cmdletbinding()]
                param(
                    [Parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
                    [psobject]$Object,
                    [string]$CurrentSubObjectName)
                begin {

                }
                process {
                    [string[]]$Script:SubObjects = $null
                    #if(-not $Object){
                    #    $Object = @($Input)
                    #}
                    [array]$Script:SubObjects += (Get-SubObjects -Object $Object)
                    if ($SubObjects) {
                        $SubObjects | ForEach-Object {
                            if ($currProperty = $_.psobject.properties|Where-Object {$_.Value -match '\$ref'}) {
                                $currProperty.Value = (Get-JsonNetObjectById -parentObj $Object -id $currProperty.Value.'$ref')
                            }
                        }
                    } 
                    else {
                        if ($Object | Where-Object {$_.Value -match '\$ref'}) {
                            $Object = $Object | Where-Object {$_.Value -match '\$ref'} | ForEach-Object {
                                if ($currProperty = $_ | Where-Object {$_.Value -match '\$ref'}) {
                                    $currProperty.Value = (Get-JsonNetObjectById -parentObj $Object -id $currObject.Value.'$ref')
                                }
                            }
                        }
                    }
                    $Object
                }
            }
            if ($PSVersionTable.PSVersion -lt [version]3.0.0) {
                function Script:ConvertFrom-Json([object]$InputObject) {
                    Add-Type -AssemblyName System.Web.Extensions
                    $jsSerializer = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
                    return , $jsSerializer.DeserializeObject($InputObject)
                }
            }
        } 
Function Show_msgbox  {
    Param($msgBody)
    #Add-Type -AssemblyName PresentationCore,PresentationFramework

    $msgBody = "Errors Found!"
    #$msgTitle = "Confirm Reboot"
    #$msgButton = 'YesNoCancel'
    #$msgImage = 'Question'
    #$Result = [System.Windows.MessageBox]::Show($msgBody,$msgTitle,$msgButton,$msgImage)
    #Write-Host "The user chose: $Result [" ($result).value__ "]"
    [System.Windows.MessageBox]::Show($msgBody)
}
Function Confirm-creds {
<#
.Synopsis
   Authenticate [domain\]username and password in the $env:userdomain
.DESCRIPTION
    1. Verify credentials on the...........current domain.
    2. Verification not available on.........other domain.
    3. Failure can be on username, password, other domain.
    4. Verification unavailable on other domain does not imply logon would fail.
    5. Popup to re-enter credentials.
    Authentication is done over a secure channel between the workstation and the DC.
    That communication is encrypted using the 'workstation's' domain credentials.
    This prevents credentials verification with other than the current domain.
    This should not affect access if credentials are entered correctly.
.EXAMPLE
    $cred = Get-Credential                     ...enter admin username and password
    Confirm-creds [-cred | -credential] $cred   ...<verify>
.INPUTS
    output from <get-credential> command
.OUTPUTS
    1. Authentication Success or Failure is written to the console
    2. popup to allow re-enter credentials
#>
    [CmdletBinding()]
    [OutputType([String[]])]
    Param (
        # Param1 help description
        [Parameter(
            Mandatory=$true,
            Position=0, 
            ValueFromRemainingArguments=$false)]
        [ValidateNotNullOrEmpty()]
        [Alias("cred")]
        [System.Management.Automation.PSCredential]$credential 
    ) #Param
    Begin {
        ##################################################
        # Create a message box to re-enter credentials
        $wshell        = New-Object -ComObject Wscript.Shell -ErrorAction Stop
        $Message       = "re-enter credentials?"
        $Time          = 0   # popup fade in 2 sec
        $Title         = ""
        $ButtonValue   = 4   # 0  = OK, 4 = Yes/No
        $DefaultButton = 256 # 0 = 1st button, 256 = 2nd button, 512 = 3rd button
        $iconValue     = 32  # 32 = Question symbol
        $exitLoopcred = $null # reset the loop exit variable
    } #begin
    Process {
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement # load assembly
        $ct = [System.DirectoryServices.AccountManagement.ContextType]::Domain
        
        do {# get user credentials; Verify credentials. Loop until No is clicked or popup fade
            $ErrorActionPreference = 'SilentlyContinue'
            If ($credential -eq $null) {$credential = Get-Credential -credential "" }
            $ErrorActionPreference = 'Continue'
            If ($credential -eq $null) { Write-Host "credentials are empty. Please try again." -foregroundcolor "red" }

            $userName = $credential.username
            $passwrd = $credential.GetNetworkCredential().Password

            # get the domain provided...else use the current domain
            If ($userName.Contains("\")) {$domain = ($userName.Split("\"))[0]}
            Else {$domain = $env:USERDOMAIN} #else use the default domain
    
            $credresult = $null, $credresult = @()
            $credresult += "UserName = $($userName)"
            $credresult += "Domain = $($domain)"

            if($domain -eq $env:USERDOMAIN){
                $pc = New-Object System.DirectoryServices.AccountManagement.PrincipalContext $ct,$domain
                if ($pc.ValidateCredentials($userName,$passwrd)) {
                    [array]$credresult += "Successfully authenticated with domain $($pc.Name)"
                } else {
                    [array]$credresult += "Failed authentication with domain $($pc.Name)"
                } # end else
            } #if
            elseif ($domain -ne $env:USERDOMAIN){ [array]$credresult += "Credentials verification not available." }

            Write-Host "----------------------------------------------------"
            foreach( $line in $credresult ){
                if ($line -like "*UserName*"){ 
                    if($line.length -lt 20){ write-host $line }
                    else { write-host "UserName = smartcard"  } 
                } #if
                if ($line -like "*Failed*"){write-host $line -ForegroundColor Red}
                elseif ($line -like "*Successful*"){write-host $line -ForegroundColor Green}
                elseif ($line -like "*not available*"){write-host "Verification not available across domains" -F Yellow}
            } #for
            Write-Host "----------------------------------------------------"

            $exitLoopcred = $wshell.Popup($Message,$Time,$Title,$ButtonValue+$iconValue+$DefaultButton) 
            if ($exitLoopcred -eq 6) {$credential = Get-Credential -credential ""} 
        } Until ($exitLoopcred -ne 6) # exit loop if "no" is clicked or popup fades
    } #process
    End {
        $passwrd = $null #clear this variable
        return $credential
    } #end
} #funct Verify-credentials
Function Get-FileBrowser {
<#
.Synopsis
    Windows File Browser popup for csv or txt file selection.
.DESCRIPTION
    Windows file browser popup for csv or txt file selection.
    The csv file must contain a header row, and can be any number of columns.
    The server list column header must be "Hostname".
.INPUT
    The starting directory location.
.OUTPUT
    A fully qualified path and filename.
.EXAMPLE
   Get-FileBrowser -iniDir $Inidir
.EXAMPLE
   Get-FileBrowser $Inidir
#>
    [CmdletBinding()]
    [Alias()]
    [OutputType([String])]
    Param (
        # Param1 help description
        [Parameter( Mandatory=$true, 
                    ValueFromPipelineByPropertyName=$true, 
                    Position=0)]
        [ValidateNotNullOrEmpty()]
        [string]$Inidir
    ) #Param
    Begin {
        # required assembly for the OpenFileDialog form
        Add-Type -AssemblyName System.Windows.Forms | Out-Null

        # No white space before/after *.csv and *.txt
        $filetype = "excel files (*.csv)|*.csv|text files (*.txt)|*.txt"
    } #Begin
    Process {
        $dialog = New-Object System.Windows.Forms.OpenFileDialog #.......create a file open form
        $dialog.initialDirectory = $Inidir #.............set the starting directory for browsing
        $dialog.Multiselect = $false #........................allow only one file to be selected
        $result = $dialog.ShowDialog() #.............................make the dialog box visible
    } #Process
    End {
        # validate a file was selected..else echo error message and exit script.
        if ($result -eq 'OK') {
            $filename = $dialog.FileName
        } elseif ($result -eq 'Cancel') {
            write-Host "Cancel button selected." -foregroundcolor "red"
            $filename = "Cancel"
        } #else
        return ($filename)
    } # End
} #funct Get-FileBrowser
Function Get-FolderBrowser {
    Param (
        [Parameter(Mandatory=$false,Position=0)]
        [string]$inidir
    )
    $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
    $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
    $OpenFileDialog = [System.Windows.Forms.OpenFileDialog]::new()
    $OpenFileDialog.AddExtension = $false
    $OpenFileDialog.CheckFileExists = $false
    $OpenFileDialog.DereferenceLinks = $true
    $OpenFileDialog.Filter = "Folders|`n"
    $OpenFileDialog.Multiselect = $false
    $OpenFileDialog.Title = "Select folder"
    $OpenFileDialog.InitialDirectory = $inidir
    $OpenFileDialogType = $OpenFileDialog.GetType()
    $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
    $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null)
    $OpenFileDialogType.GetMethod('OnBeforeVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$IFileDialog)
    [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
    $FolderOptions = $OpenFileDialogType.GetMethod('get_Options',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null) -bor $PickFoldersOption
    $FileDialogInterfaceType.GetMethod('SetOptions',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$FolderOptions)
    $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName,'System.Windows.Forms.FileDialog+VistaDialogEvents',$false,0,$null,$OpenFileDialog,$null,$null).Unwrap()
    [uint32]$AdviceCookie = 0
    $AdvisoryParameters = @($VistaDialogEvent,$AdviceCookie)
    $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdvisoryParameters)
    $AdviceCookie = $AdvisoryParameters[1]
    $Result = $FileDialogInterfaceType.GetMethod('Show',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,[System.IntPtr]::Zero)
    $FileDialogInterfaceType.GetMethod('Unadvise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdviceCookie)
    if ($Result -eq [System.Windows.Forms.DialogResult]::OK) {
        $FileDialogInterfaceType.GetMethod('GetResult',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$null)
    }
    Return $OpenFileDialog.FileName
} #funct Get-FolderBrowser
Function New-OpenFileDialog {
  [CmdletBinding()]
  [OutputType([Microsoft.Win32.OpenFileDialog])]
  param (
    [Parameter()]
    [string]$FileName,
    [Parameter()]
    [string[]]$FileNames,
    [Parameter()]
    [switch]$AddExtension,
    [Parameter()]
    [switch]$CheckFileExists,
    [Parameter()]
    [switch]$CheckPathExists,
    [Parameter()]
    [string]$DefaultExt,
    [Parameter()]
    [switch]$DereferenceLinks,
    [Parameter()]
    [string]$Filter,
    [Parameter()]
    [int]$FilterIndex,
    [Parameter()]
    [string]$InitialDirectory,
    [Parameter()]
    [switch]$Multiselect,
    [Parameter()]
    [int]$Options,
    [Parameter()]
    [switch]$ReadOnlyChecked,
    [Parameter()]
    [string]$SafeFileName,
    [Parameter()]
    [string[]]$SafeFileNames,
    [Parameter()]
    [switch]$ShowReadOnly,
    [Parameter()]
    [string]$Tag,
    [Parameter()]
    [string]$Title,
    [Parameter()]
    [switch]$ValidateNames,
    [Parameter()]
    [bool]$AcceptsReturn
  )
  end {
    $control = New-Object Microsoft.Win32.OpenFileDialog
    #if ($InitialDirectory) { [void]$control.SetBinding([Windows.Controls.TextBox]::TextProperty, $BindTextTo) }
    if ($InitialDirectory) {
       $control.InitialDirectory = $InitialDirectory
    }
    Set-UIProperty $control $PSBoundParameters
  }
}
Function Get-FileInput {
    Param($Inidir)
    # Have user browse to input file (txt or csv)
    $browserFile = Get-FileBrowser -Inidir "$Inidir" #funct call
    if($browserFile -ne "Cancel"){
        $file = Get-ChildItem $browserFile # get file object
        Switch ($file.Extension) {
            ".csv"  { # input csv .... check column for $HostColHeader
                        #################################################
                        # Read in the serverlist from csv (filter columns will happen later)
                        Write-Host "Reading in server list from $($browserFile)..." -NoNewLine
                        Write-Host "Please wait" -f Yellow
                        Write-Host ""
                        ##################################
                        # Read in the server data from csv
                        $serverList1 = Import-Csv $browserFile # read in all columns of the csv file
                        # Get the column header for the list of servers
                        $allheaders1 = $serverList1 | Get-Member -MemberType NoteProperty | ForEach-Object { $_.Name }
                        [array]$allheaders2 = $allheaders1 -split " "
                        #foreach($columnx in $allheaders2){Write-Host $columnx}
                        $hostNameCol = Show-UIListSelectionPrompt -Title "Select Column" -Options $allheaders2

                        #Write-Host "Filtering server list...Please wait" -f Cyan
                            
                        [array]$serverList = $serverList1.$hostNameCol | sort $_
                        #################################################
                        # leave this turned off...only for advanced users
                        # allows filtering the columns of an input csv file
                        # example: filter the domain column for one domain (matching your credentials)
                        # using the filter requires manually customizing the filter
                        #################################################
                        break }
            ".txt"  { # input file and remove blank spaces
                        Write-Host "Reading in server list from txt..."
                        Write-Host ""
                        $serverList = Get-Content $browserFile | Where {$_.trim() -ne ""}
                        Write-Host ""
                        break }
        } #switch
        return $serverList
    } #if
} #funct Get-FileInput
Function Show-UIListSelectionPrompt{
    Param(
        [Parameter(Mandatory=$true)] [string] $Title,
        [Parameter(Mandatory=$true)] [string[]] $Options
    )

    [void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')

    $xml = [xml]'
    <Window SizeToContent="WidthAndHeight" xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="{Binding Path=Title}" ResizeMode="NoResize">
        <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto" />
            <RowDefinition Height="*" />
            <RowDefinition Height="Auto" />
        </Grid.RowDefinitions>
        <TextBlock Text="{Binding Path=Title}" FontSize="16" Margin="8,8,8,0" />
        <ListView ItemsSource="{Binding Path=Options}" Margin="8,8,8,8" Grid.Row="1" 
            SelectedItem="{Binding Path=SelectedOption}" SelectionMode="Single" SelectedIndex="1" />
        <StackPanel Orientation="Horizontal" Grid.Row="2">
            <Button Name="OkButton" Width="76" Height="25" Margin="8,0,0,8" HorizontalAlignment="Left" VerticalAlignment="Top">OK</Button>
            <Button Name="CancelButton" Width="76" Height="25" Margin="8,0,8,8" HorizontalAlignment="Left" VerticalAlignment="Top">Cancel</Button>
        </StackPanel>
        </Grid>
    </Window>
    '
    
    $dataContext = 1 | Select-Object Title, Options, SelectedOption, OK
    $dataContext.Title = $Title
    $dataContext.Options = $Options

    $window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xml))
    $window.DataContext = $dataContext 
# Add-UIEvent MouseDoubleClick $dataContext.SelectedOption
    $window.Topmost = $true

    $window.FindName("OkButton").Add_Click({
        if (!$dataContext.SelectedOption) { [System.Windows.MessageBox]::Show("Select an option first."); return }
        $dataContext.OK = $true
        $window.Close()
    })
    
    $window.FindName("CancelButton").Add_Click({ $window.Close() })

    
    [void]$window.Dispatcher.InvokeAsync({ [void]$window.ShowDialog() }).Wait()

    if ($dataContext.OK) { $dataContext.SelectedOption }
}
Function Show-UIServerListPrompt{
    Param($mainfile,$Srvfile)
    
    #------------------------------------------------------
    #region - UI Properties

    # UI Master Object
    $ServerListMaster = New-UIObject
    # properties
    $ServerListMaster.OK = $false
    $ServerListMaster.ServerListTitle = ""
    $ServerListMaster.ServerListText = ""
    #endregion

    #------------------------------------------------------
    #region - UI Data Loading
    try {
        $settingsHash = Import-Clixml "$($env:APPDATA)\Scripts_UI\RunUiSettings.xml" -ErrorAction Stop
        foreach ($setting in 'WindowLeft','WindowTop') {
            if ($settingsHash.Contains($setting)) {
                $ServerListMaster.$setting = $settingsHash.$setting
            }
        } #foreach
    }
    catch { }
    #endregion

    #------------------------------------------------------
    #region - UI Action Scripts
    $ServerListMaster.Scripts = @{}

    $ServerListMaster.WindowLoaded = {
        $ServerListMaster.Window = $this
        if ($ServerListMaster.WindowLeft)  { 
            if($ServerListMaster.WindowLeft -le 260){ $this.Left = ($ServerListMaster.WindowLeft) + 20}
            else { $this.Left = ($ServerListMaster.WindowLeft) - $this.Width + 15}

        }
        if ($ServerListMaster.WindowTop)   { $this.Top  = $ServerListMaster.WindowTop  }
        $this.Activate()
        #$this.RestoreBounds | fl | out-string | write-host # To see all the restore bound options
    }

    if ($SrvFile)
    {
        $ServerListMaster.ServerListText = (Get-Content -Path $Srvfile -ErrorAction Ignore) -join "`r`n"
    }

    # Scripts
    $ServerListMaster.Scripts = @{}
    $ServerListMaster.Scripts.ServerListTextChanged = {
        # server textbox
        $searchText = ($this.Text -split "`r`n") | ForEach-Object Trim | Where-Object { $_ } | Select-Object -Unique
        $ServerListMaster.ServerListTitle = "Count: $($searchText.count)" 
    }
    $ServerListMaster.Scripts.Clear = { 
        $ServerListMaster.ServerListText = ""
    }
    $ServerListMaster.Scripts.LoadFromFile = { 
        $ServerListMaster.ServerListText = (Get-FileInput $mainfile) -join "`r`n" 
        Write-Host "Complete" -f Yellow
        Write-Host ""
    }
    $ServerListMaster.Scripts.OK = {
        if (!$ServerListMaster.ServerListText) {
            Show-UIMessageBox "No Servers Entered!"
            return
        }
        $ServerListMaster.OK = $true
        Find-UIParent -Type Window | ForEach-Object Close
    }
    $ServerListMaster.Scripts.Cancel = { Find-UIParent -Type Window | ForEach-Object Close }
    #endregion

    #------------------------------------------------------
    #region Layout
    Show-UIWindow -AddLoaded $ServerListMaster.WindowLoaded -DataContext $ServerListMaster -Title "Server List" -Width 300 -Height 260 -MinWidth 280 -MinHeight 200 {
        New-UIGrid -RowDefinition auto, *, auto {
            New-UITextBlock -Margin 4,4,4,2 -Align TopRight -BindTextTo ServerListTitle -AlsoSet @{FontSize=14}
            New-UITextBox -GridRow 1 -Margin 4,4,4,2 -BindTextTo ServerListText -AcceptsReturn $true -VerticalScrollBarVisibility Auto |
                Add-UIEvent -Event TextChanged -Script $ServerListMaster.Scripts.ServerListTextChanged
            New-UIStackPanel -GridRow 2 -Orientation Horizontal -Margin 2,0,2,2 {
                New-UIButton "OK" -Margin 2,2,2,2 -Padding 8,2,8,2 -AddClick $ServerListMaster.Scripts.OK -AlsoSet @{FontSize=14}
                New-UIButton "Cancel" -Margin 2,2,2,2 -Padding 8,2,8,2 -AddClick $ServerListMaster.Scripts.Cancel -AlsoSet @{FontSize=14}
                New-UIButton "Clear" -Margin 2,2,2,2 -Padding 8,2,8,2 -AddClick $ServerListMaster.Scripts.Clear -AlsoSet @{FontSize=14}
                New-UIButton "Load From File..." -Margin 2,2,2,2 -Padding 8,2,8,2 -AddClick $ServerListMaster.Scripts.LoadFromFile -AlsoSet @{FontSize=14}
            }
        }
    }

    # Return results
    if ($ServerListMaster.OK -ne $true) { return } # Exit early if OK was not pressed

    $ServerListMaster.ServerListText -split "`r`n" | ForEach-Object Trim | Where-Object { $_ } | Select-Object -Unique
    #endregion

    #------------------------------------------------------
}
Function Invoke-AsJob {
    Param(
        [Parameter()] [string[]] $ServerList,
        [Parameter()] [scriptblock] $Script,
        [Parameter()] [object[]]$ArgumentList,
        [Parameter()] [System.Management.Automation.PSCredential]$cred
    )

    #region - Initialize and get serverlist
    ##################################################################################################
    # Get-WFCredential -Domain ent.wfb.bank.corp -Type Server # Gets stored creds for the given domain
    # calls Get-WFCredentia and gets credential in the correct domain for the server #Get-WFServerCredential -Server "ASPWA00A0001"
    #################################################################################
    $MaxRunningJobCount = 30
    $GroupSize = 20
    $OutputDirectory = "$($env:APPDATA)\Scripts_UI"
    $i = 0
    $j = 0
    # cleanup del old file
    $csvSuccess   = "$($mainfile)\Success.csv"
    $csvFail      = "$($OutputDirectory)\Fail.csv"
    $excelFileout = "$($OutputDirectory)\Results.xlsx"
    if (Test-Path $excelFileout){ remove-item $csvFail -force -ea 'SilentlyContinue'}
    ####################
    $srvCount = $serverList.Count
    $GroupCount = [math]::Ceiling($srvCount/$GroupSize) # use ceiling to always round up (13.01 => 14)
    $RemainderCount = ($srvCount%$GroupSize) # server count if the last group is a partial group
    Write-Host "Total server count = $($srvCount)" -f Yellow
    Write-Host "Group size         = $($GroupSize)" -f Yellow
    Write-Host "Number of groups   = $($GroupCount)" -f Yellow
    ####################
    #Write-Host "Output:`t`t$($excelFileout)"
    #endregion - Initialize and get serverlist

    #region - send scriptblock to groups of servers...output to excel 
    $timeSpan  = $null
    $startTime = $(get-date)
    $allJobs   = $null
    $job       = $null
    $success   = $null
    $fail      = $null

    # This section will create groups of servers based on the $GroupSize
    for($CurrentGroupNumber = 1; $CurrentGroupNumber -le $GroupCount; $CurrentGroupNumber++){
        # Calc Runtime and ETA
        $Nowx = Get-Date
        $ts = New-TimeSpan -Start $StartTime -End $Nowx
        $CurrentServerCountx = ($CurrentGroupNumber * $GroupSize)
        $SecPerServer = ($ts.Totalseconds)/$CurrentServerCountx
        $ETA = (($srvCount - $CurrentServerCountx)*($SecPerServer))
        $ETA = [int]($ETA/60) # convert seconds to minutes
        write-host ""
        write-host "================================="
        Write-Host "GroupSize   = $($GroupSize)"
        Write-Host "Group count = " -NoNewline; Write-Host "$($CurrentGroupNumber) "     -f Cyan  -NoNewline; Write-Host "of $($GroupCount)"
        Write-Host "Elapsed     = " -NoNewline; Write-Host "$([int]($ts.TotalMinutes)) " -f Cyan  -NoNewline; Write-Host "Minutes"
        Write-Host "ETA         = " -NoNewline; Write-Host "$($ETA) "                    -f Green -NoNewline; Write-Host "Minutes"

        $serverListx = $null
        $invok       = $null # clear the variable so it only fills with the current group of servers

        switch ($currentGroupNumber){
            1  { #...1st group of servers
                if($SrvCount -lt $GroupSize){ #.........................................this is a partial group
                    if($SrvCount -gt 1){$serverListx = $Serverlist[0..($SrvCount-1)]} 
                    else { $serverListx = $Serverlist }
                } else {$serverListx = $Serverlist[0..($GroupSize-1)]} #...................this is a full group
                break }
            ($GroupCount){ #...last group of servers
                if($RemainderCount -eq 0){ #...full group of servers
                    [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..(($currentGroupNumber*$GroupSize)-1)]
                } else { #...partial group of servers
                    [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..((($currentGroupNumber-1)*$GroupSize)+$RemainderCount-1)]
                } #else
                break }
            default {# Middle groups of servers
                [array]$serverListx = $Serverlist[(($currentGroupNumber-1)*$GroupSize)..(($currentGroupNumber*$GroupSize)-1)]
                break }
        } #switch
        write-host ""
        write-host "Sending jobs" -f Green -NoNewline
        write-host "...please wait"   
        # Send jobs to the "current group" of servers
        #####################################################
        #####################################################
        foreach ($Computer in $serverListx){ #....Loop - for each server in list
            Try { 
                if($SimpleCredsCheckbox){
                    [array]$invok += invoke-Command -ComputerName $Computer -Credential $cred `
                                -ScriptBlock $script -ArgumentList $ArgumentList -AsJob -JobName $Computer –ErrorAction Stop -ErrorVariable customError
                }
                else{
                    [array]$invok += invoke-Command -ComputerName $Computer -Credential (Get-WFServerCredential -Server $Computer) `
                                -ScriptBlock $script -ArgumentList $ArgumentList -AsJob -JobName $Computer –ErrorAction Stop -ErrorVariable customError
                }
            }
            Catch { #..Catch
                Write-Host "error - $Computer"
                $err1 = $customError.Exception
                ################################################################
                # clean up the $err1 message ... $a = $a.Replace("old","new")
                if($err1 -like "*message : *"){$err1 = $err1.Replace("message : ","= ")}
                        if($err1 -like "*For more information, see the about_Remote_Troubleshooting Help topic*"){
                    $err1 = $err1.Replace(" For more information, see the about_Remote_Troubleshooting Help topic.","")
                } #if
                        if($err1 -like "*The WinRM client cannot process the request because*"){
                        $err1 = $err1.Replace("The WinRM client cannot process the request because ","")
                } #if
                $FailedObj = New-Object PSObject #...new psobject -help format output (row of data)
                $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($Computer)"
                $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "$($err1)"
                [array]$Fail += $FailedObj
                $j++ #...count failed jobs
            } #...End Try/Catch           
        } #foreach
        #####################################################
        #####################################################
        #$invok | select Id,Name,PSJobTypeName,State,HasMoreData,Location
        $invok | select Id,Name,PSJobTypeName,State | ft -auto | out-host # echo jobs to console
        #################
        $timeSpan = [timespan]::fromseconds(($(get-date) - $startTime).TotalSeconds)
        Write-Host ("Elapsed time (hh\mm\ss) = {0:hh\:mm\:ss}" -f $timeSpan)
        Write-Host ""

        #######################################
        # Monitor running jobs vs complete jobs
        write-host "Checking jobs" -NoNewline -f Green 
        Write-Host "...please wait"
        Confirm-Jobs $CurrentGroupNumber $MaxRunningJobCount $GroupCount #funct call
        ########################################
        # Get and sort by job status
        $allJobs = Get-Job | Sort-Object state
        ##############################
        # Results collection (Jobs collection)

        foreach ($job in $allJobs) {
            Switch ($job.state) {
                Failed { #.........................................................collect Job error information
                    $err1,$err1sub,$err1message,$FailedObj = $null #...reset variables
                    $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                    ################################################################
                    # clean up the $err1msg message ... $a = $a.Replace("old","new")
                    if($err1 -like "*message : *"){$err1 = $err1.Replace("message : ","= ")}
                    if($err1 -like "*For more information, see the about_Remote_Troubleshooting Help topic*"){
                        $err1 = $err1.Replace(" For more information, see the about_Remote_Troubleshooting Help topic.","")
                    } #if
                    if($err1 -like "*The WinRM client cannot process the request because*"){
                        $err1 = $err1.Replace("The WinRM client cannot process the request because ","")
                    } #if
                    if($err1 -like "*Verify that the specified computer name is valid, that the computer is accessible over the network, and that a firewall exception for the WinRM service is enabled and allows access from this computer. By default, the WinRM firewall exception for public profiles limits access to remote computers within the same local subnet.*"){
                        $err1 = $err1.Replace("Verify that the specified computer name is valid, that the computer is accessible over the network, and that a firewall exception for the WinRM service is enabled and allows access from this computer. By default, the WinRM firewall exception for public profiles limits access to remote computers within the same local subnet.","")
                    }
                    ############################################
                    # created an object to hold error message(s) 
                    $FailedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                    $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($job.Location)"
                    $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "$($err1)"
                    [array]$Fail += $FailedObj
                    $j++ #......................................................................count failed jobs
                    Remove-Job $job #.............................................................remove this job
                    break 
                    }
                Completed {
                    [array]$Success += Receive-Job -job $job -ea SilentlyContinue; Remove-Job -job $job #.........get completed job results
                    $i++ #...................................................................count completed jobs
                    break 
                    }
                Stopped {
                    $FailedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                    $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($job.Location)"
                    $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "Job Stopped"
                    [array]$Fail += $FailedObj
                    $j++ #......................................................................count failed jobs
                    Remove-Job $job #.............................................................remove this job
                    break 
                    }
            } #switch
        } #foreach
        # export the collected results to csv...if script hangs, progress so far is not lost
#        if($Success){ [array]$Success = $Success | select * -ExcludeProperty PSShowComputerName,RunspaceId }
#        if($Fail)   { [array]$Fail    = $Fail    | select * -ExcludeProperty PSShowComputerName,RunspaceId }
    } #for
    ########################################
    #endregion - send scriptblock to groups of servers...output to excel

    #region - sort and collect final jobs...output to excel
    ########################################
    # get and sort by job status
    Start-Sleep 2 # sleep 10 sec to allow final jobs to complete
    $allJobs = Get-Job | Sort-Object state
    # Collect jobs again ... allowing final jobs to complete
    foreach ($job in $allJobs) {
        Switch ($job.state) {
            Running { #..............................Jobs still running, did not complete for unknown reasons
                $FailedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value $Computer
                $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"    -Value "Long running job did not complete"
                [array]$Fail += $FailedObj
                #$FailedObj
                $j++ #......................................................................count failed jobs
                Stop-Job $job; Remove-Job $job #.....................................stop and remove this job
                break 
                }
            Failed { #.........................................................collect Job error information
                $err1,$err1sub,$err1message,$FailedObj = $null #...reset variables
                $err1 = $job.ChildJobs[0].JobStateInfo.Reason.Message #....collect the error
                ################################################################
                # clean up the $err1 message ... $a = $a.Replace("old","new")
                if($err1 -like "*message : *"){$err1 = $err1.Replace("message : ","")}
                if($err1 -like "*For more information, see the about_Remote_Troubleshooting Help topic*"){
                    $err1 = $err1.Replace(" For more information, see the about_Remote_Troubleshooting Help topic.","")
                } #if
                if($err1 -like "*The WinRM client cannot process the request because*"){
                        $err1 = $err1.Replace("The WinRM client cannot process the request because ","= ")
                } #if
                ############################################
                # created an object to hold error message(s) 
                $FailedObj = New-Object -TypeName PSObject # new psobject to help format output (row of data)
                $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($job.Location)"
                $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "$($err1)"
                [array]$Fail += $FailedObj
                #$FailedObj
                $j++ #......................................................................count failed jobs
                Remove-Job $job #.............................................................remove this job
                break 
                }
            Completed {
                [array]$Success += Receive-Job -job $job -ea SilentlyContinue; Remove-Job $job #................get completed job results
                #Receive-Job -job $job -ea SilentlyContinue; Remove-Job $job #................get completed job results
                $i++ #...................................................................count completed jobs
                break 
                }
            Stopped {
                $FailedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($job.Location)"
                $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "Job Stopped"
                [array]$Fail += $FailedObj
                #$FailedObj
                $j++ #......................................................................count failed jobs
                Remove-Job $job #.............................................................remove this job
                break 
                }
            Default { #.........................................................collect Job error information
                $FailedObj = New-Object -TypeName PSObject #...new psobject -help format output (row of data)
                $FailedObj | Add-Member -MemberType NoteProperty -Name "PSComputerName" -Value "$($job.Location)"
                $FailedObj | Add-Member -MemberType NoteProperty -Name "Error"          -Value "$($job.State)"
                [array]$Fail += $FailedObj
                #$FailedObj
                $j++ #......................................................................count failed jobs
                Stop-Job $job; Remove-Job $job #.............................................................remove this job
                break 
                }
        } #switch
    } #foreach
    
    # Send collected results to new UI output tab
    if($Success){
        $Success = $Success | Select-Object * #-ExcludeProperty RunspaceId, PSShowComputerName
        $Success | %{ Write-Host "$_" }
    } #if
    if($Fail)   {
        [array]$Fail = $Fail | select * #-ExcludeProperty PSShowComputerName,RunspaceId 
        #$Fail | select * -ExcludeProperty PSShowComputerName,RunspaceId 
        #$Fail | Export-Csv -Path "$csvFail" -NoTypeInformation
        #$csv_tabs = "Fail"
        $Fail | %{ Write-Host "$_" }
    } #if

    # send results to xlsx file
    write-host ""
    write-host "==============================="
    write-Host ""
    ##################################
    # Convert csv files into xlsx tabs
#    if($csv_tabs -eq "Fail"){
#        Get-Csv2xls $csv_tabs $excelFileout #funct call
#    } #if

    Write-Host ""
    Write-Host "Complete" -f Cyan
    Write-Host "========"
    # echo stopwatch...the end of script execution
    $endTime = $(get-date)
    $timeSpan = [timespan]::fromseconds(($endTime - $startTime).TotalSeconds)
    if( $inturrupt -like "*exit=true*" ){ $serverListcount = $i+$j } # if we exited early...recalculate server count.
    else { $serverListcount = $serverList.Count }
        
    #...write to console
    if ($serverListcount -gt 0)         {Write-Host "Total server count = " -NoNewline; Write-Host "$($serverListcount)" -f Yellow }
    if ($i -gt 0)                       {Write-Host "Success job count  = " -NoNewline; Write-Host "$($i)" -f Yellow               }
    if ($j -gt 0)                       {Write-Host "Failed job count   = " -NoNewline; Write-Host "$($j)" -f Yellow               }
    if (($serverListcount-$i-$j) -gt 0) {Write-Host "Missing jobs       = " -NoNewline; Write-Host "$($serverListcount)" -f Yellow }
    ("Total execution time (hh\mm\ss) = {0:hh\:mm\:ss}" -f $timeSpan) | out-host

    # clear the Global Variables
    #################################################################################
    # cleanup del old file
    if (Test-Path $csvSuccess){remove-item $csvSuccess -force -ea 'SilentlyContinue'}
    if (Test-Path $csvFail)   {remove-item $csvFail    -force -ea 'SilentlyContinue'}
    ##################################
    $Success,$Fail             = $null # reset the variable
    #endregion - sort and collect final jobs...output to excel

    Write-Host ""
    Write-Host "PowerShell Script ... " -NoNewline
    Write-Host "Complete" -f Cyan # write to console
} 
Function Get-InputBox {
    <#
    .Synopsis
        Creates a popup multiline input box
    .DESCRIPTION
        Creates a popup multiline input box for entering a list of text strings (server names).
        Blank lines are removed. Leading and trailing whitespace is removed.
        The item list is saved to file. This file can be used to pre-populate the item list.
    .EXAMPLE1
        $Srvfile = "c:\temp\servers.txt"
        $serverList = Get-InputBox -Message "One per line" -WindowTitle "Server List" -Inputfile $Srvfile
    .EXAMPLE2
        $Srvfile = "c:\temp\servers.txt"
        Get-InputBox "One perline" "Server List" $Srvfile
    .EXAMPLE3
        Get-InputBox "One perline" "Server List"
    .INPUTS
        -Message "Please enter servers. One per line"
        -WindowTitle "Item List"
        -DefaultText ""
    .OUTPUTS
        A string array containing a list of server names.
    .FUNCTIONALITY
        Input box
    #>
    [CmdletBinding()]
    [OutputType([String])]
    Param(
        # Param1
        [Parameter(Mandatory=$false, Position=0)]
        [string]$Message,

        # Param2
        [Parameter(Mandatory=$false, Position=1)]
        [string]$WindowTitle,

        # Param3 The last script run will write the item list to file. 
        # This parameter accepts the filename and path so the item list can be pre-populated.
        [Parameter(Mandatory=$false, Position=2)]
        [string]$Inputfile
    )

    Begin {
        ############## Load Assembly for creating form & button
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        Add-Type -AssemblyName Microsoft.VisualBasic 
        ############## Initialize form items...optional
        $handler_form_Load = { # initialize variables and controls when the form 1st loads
            if ($Inputfile){
                if(test-path $Inputfile){ # if serverfile exists
                    $file = get-content $Inputfile # read the file and populate the txtbox
                    foreach($line in $file){ # remove blank lines and trim whitespace
                        if ($line.trim() -ne ""){$textBox.AppendText("$($line.trim())`r`n")} 
                    } #for
                } #if
            } #if
        } #$handler_form_Load
    } #Begin

    Process {
        # define the form
        # define the controls (textbox, buttons, labels, checkbox, radiobutton, etc
        # add each control to the form (Controls.Add)
        ############## Main Window - Form
        $form = New-Object System.Windows.Forms.Form
        $form.Text = $WindowTitle
        $form.Size = New-Object System.Drawing.Size(230,320)
        $form.FormBorderStyle = 'FixedSingle'
        $form.StartPosition = "CenterScreen"
        $form.Topmost = $True
        $form.add_Load($handler_form_Load) # trigger the above item ($handler_form_Load)
        $form.ShowInTaskbar = $true
        $form.Tag = "" # tag is used to return the list

        # Label
        $label = New-Object System.Windows.Forms.Label
        $label.Location = New-Object System.Drawing.Size(10,10)
        $label.Size = New-Object System.Drawing.Size(280,20)
        $label.AutoSize = $true
        $label.Text = $Message

        # TextBox
        $textBox = New-Object System.Windows.Forms.TextBox
        $textBox.Location = New-Object System.Drawing.Size(10,40)
        $textBox.Size = New-Object System.Drawing.Size(200,200)
        $textBox.AcceptsReturn = $true
        $textBox.AcceptsTab = $false
        $textBox.Multiline = $true
        $textBox.ScrollBars = 'Both'
        $textBox.WordWrap = $false
        $textBox.Text = ""

        # button
        $okButton = New-Object System.Windows.Forms.Button
        $okButton.Location = New-Object System.Drawing.Size(10,250)
        $okButton.Size = New-Object System.Drawing.Size(75,25)
        $okButton.Text = "OK"
        $okButton.Add_Click({ 
            $temp,$form.tag = "" # initialize so no unexpected values
            # split into lines, remove blanks, remove leading/'trailing whitespace
            $temp = ($textBox.Text).Split("`n").Trim() | Where {$_.trim() -ne ""}
            $form.tag = $temp # $form.tag is the only way to "return" a value
            #$Global:serverList = $temp
            if($form.tag -eq $null){$form.tag = ""} # needed to show empty vs cancel button
            $form.Close() # close the popup
        })

        # button
        $cancelButton = New-Object System.Windows.Forms.Button
        $cancelButton.Location = New-Object System.Drawing.Size(130,250)
        $cancelButton.Size = New-Object System.Drawing.Size(75,25)     
        $cancelButton.Text = "Cancel"
        $cancelButton.Add_Click({ $form.Tag = $null; $form.Close() })
        $form.CancelButton = $cancelButton # allow using esc key for clicking cancel button

        # Add controls to the form
        $form.Controls.Add($label)
        $form.Controls.Add($textBox)
        $form.Controls.Add($okButton)
        $form.Controls.Add($cancelButton)

        # Initialize and show the form
        $form.Add_Shown({$form.Activate()})
        [system.windows.forms.application]::run($form) | Out-Null
    } #Process

    End {     
        If ($form.tag -eq ""){ # no data entered
            Write-Host "Item list empty." -foregroundcolor "red"
        } elseif ($form.tag -eq $null) { # CANCEL button clicked
            Write-Host "Cancel button clicked." -foregroundcolor "red"
        } else { # save the data to file...used to prepopulate next script run
            if ($Inputfile){ $form.Tag | set-content $Inputfile } # write list to file.
        } #else
        #$Global:serverList = $form.Tag
        return ($form.Tag) # Return the list
    } #End
} #funct Get-InputBox
