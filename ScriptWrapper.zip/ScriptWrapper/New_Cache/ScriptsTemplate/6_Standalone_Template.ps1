<#
.SYNOPSIS
    one line description of what this script does...
.ROLE
    Utility
.FUNCTIONALITY
    Test,Standalone,NewScript,Phil
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    Standalone
#>

# A standalone powershell script (to me) is a collection of PowerShell code in a .PS1 file.
# You can run a standalone script by R-Clicking on the script file and select run with PowerShell.
#
# If you take your standalone PowerShell script...
# - add a header like above (lines 1 thru 12)
# - Save the script
# - You can now see your script name and description in the Scripts_UI.
# - When you launch your script it will open in a new instance of powershell, seperate from the Scripts_UI.
# - This is a very fast way to add a bunch of team script into the Scripts_UI tool.
# - Standalone scripts do not have access to the ServerList Textbox, Output Tabs, Credentials, or any other Scripts_UI features.
# - You should add a pause at the end of your script .. otherwise the PowerShell instance will close immediately after your script completes.
# - If you echo output to console .. a pause will give you time to see it.
##############################
# Paste your entire standalone script code here...


##############################

Write-Host "Script Complete" -ForegroundColor Cyan
Pause
