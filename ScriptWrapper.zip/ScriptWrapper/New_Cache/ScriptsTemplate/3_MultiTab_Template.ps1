<#
.SYNOPSIS
    (No input tab) A working example script with multi-tab output.
.ROLE
    Utility
.FUNCTIONALITY
    Test,Multitab,NewScript,Phil
.NOTES
    Author - Philip.Bellanca@OutLook.Com
.OUTPUTS
    ExcelMultiSheet
#>

#hit ctrl+m - this will toggle all the collapsable areas below.
#You should be familiar with both my Text and Table Template scripts
#--------------------------------------------
# 1. create the new object compatible with Export-csv...this will be the 1st output tab...table example
    $Servicesx = get-service | select -First 10 | select @{Label='HostName';Expression={$env:computername}},Name,Status,StartMode

# 2. create the second object...table example:
    $GetNetAdapter = Get-NetAdapter | select Name,InterfaceDescription,Status,FullDuplex,MACAddress,LinkSpeed
    $NicResults = $null
    foreach($NetAdapter in $GetNetAdapter){
        $obj = [ordered]@{}
        $obj.HostName    = $env:computername
        $obj.Name        = $NetAdapter.Name
        $obj.Description = $NetAdapter.InterfaceDescription
        $obj.Status      = $NetAdapter.Status
        $obj.FullDuplex  = $NetAdapter.FullDuplex
        $obj.MACAddress  = $NetAdapter.MACAddress
        $obj.LinkSpeed   = $NetAdapter.LinkSpeed
        [Array]$NicResults += [pscustomobject]$obj
    } #for

# 3. create the 3rd object...text example:
    $pathx = (Get-Childitem env:path).value
    $Valuex = $pathx -split ";" -join "`n"

    $EnvPathx = "`n####################### `n" + `
    "Hostname = $($env:computername) `n" + `
    "`n" + `
    "Path Environment Variable: `n" + `
    "$($Valuex) `n"

# 4. create the 4th object...text example:
    $IPConfigx = "`n####################### `n" + `
    "Hostname = $($env:computername) `n" + `
    "$(IPConfig | Out-String)"

# 5. create the final return object and attach items 1 thru 4
    $FinalObj = [pscustomobject]@{
        Services      = [Array]$Servicesx  # tab will be Services
        NetAdapter    = [Array]$NicResults # tab will be NetAdapter
        Text_EnvPath  = $EnvPathx  #........ tab will be EnvPath
        Text_IPConfig = $IPConfigx #........ tab will be IPConfig
    }

    return $FinalObj
#--------------------------------------------
# PowerShell script complete

# Appendix of useful stuff
<#
#-------------------------------------------
$serverlist | foreach{$_.Trim() | where{$_}} # remove whitespace and blank lines
$serverlist |       %{$_.Trim() |     ?{$_}} # remove whitespace and blank lines

#-------------------------------------------
The following 3 data structures .. accomplish the same output

1: Add a custom property to your output
    $HostName1 = @{Name=HostNamex; Expression={$env:computername}}
    [array]$DriveObjectx = Get-WmiObject -Class Win32_DiskDrive | select $HostName1,DeviceID,Name,Model,Index,SerialNumber
    $DriveObjectx #...........echo to output

2: Select Properties as a collection ...
    $HostName1 = @{Name='HostNamex'; Expression={$env:computername}}
    $WMI_DiskProps = @($HostName1,'DeviceID','Name','Model','Index','SerialNumber')
    $WMI_DiskDrives = Get-WmiObject -Class Win32_DiskDrive | select $WMI_DiskProps | Sort Index
    $WMI_DiskDrives #......echo to output

3: PScustomObject - Create a custom object then add it to an array (My favorite .. and easy to read code)
    ForEach($thing in WMI_DiskDrives)
        $obj              = [ordered]@{}
        $obj.HostName1    = $env:computername #custom object
        $obj.DeviceID     = $thing.DeviceID
        $obj.Name         = $thing.Name    
        $obj.Model        = $thing.Model   
        $obj.Index        = $thing.Index
        $obj.SerialNumber = $thing.SerialNumber
        [array]$Objs += [PSCustomObject]$obj #add the object to your PSCustomObject collection
    } #foreach
    $Objs #...................echo to output

#-------------------------------------------
Lookup Table:
    $serviceNameToWmiHash = @{}
    Get-WmiObject -Class Win32_Service | %{ $serviceNameToWmiHash[$_.Name] = $_ } 
    $serviceNameToWmiHash        | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Keys   | Out-String | Out-Host #echo to console
    $serviceNameToWmiHash.Values | Out-String | Out-Host #echo to console

#-------------------------------------------
Error Info:
    $error[0] 
    $error[0].Exception
    $error[0].InnerException
    $error[0].CategoryInfo
    $error[0].ErrorDetails
    $error[0].FullyQualifiedErrorId   #very useful .. the short version
    $error[0].InvocationInfo
    $error[0].TargetObject
    $error[0].PSMessageDetails
#>