# Dbl-Click to launch the main script (ScriptWrapper.ps1).
# 
# A cmd window opens and echoes what is going on. Then a main window will open.
# In the top left is a help item ... a description of this script and how to use it.
#    1st time ... a folder is created ($CacheRoot).
#    click the refresh button to view the default list of scripts available to run.
#
# To fix most problems ... the main window at the top has a dropdown ... Uninstall the ScriptWrapper.
#    This will delete the $CacheRoot folder ... Launch the main script again to recreate $CacheRoot.
#########################################################################################################
# ---Requirements: 
# ---If you move the main app folder to a new location ... you need to update this variable ($RootFolder)
# ---You must launch the ScriptWrapper.ps1 with your logon account.
#    This tool is not installed. Your logon profile path "$($env:appdata)\..." is needed to cache files.
# .....................To any who follow...happy scripting :)
#
# ---There are 2 main folders: ...these can be on the local drive or on a network unc path. 
#      1) $RootFolder - selfcontained files and folders needed by the ScriptsWrapper Tool.
#      2) $CacheRoot  - created on client machine during 1st launch - used for cache files and all output files.
#      $RootFolder = "C:\ScriptWrapper"
#      $CacheRoot  = "$($env:appdata)\ScriptWrapper" # Users logon profile path required...launched from laptop or server.
#