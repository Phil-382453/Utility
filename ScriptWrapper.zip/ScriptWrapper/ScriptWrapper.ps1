﻿cls
<#
.SYNOPSIS  
    GUI Interface (wrapper) for searching, selecting, and running scripts remotely.
.DESCRIPTION
    This tool was written to facilitate choosing and running PowerShell scripts from a folder/Repository.
.NOTES
   Author - Philip R. Bellanca
#>

# This tool consists of:
<# - The main launch script (this file).
# - A subfolder (DevScripts) - various useful scripts, including template script examples.
# - A subfolder (New_Cache) - robocopied (and renamed) to users local profile on 1st launch.
#   This local cache is used to increase efficiency and performance.
#   It also has subfolders to collect the output generated when running scripts.
#-------------------------------------------------------------------------------------
# It is easiest to read this script using ctrl+m to collapse all the expandable sections.
#   Then expand each section as you navigate the different regions.
#   You should be able to understand most of the flow. The code is heavily commented.
#>

Do {
#########################################################################################################
# ---Requirements: 
# ---Launch the ScriptsWrapper with default credentials. Do not use RunAs.
     <#The ScriptsWrapper (on 1st launch) uses your local profile path to create a cache folder in your profile path.
#      The ScriptsWrapper will prompt for privileged credentials when accessing a remote server(s).
#      If you move the main app folder to a new location ... you might need to hardCode this variable ($RootFolder)
#>
# ---There are 2 main folders: 
#      1) $RootFolder - Source files and folders needed by the ScriptsWrapper Tool.
#      2) $CacheRoot  - Created on client machine during 1st launch - output files and other settings files.
$RootFolder = $PSScriptRoot # if you have problems launching - try hard-coding the RootFolder path (local or UNC).
#$RootFolder = "F:\PowerShell\ScriptWrapper" # This hard-coded RootFolder must match the path to this ps1 file.
$CacheRoot  = "$($env:appdata)\ScriptWrapper" # Users logon profile path required (stores output generated, etc.).
#
#------------------------------------------------
#region 1 - Initialize Settings and Load modules

    # Most variables used in this script are defined in this section
    Write-Host ""
    Write-Host "----------------------------" -Foreground Magenta
    Write-Host "Launching the Script Wrapper"
    
    # This file is deleted during successful launch, just before loading the app window.
    # If the file is present...it wasn't deleted (previous launch) failed to complete and load the app window.
    if (Test-Path "$CacheRoot\ScriptWrapperStarting.txt"){ # created during robocopy ...below.
        Write-Host ""
        Write-Host "Warning: " -NoNewline -Foreground Red
        Write-Host "It appears ScriptWrapper did not launch successfully the last time." #-Foreground Cyan
        Write-Host "press " -NoNewline #-Foreground Cyan
        Write-Host "ENTER  " -NoNewline -Foreground Cyan #-FontWeight Bold
        Write-Host "to skip warning ... and continue with launch." #-Foreground Cyan
        Write-Host "type  "  -NoNewline #-Foreground Cyan
        Write-Host "DELETE " -NoNewline -Foreground Red #-FontWeight Bold
        Write-Host "to delete the local cache folder. " #-Foreground Cyan
        Write-Host ""
        Write-Host "Deleting the local cache folder is equivalent to uninstall/reinstall." -Foreground Cyan

        $DeLeteCache = Read-Host "Press ENTER (or type DELETE)"
        IF($DeLeteCache -like "DELETE*"){Remove-Item -Path "$($env:appdata)\ScriptWrapper" -Recurse -Force} #if
    } #if

    if(Test-Path $CacheRoot){
        Write-Host ""
        Write-Host "Synching the local cache folder..." -Foreground Yellow # Synching to the New_Cache folder in the source files.
        Write-Host "`t$($CacheRoot)"
    } #if
    else{
        Write-Host ""
        Write-Host "Creating the local cache folder..." -Foreground Green
        Write-Host "`t$($CacheRoot)"
    } #else

    # This will robocopy the New_Cache footprint ... to the local cache folders.
    $Sourcex = "$RootFolder\New_Cache" # Required for loading modules
    
    # Sync the local cache to the source
    & "C:\Windows\System32\robocopy.exe" $Sourcex $CacheRoot /e /MT:nn /tbd /E /R:3 /W:1 | Out-Null # /purge  /NP

    # Verify robocopy was successful
    if (-not(Test-Path $CacheRoot)){
        Write-Host ""
        Write-Error "Robocopy failed to copy from $Sourcex to $CacheRoot"
        Write-Host 'If the problem persists, consider hard-coding your source path (to the unzip files). (approx) Line 30 of this script $RootFolder =' -f Cyan
        return
    }

    #---------------------
    # This will expand (horizontally) the console buffer...and output tabs in the main app window
    $FormatEnumerationLimit = -1
    $Console = $Host.UI.RawUI
    $Buffer = $Console.BufferSize
    $Buffer.Width = '6144'
    $Console.BufferSize = $Buffer

    ###########################################################################
    # In its simplest form - a module is a .psm1 file that holds many functions.
    #------------------------------------------------
    $VerbosePreference = "SilentlyContinue" #prevents the echo when loading modules
    Write-Host ""
    Write-Host "Loading Modules" -NoNewline -ForegroundColor Cyan
    Write-Host "...please wait"
    Import-Module "$($CacheRoot)\Modules\UserInterface"  -DisableNameChecking # needed by 'region - show the main window'
    Write-Host "`t$($CacheRoot)\Modules\UserInterface"
    Import-Module "$($CacheRoot)\Modules\MCredential"    -DisableNameChecking # needed to access the credentials manager in the control panel
    Write-Host "`t$($CacheRoot)\Modules\MCredential"
    Import-Module "$($CacheRoot)\Modules\MServer"        -DisableNameChecking #
    Write-Host "`t$($CacheRoot)\Modules\MServer"
    Import-Module "$($CacheRoot)\Modules\MiscFunctions"  -DisableNameChecking # needed by 'region - Main Engine - Invoke' and several items under 'region - Action - Misc'
    Write-Host "`t$($CacheRoot)\Modules\MiscFunctions"
    $VerbosePreference = "SilentlyContinue" #Continue | SilentlyContinue

    ###########################################################################
    # Initialize $UIMaster
    $UIMaster = New-UIObject # This is my main object. I attach all variables to this. 
    # PowerShell lets you use Dot Notation to create complex objects ... all linked to a main object.
    # I need a main object when I link it to the main window (app window).
    # Important variables (used in this script) are defined in this section
    #--------------------------------------------
    $UIMaster.Relaunch             = $false # used in outermost loop to allow closing the main gui and relaunching...instead of straight to exit.
    #--------------------------------------------
    $UIMaster.Scripts_Root         = $PSScriptRoot # this is a powershell variable for "THIS" folder ... for the running script (ScriptWrapper.ps1)
    $UIMaster.CacheFolderMain      = "Dev"       # Name used in the DDLB
    $UIMaster.CacheFolderTest      = "Test"      # Name used in the DDLB
    $UIMaster.CacheFolderTemplates = "Templates" # Name used in the DDLB
    $UIMaster.WorkingDirectory     = "$($CacheRoot)" # Warning!!! This is the only generic location every user has access to (logon profile path).
    $UIMaster.ScriptFolderMain     = "$($RootFolder)\DevScripts"
    # The next 2 folders are local and have scripts (..test and ..template). Normally you would put Team scripts on a UNC path.
    $UIMaster.ScriptFolderTest     = "$($CacheRoot)\ScriptsTest"  # location for writing and testing new scripts...most users dont have access to modify scripts on unc path.
    $UIMaster.ScriptFolderTemplate = "$($CacheRoot)\ScriptsTemplate"   # local staged template scripts folder.
    #$UIMaster.ScriptFolderMerge    = "$($PSScriptRoot)\Resource\GeneralScripts" # location for scripts that get merged with the selected repo during refresh button click.
    $UIMaster.SelectedCacheFolder  = $UIMaster.CacheFolderMain # default "Selected Scripts Folder"
    $UIMaster.SelectedScriptFolder = $UIMaster.ScriptFolderMain 
    #---------------------
    $UIMaster.ScriptLogs           = "$($PSScriptRoot)\Logs" # Users must have write-access to $UIMaster.ScriptLogs
    Write-Host ""
    Write-Host "Logs folder" -ForegroundColor Cyan # echo to console
    Write-Host "`t$($UIMaster.ScriptLogs)"   # echo to console
    $UIMaster.FileSaveLimit        = 1       # The number of save files to rotate. This helps keep the output cache folder size small.  
    $UIMaster.CurrentOutType       = "Table" # default 
    #--------------------------------------------
    $UIMaster.bypassloop           = $false  # Used inside MiscFunctions.psm1/confirm-jobs ...to step out of the current loop and exit.
    $UIMaster.ConnectionType       = "AsJob" # AsJob can handle 10,000 servers easily. 
    $UIMaster.Cred                 = $null   # Holds privileged creds (Used if you select CredsManual radiobutton).
    $UIMaster.CredsforCopy         = $null   # Used by several scripts ... drive mapping scripts ... copy to/from UNC etc.
    #-------------------------------------------- I want these scripts available in each scripts repo... but they are saved in a seperate folder.
    $UIMaster.CredMgrScript        = "CredManager.ps1" # Used to reset or update or clear your credsManager credentials
    $UIMaster.NameResScript        = "NSLookupx.ps1"   # 
    $UIMaster.PingScript           = "Ping.ps1"   # 
    #--------------------------------------------
    $UIMaster.RadioCredsManual     = $true   # Input Radio button    (default $false) Radio button to store credentials in memory until you exit PowerShell
    $UIMaster.RadioScriptRunLocal  = $true   # Input Radio button    Force run scriptblock on local machine (several exceptions... Standalone script type)
    $UIMaster.RadioCredsManager    = $false  # Input Radio button    (default $true) Radio button used for control panel credentials manager (to store credentials)
    $UIMaster.RadioScriptRunRemote = $false  # Input Radio button    ($true is default) run script on remote serverlist
    #--------------------------------------------
    $UIMaster.CredDomain       = "prod.manuf.corp" # Control panel - Creds Manager - generic
    $UIMaster.CredType         = "Server"          # Control panel - Creds Manager - generic
    $UIMaster.CredAccount      = "A123456"         # Control panel - Creds Manager - generic
    #--------------------------------------------
    $UIMaster.autofilter       = $true   # Output     Flag to enable auto filter on xlsx output file. 
    $UIMaster.autofreeze       = $true   # Output     Flag to enable auto freeze on xlsx output file. 
    $UIMaster.Csv_tabs         = $null   # Output     String array used to store tab names for multi-tab output (xlsx file)
    $UIMaster.Error            = $false  # Output     (default $false) Flag to indicate one or more failed jobs. I use this to trigger sending errors to an 'Errors' output tab.
    $UIMaster.ErrorData        = $null   # Output     Job errors ... used to populate the errors output tab.
    $UIMaster.MultiSheet       = $false  # Output     (default $false) Flag to indicate a scriptblock is launched that creates mulit-tab output. _Server_Health is the only script currently that does this. 
    $UIMaster.Excel_Tabs       = $null   # Output    (not used) Array used to store tab names for multi tab output (xlsx)
    $UIMaster.FilteredScriptListCount = "0" # ....... default - The Filter looks at script file .Functionality for AdminScript.
    $UIMaster.GroupSize        = 10      # Input Textbox         (default is 10)
    #--------------------------------------------
    $UIMaster.DDLBfile         = "$($UIMaster.WorkingDirectory)\Config\ScriptLocations.txt" # text file used to populate ddlb (names and paths).
    $UIMaster.Helpx            = $false  # ..............................................Help     (default is false) Flag to read and send HelpText file to output tab.
    $UIMaster.HelpTextFile     = "$($UIMaster.WorkingDirectory)\Config\HelpReadme.txt" # Used on the Help menu of the main app window
    $UIMaster.HelpGUIFile      = "$($UIMaster.WorkingDirectory)\Config\HelpGUI.txt" #....Used on the Help menu of the main app window
    #--------------------------------------------
    $UIMaster.Header           = $null   # Name on the Output tab. Store a single tab header.
    $UIMaster.InputTabDefaults = $false  # .......... Flag to suppress prompts. Used by inputtab scripts when reseting the fields they contain to default values.
    $UIMaster.LoggingEnabled   = $true   # .......... - User activity logging
    $UIMaster.MaxRunningJobCount = 50    # .......... This will limit the maximum number of running jobs (will sleep until running job count decreases below)
    $UIMaster.DDLBkeys         = $null   # .......... The combobox (dropdownlistbox) contents are paths to script folders (repositories).
    $UIMaster.MultiPathHash    = $null   # .......... Lookup table for @{ shortname = Scriptfilepath } ... key = value
    $UIMaster.NoPrompt         = $false  # .......... Some scripts will access this to bypass several prompts (no servers in list ... and no selected script)
    $UIMaster.RunName          = $null   # .......... A variable for the invoke-command. Holds Success, Fail, and (run)Name
    $UIMaster.Uninstall        = $false  # .......... Flag to suppress prompts. Used when removing the ScriptWrapper local cache folder.
    $UIMaster.SaveToFile       = $false  # .......... (default $false) Flag to save script output to a file in cache directory. This is used by several scripts (Firmware)
    # these 3 SaveFileName.....allows a script save write something to file directly using a predetermined filename (txt or csv).
    $UIMaster.SaveFileName     = $null   # .......... Will be set by some scripts (firmware) to cause output to save to file (before sending to output tab)
    $UIMaster.SaveFileNametxt  = "SaveFiletemp.txt" # Will be set by some scripts (firmware) to cause output to save to file (before sending to output tab)
    $UIMaster.SaveFileNamecsv  = "SaveFiletemp.csv" # Will be set by some scripts (firmware) to cause output to save to file (before sending to output tab)
    $UIMaster.ScriptCalled     = ""
    $UIMaster.Stop             = $true   # .......... flag used by PreLaunch Checks to indicate checks failed.
    $UIMaster.Success          = $null   # .......... Holds results collection for successful jobs.
    $UIMaster.ScriptName       = (($MyInvocation.MyCommand.Name).Split('.'))[0] # THIS ScriptName (no path or ext - just the name) 
    $UIMaster.SelectedScript   = $null   # The (highlighted) selected script in the Script list.
    $UIMaster.ServerCount      = 0       # This counts how many unique servers names in the serverslist textbox.
    $UIMaster.Searchtxt        = "*"     # Input      Textbox - Keyword search (required).
    $UIMaster.ServerCountLimit = 50      # Input      Textbox - Limits the allowed number of servers per script run...verifyed when launching a script.
    $UIMaster.ServerText       = ""      # ServerList Textbox - This is the textbox contents for serverlist
    $UIMaster.ServerTextTemp   = ""      # ServerList Textbox - A variable - holding place when switching back and forth between Run Scripts Remote | Local
    $UIMaster.ServerTextFilePath = "$($UIMaster.WorkingDirectory)\Servers.txt" # Serverlist file save location... updated each script launch and on window closing.
    $UIMaster.FlipLocalRemote  = "Local"       # Local  Remote
    $UIMaster.FlipCreds        = "Creds Manual" # Cred Manager   Creds Manual
    $UIMaster.SettingsBanner   = "Creds Manual - Local"
    $UIMaster.SrvrListcount    = ""      # ServerList textbox      Count unique server names in the textbox    
    $UIMaster.SubScriptMessage = $null   # .......... default - The message sent to console (script name) when launching a script.
    #----------------------------------
    $UIMaster.FullAccess      = $true # (default)
    $UIMaster.adminServerList = $true # (default) True allows unlimited server list
    $UIMaster.adminScripts    = $true # (default) True allows you to view AdminScripts = Script with "AdminScript" in the list of keyworkds (.Functionality)

    #####################################################
    # List of scripts
    $UIMaster.ScriptList         = New-UIObjectCollection # This will be the "full"     list of available scripts collected to cache.
    $UIMaster.FilteredScriptList = New-UIObjectCollection # This will be the "filtered" list of available scripts after keyword filters.
#endregion 1
#------------------------------------------------
#region 2 - Create the local cache folders and default content

    #########################################################
    Write-Host "" # echo to console

    # Verify the path for each item listed in the ScriptLocations.txt.
    #------------------------------------------------
    # \ScriptWrapper\Config\ScriptLocations.txt - This file matches the (default) choices in the drop down box (select a scripts location).
    if(Test-Path "$($UIMaster.DDLBfile)"){
        
        # Read in the current file - ScriptLocations.txt
        $filex = Get-Content "$($UIMaster.DDLBfile)" # ScriptLocations.txt
        $NewFilex = $null
        $locx = "$($UIMaster.DDLBfile)"
        foreach($line in $filex){
            $LineSplit = $line -split "," #split the line by 'comma'

            #"1>$(($LineSplit[0]).Trim())<" | out-string | out-host # echo for testing
            #"2>$(($LineSplit[1]).Trim())<" | out-string | out-host # echo for testing
            $checkPath = "$(($LineSplit[1]).Trim())"

            if(-not(Test-Path "$checkPath")){
                $messagex = "The path in your ScriptLocations.txt file is missing`n" + `
                            "This file is located in your local cache - config folder.`n`n" + `
                            "Please verify Path = " + `
                            "$checkPath`n"
                $ShowUIMsgBox = Show-UIMessageBox -Message $messagex -button Ok
            } #if
        } #for
    } #if
    else { # ScriptLocations.txt not found (new install?)
        #Write-Host ""
        #Write-Host "`tCreating the DDLB file - $($UIMaster.WorkingDirectory)\Config\ScriptLocations.txt" -ForegroundColor Green
        New-Item -Path "$($UIMaster.WorkingDirectory)\Config" -Name "ScriptLocations.txt" -ItemType file | Out-Null     # ScriptWrapper\Config\ScriptLocations.txt
        "$($UIMaster.CacheFolderMain)     , $($UIMaster.ScriptFolderMain)"     | Add-Content -Path "$($UIMaster.DDLBfile)" -Force | Out-Null # Add dev location
        "$($UIMaster.CacheFolderTest)     , $($UIMaster.ScriptFolderTest)"     | Add-Content -Path "$($UIMaster.DDLBfile)" -Force | Out-Null # Add test location
        "$($UIMaster.CacheFolderTemplates), $($UIMaster.ScriptFolderTemplate)" | Add-Content -Path "$($UIMaster.DDLBfile)" -Force | Out-Null # Add templates location
        # "Prod , some unc path to prod script location"
    } #else

    #------------------------------------------------
    # Read the ScriptLocations.txt (split into lines)
    $ArrayPathCache = (Get-Content -Path "$($UIMaster.DDLBfile)") -split "`n"

    #------------------------------------------------
    # Export Settings - to be used the next time the UI is loaded.
    $ScriptPathObjs = [ordered]@{} # Define a HashTaboe .. (a fundamental structure in PowerShell) .. https://ss64.com/ps/syntax-hash-tables.html
    # Https://docs.microsoft.com/en-us/powershell/scripting/learn/deep-dives/everything-about-hashtable?view=powershell-7.1

    $ErrorActionPreference = 'SilentlyContinue'
    # Add each line (Key , Value) to the $ScriptPathObjs - this object used in the gui to populate the script repo paths drop down list box.
    foreach ($line in $ArrayPathCache){
        $twoItem = $line -split "," # LocalScriptsCache , C:\Users\<username>\AppData\Roamng\ScriptWrapper\TestScripts
        $ScriptPathObjs.Add(($twoItem[0]).Trim(),($twoItem[1]).Trim()) # add key | value pair to the hashtable ($ScriptPathObjs)
    } #for
    $ErrorActionPreference = 'Continue'

    $DDLBkey = $null
    [string[]]$DDLBkey = $ScriptPathObjs.Keys -split "`n" | foreach Trim | ?{$_} | Select -Unique # list of new local cache folders (The 1st column for out txt file)

    #------------------------------------------------
    # $ScriptPathObjs.Keys will be the combobox (ddlb) values (Dev, Test)
    $UIMaster.DDLBkeys = $ScriptPathObjs.Keys

    #------------------------------------------------
    # Create a lookup table (MultiPathHash) for available script locations
    $UIMaster.DDLBhash = @{}
    $UIMaster.DDLBhash = $ScriptPathObjs #example 2 column entry ... TestScript, c:\Users\<username>\Appdata\Roaming\ScriptWrapper\TestScripts

    #------------------------------------------------
    # Set the Selected script repo path ... user does not have to keep changed to desired script repo every launch
    if(Test-Path "$($UIMaster.WorkingDirectory)\Config\ScriptLastLoc.xml"){ # ScriptLastLoc.xml was the last selected path
        $ScriptLastLoc = Import-Clixml -Path "$($UIMaster.WorkingDirectory)\Config\ScriptLastLoc.xml"
        # Populate the combobox (drop down) with the users last selected script repo.

        if("$($ScriptLastLoc.Keys)" -in $DDLBkey){ # if the last selected script folder is available in the ScriptLocations.txt
            $UIMaster.SelectedCacheFolder  = "$($ScriptLastLoc.Keys)" # Key is the path to the scripts folder (repo)
            $UIMaster.SelectedScriptFolder = "$($ScriptLastLoc.Values)" # value is the local cache folder
        } #if
        else{ # Set the combobox on startup - Default (currently Dev)
            $UIMaster.SelectedCacheFolder  = "$($UIMaster.CacheFolderMain)" #Dev
            $UIMaster.SelectedScriptFolder = "$($UIMaster.ScriptFolderMain)"

            # Export (default) settings for the next time the UI is loaded
            Export-Clixml -Path "$($UIMaster.WorkingDirectory)\Config\ScriptLastLoc.xml" -InputObject @{
                "$($UIMaster.ScriptFolder)" = "Dev"
            } # Export-Clixml
        } #else
    } #if
    else{ # Set to default .. save the file.
        #Export (default) settings for the next time the UI is loaded
        Export-Clixml -Path "$($UIMaster.WorkingDirectory)\Config\ScriptLastLoc.xml" -InputObject @{
            "$($UIMaster.CacheFolderMain)" = "$($UIMaster.ScriptFolderMain)"
        } # Export-Clixml

        # Populate the Textboxes (variables) for selected cache and script path
        $UIMaster.SelectedCacheFolder  = $UIMaster.CacheFolderMain
        $UIMaster.SelectedScriptFolder = $UIMaster.ScriptFolderMain
    } #else

    #------------------------------------------------
    # Set access level L34dh027-d936p-4SgLYr-7daAsdDf3tb-1qaf34fYyklLT-YxcWEhkisdp2t
    $UIMaster.accessx         = "$($UIMaster.WorkingDirectory)\Config\Deleteme.txt" # sets access level
    #----------------------------------

    # This "if" does nothing - $UIMaster.FullAccess = $true  has been set above in #region1
    # To re-enable - uncomment the if statement below, and set $UIMaster.FullAccess = $false above in #region1
    # Then search down for $UIMaster.FullAccess ... re-enabling the code as indicated in several areas.
    # Then have your admin users create a Deleteme.txt file populated and saved locally as shown below.

    # This allows 
    # 1. limiting the servers list max count for non-admin users...change value in region1 ($UIMaster.ServerCountLimit = 50)
    # and 2. hiding Admin scripts for non-admin users.
    # You also must designate Admin scripts by adding the keyword AdminScript to .Functionality in each desired admin script.
    <#
    if(Test-Path $UIMaster.accessx){
    #if($false){ #disabled
    #----------------------------------
        #L34dh027-d936p-4SgLYr-7daAsdDf3tb-1qa34FYyklLT-YxcWEhkisdp2t ... save to the Deleteme.txt file w/o leading #.
        $x1 = Get-Content -path "$($UIMaster.WorkingDirectory)\Config\Deleteme.txt"
        if($x1){
            $len=$x1.Length
            $y1=$x1.substring($len-3)
            $a1=$y1.substring(0,1);$a2=$y1.substring(1,1);$a3=$y1.substring(2)
            [array]$y2=$x1.split('-')
            $len1=($y2[1]).Length;$len2=($y2[2]).Length;$len3=($y2[3]).Length;
            $b1=($y2[1]).Substring($len1-1);$b2=($y2[2]).Substring($len2-1);$b3=($y2[3]).Substring($len3-1)

            if($a1 -eq $b1){
                $UIMaster.FullAccess      = $true
                $UIMaster.adminServerList = $true
                $UIMaster.adminScripts    = $true
            } #if
            else{
                if($a2 -eq $b2){$UIMaster.adminServerList = $true}
                if($a3 -eq $b3){$UIMaster.adminScripts    = $true}
            } #else
        } #if
    } #if
    #>

    Write-Host "Initializing Settings " -ForegroundColor Cyan -NoNewline # echo to console
    Write-Host "... Please wait "                                        # echo to console

#endregion 2
#------------------------------------------------
#region 3 - Action - Misc calls for Actions

    # These actions are triggered from various locations throught the script.
    # Example: find $UIMaster.Scripts.HelpText will show this item is triggered in #region7 below
    #--------------------------------
    $UIMaster.Scripts = @{} # Initialize
    $UIMaster.Scripts.WindowLoaded      = { # load previous window position, height, width
        # Import and apply settings for the main window (The ScriptWrapper)
        if(Test-Path "$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml"){
            Write-Host "`t$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml"
            # _GuiHeightWidth.xml"
            $settingsHash1 = Import-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml" -ErrorAction Stop

            $settings = 'WindowTop','WindowLeft','WindowHeight','WindowWidth'
            foreach($setting in $settings){
                if($settingsHash1.Contains($setting)){$UIMaster."$Setting" = $settingsHash1."$Setting"}
            } #for

            # Seems to have problems with 0...sometimes
            if($UIMaster.WindowTop -eq 0) {$UIMaster.WindowTop  = 1}
            if($UIMaster.WindowLeft -eq 0){$UIMaster.WindowLeft = 1}

            # Now apply the imported settings to 'this' window
            $UIMaster.Window = $this
            if ($UIMaster.WindowTop)   { $this.Top    = $UIMaster.WindowTop }
            if ($UIMaster.WindowLeft)  { $this.Left   = $UIMaster.WindowLeft }
            if ($UIMaster.WindowHeight){ $this.Height = $UIMaster.WindowHeight }
            if ($UIMaster.WindowWidth) { $this.Width  = $UIMaster.WindowWidth }
            $this.Activate()
            #$this.Restore.Bounds #| fl | out-string | write-host # To see all the restore bound options
        } #if
        if(test-path "$($UIMaster.WorkingDirectory)\_GuiSettings.xml"){
            Write-Host "`t$($UIMaster.WorkingDirectory)\_GuiSettings.xml"           
            #-----------------
            # _GuiSettings.xml
            $settingsHash1 = Import-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiSettings.xml" # -EA Stop
            $settings = 'RadioCredsManager','RadioCredsManual','RadioScriptRunRemote','RadioScriptRunLocal','RunJob','RunSession','FileSaveLimit','GroupSize','MaxRunningJobCount','SettingsBanner' ,'Searchtxt'
            foreach ($setting in $settings) {
                if ($settingsHash1.Contains($setting)){$UIMaster.$setting = $settingsHash1.$setting}
            } #foreach

            #----------------------------------------------------------------
            # _isFavoritesCache.xml - see region 7 - UI Data Loading
            # _isFavoritesCache.xml is linked to the chosen cache folder loading... not the main window loading.

            # ServerList.txt
            if(test-path "$($UIMaster.ServerTextFilePath)"){$UIMaster.ServerText = (get-Content "$($UIMaster.ServerTextFilePath)") -join "`r`n" }

            if (Test-Path "$($env:appdata)\ScriptWrapper\ScriptWrapperStarting.txt"){
                Remove-Item -Path "$($env:appdata)\ScriptWrapper\ScriptWrapperStarting.txt" -Force
            } #if

        } #if
        Write-Host ""
        Write-Host "Complete" -f Cyan
    } #.WindowLoaded
    #--- Menu Items (not a complete list) ---------------
    $UIMaster.Scripts.HelpText          = {
        $UIMaster.Helpx = $true
        $header = "Help - Readme"
        $TextFile = $UIMaster.HelpTextFile
        $UIMaster.NoPrompt = $true # disable prompting on this script run
        & $UIMaster.Scripts.Text2Tab $header $TextFile # send text from file to output tab
    } #.HelpTxt
    $UIMaster.Scripts.HelpGUI           = {
        $UIMaster.Helpx = $true
        $header = "Help - How to write a gui window"
        $TextFile = $UIMaster.HelpGUIFile
        $UIMaster.NoPrompt = $true # disable prompting on this script run
        & $UIMaster.Scripts.Text2Tab $header $TextFile # send text from file to output tab
    } #.HelpGUI
    $UIMaster.Scripts.HelpDocx          = {
        if(Test-Path "$($UIMaster.WorkingDirectory)\ScriptWrapper_User_Guide.docx"){
            Invoke-Item "$($UIMaster.WorkingDirectory)\ScriptWrapper_User_Guide.docx"
        } #if
        else{
            $messagex = "Word doc not found...`r`n$($UIMaster.WorkingDirectory)\ScriptWrapper_User_Guide.docx"
            $ShowUIMsgBox = ShowUIMessageBox -Message $messagex -button Ok
        } #else
    } #.HelpDocx
    $UIMaster.Scripts.Ping              = {
        $UIMaster.ScriptCalled = "Ping.ps1"
        & $UIMaster.Scripts.CallScript
    } #.Ping
    $UIMaster.Scripts.CompileLogs       = {
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    # 
    #
    # 
        } #.CompileLogs
    $UIMaster.Scripts.Support           = {
        # This works if you use outlook ... not working for outlook 365 ... an easy fix

        & {
            #"<h1>put your header here....</h1>"
            #"<p>"Generated: $(Get-Date | Get-HtmlEncodedText)</p>
            "<ul>"
            "</ul>"
            #"<li>  </li>" # add a line at bottom
        } | 
        Out-Outlook -Subject "Support Needed for PowerShell Scripts tool" -to "John.Doe@ABCcompany.com"
    } #.Support
    $UIMaster.Scripts.Exit              = { 
        Find-UIParent -Type Window | ForEach-Object Close
    } #.Exit
    #--- GUI button and textbox -------------------------
    $UIMaster.Scripts.RefreshButton     = { # triggered when clicking the refresh button
        
        #--------------------------------
        # Update Servers.txt file from textbox prior to switchein script directories
        $UIMaster.ServerText | Set-Content -Path "$($UIMaster.ServerTextFilePath)"

        #--------------------------------
        # Export _isFavoritesCachj.xml - Save isFavorites before leaving 
        if($UIMaster.OriginalScriptsFolder){
            $newScriptSettings = @{}
            foreach ($script in $UIMaster.ScriptList){
                $newScriptSettings[$script.ScriptName] = @{ IsFavorite = $script.IsFavorite }
            } #for
            Export-Clixml -Path "$($UIMaster.OriginalScriptsFolder)\_isFavoritesCache.xml" -InputObject $newScriptSettings
        } #if
        
        #--------------------------------
        # Export settings (selected local cache and script folder) Used in data loading next.
        Export-Clixml -Path "$($UIMaster.WorkingDirectory)\Config\ScriptLastLoc.xml" -InputObject @{
            "$($UIMaster.SelectedCacheFolder)" = "$($UIMaster.SelectedScriptFolder)"
        } -Force -EA SilentlyContinue #export-clixml
        
        ### This is required otherwise a script repo with only 1 script will appear empty
        if(-not($UIMaster.Searchtxt)){$UIMaster.Searchtxt = "*"}

        #--------------------------------
        # Load Cache data and open the main window
        & $UIMaster.Scripts.DataLoading
        & $UIMaster.Scripts.OpenMainWindow
    } #.RefreshButton
    $UIMaster.Scripts.SrvrTxBoxChanged  = {
        # server textbox
        $searchText1 = ($this.Text -split "`r`n") | ForEach-Object Trim | Where-Object { $_ -ne "" } | Select-Object -Unique
        $UIMaster.SrvrListcount = "$($searchText1.count)"
    } #.SrvrTxBoxChanged
    $UIMaster.Scripts.SearchBoxChanged  = {
        # KeyWord Search textbox - Triggered when you type in text to search for
        $searchText = $this.Text # "$this" is the active (with focus) control (The KeyWord textbox)

        # If my account has fullaccess - I get to see all scripts
        # This is based on .Functionality - AdminScript in the script file help header
        if($UIMaster.FullAccess -or $UIMaster.adminScripts){ 
            $Listx = $UIMaster.ScriptList
        } #if
        else { # dont show the adminScripts to non admin users.
            $Listx = $UIMaster.ScriptList | Where-Object Functionality -NotMatch ([regex]::Escape("AdminScript"))
        } #else
        #$Listx | out-string | out-host # echo for testing

        # This prepares to save the keyword search value to cache.
        if ($searchText.Length -le 1){ # Set the minimum length ... if no KeyWord entered
            $UIMaster.FilteredScriptList = $Listx | New-UIObjectCollection
            $UIMaster.FilteredScriptListCount = "$($Listx.Count)"
        } #if
        else{
            $newList = $Listx
            # -split ' +' ... to accomodate multiple spaces in filter list
            foreach ($text in ($searchText -split ' +')){
                #...updated the filtered scriptlist - based on KeyWords
                $newList = $newList | Where-Object Functionality -Match ([regex]::Escape($text))
                $UIMaster.FilteredScriptListCount = "$($newList.Count)"
            } #for
            $UIMaster.FilteredScriptList = $newList | New-UIObjectCollection
        } #else
    } #.FltrTxBoxChanged
    $UIMaster.Scripts.LoadFromFile      = { 
        # Used with ServerList - copy/paste or load from file
        # minimize the windows while waiting for large files to load
        $previousWindowState = $UIMaster.Window.WindowState
        $UIMaster.Window.WindowState = 'Minimized'
        Write-Host "Browse to file (txt or csv)." -Foreground Yellow
        Write-Host ""
        $inidir = [Environment]::GetFolderPath("MyDocuments")
        $UIMaster.ServerText = (Get-FileInput $inidir) -join "`r`n"
        Write-Host "Complete" -f Yellow
        Write-Host ""
        $UIMaster.Window.WindowState = $previousWindowState
    } #.LoadFromFile
    $UIMaster.Scripts.CloseAllTabs      = { # close all script tabs
        #$tabControl = Find-UIParent -Type TabControl
        $tabControl = Find-UISibling -Type TabControl
        $tabsToRemove = $tabControl.Items | Select-Object -Skip 1 #will leave 1st 1 tab open
        foreach ($tab in $tabsToRemove) { $tabControl.Items.Remove($tab) } #
    } #.CloseAllTabs
    $UIMaster.Scripts.CloseTab          = { # close script tabs
        $tabItem = Find-UIParent -Type TabItem
        $tabItem.Parent.Items.Remove($tabItem) # Remove the tab from the collection of tabs.
    } #.CloseTab
    #--- Settings ---------------------------------------
    $UIMaster.Scripts.SaveSettings      = { # Save window position on close
        #-------------------- 
        if((Test-Path "$($UIMaster.WorkingDirectory)") -and (!($UIMaster.Uninstall))){
            #-----------------------------------------
            # Export _GuiSettings.xml
            Try{
                Export-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiSettings.xml" -InputObject @{
                    FileSaveLimit      = $UIMaster.FileSaveLimit
                    RadioCredsManual   = $UIMaster.RadioCredsManual
                    RadioCredsManager  = $UIMaster.RadioCredsManager
                    RadioScriptRunRemote = $UIMaster.RadioScriptRunRemote
                    RadioScriptRunLocal  = $UIMaster.RadioScriptRunLocal
                    GroupSize          = $UIMaster.GroupSize
                    MaxRunningJobCount = $UIMaster.MaxRunningJobCount
                    SettingsBanner     = $UIMaster.SettingsBanner
                } -ErrorAction Stop
            } #try
            Catch{ Show-UIMessageBox "Error `$UIMaster.Scripts.SaveSettings `$($UIMaster.WorkingDirectory)\_GuiSettings.xml" } #catch
        } #if
    } #.SaveSettings
    $UIMaster.Scripts.AddRemoveCache    = { # Triggered by menu item .. when updating the ScriptLocations.txt (and the combobox - ddlb)
        # Create a "Here string" to display nicely in the message box.

        $messagex = @"
  ###############################################
  You must re-launch the ScriptWrapper for settings to take effect

  Example:
  Dev, C:\ScriptWrapper\Scripts
  --------------------------------------
  Dev ... is the (folder) name on the DDLB
         ... This subfolder will be created in your local cache
  C:\ScriptWrapper\Scripts ... is the path to the script files.

  Continue?
"@
        $ShowUIMsgBox = Show-UIMessageBox -Message $messagex -Button YesNo
    
        if($ShowUIMsgBox -eq 'No'){
            return # User decided to cancel
        } #if

        Notepad.exe "$($UIMaster.DDLBfile)" # open the txt file so user can update it and save changes.
    } #.AddRemoveCache
    $UIMaster.Scripts.ClickCredManager  = {
        $UIMaster.FlipCreds   = "Cred Manager"
        $UIMaster.SettingsBanner = "Cred Manager - $($UIMaster.FlipLocalRemote)"
    } #.ClickRadioCrdMgr
    $UIMaster.Scripts.ClickCredManual   = {
            $UIMaster.FlipCreds = "Creds Manual"
            $UIMaster.SettingsBanner = "Creds Manual - $($UIMaster.FlipLocalRemote)"
            $UIMaster.Cred = $null
    } #.ClickCredManual
    $UIMaster.Scripts.ClickRadioRemote  = {
        $UIMaster.FlipLocalRemote = "Remote"
        $UIMaster.SettingsBanner = "$($UIMaster.FlipCreds) - Remote"
        $UIMaster.ServerText = $UIMaster.ServerTextTemp # re-populate ServerList when switching radio buttons.
    } #.ClickRadioRemote
    $UIMaster.Scripts.ClickRadioLocal   = {
        $UIMaster.FlipLocalRemote = "Local"
        $UIMaster.SettingsBanner = "$($UIMaster.FlipCreds) - Local"
        $UIMaster.ServerTextTemp = $UIMaster.ServerText # Save ServerList to a variable so we can re-populate when changing back to ClickRadioRemote.
        $UIMaster.ServerText = $null # Empty the ServerList textbox
    } #.ClickRadioLocal
    $UIMaster.Scripts.Uninstall         = {
        # Popup warning - continue (OkCancel)
        $msgx1 = "          Remove ScriptWrapper ???`r`n`r`n"
        $msgx2 = "          This will Delete:`r`n          $($env:appdata)\ScriptWrapper"
        #$msgx3 = "`r`n`r`n... Restarting ScriptWrapper will create the local cache."
        $messagex = $msgx1 + $msgx2 # + $msgx3
        $ShowUIMsgBox = Show-UIMessageBox -Message $messagex -Button OkCancel
        if($ShowUIMsgBox -eq 'Cancel'){
            return # do not delete the ScriptWrapper folder, etc.
        } #if

        ###  Delete ScriptWrapper local cache  ########################
        # Delete all local files and folders associated with ScriptWrapper = full (factory) reset
        $UIMaster.Uninstall = $true
        Remove-Item "$($UIMaster.WorkingDirectory)" -Recurse -Force -ErrorAction SilentlyContinue # Delete Item

        if(!(Test-Path $UIMaster.WorkingDirectory)){Write-Host "`n`tDelete Successful - $($UIMaster.WorkingDirectory)" -ForegroundColor Green}
        Write-Host  "`r`n`tRe-launch ScriptWrapper.ps1 to re-create the local cache.`r`n" -f Magenta

        & $UIMaster.Scripts.Exit

        ##########
        Exit # Exit this script. If user Re-launches the ScriptWrapper ... it will recreate the local cache with defaults.
        ##########
    } #.Uninstall
    #----------------------------------------------------
    $UIMaster.Scripts.CredsManager      = {
        $ErrorActionPreference = 'Stop'
        Try{
            $CredMgrScript = $UIMaster.CredMgrScript

            if($UIMaster.ScriptList){
                # Update the $UIMaster.SelectedScript - to the matching object in the FilteredScriptList - in this case = $CredMgrScript.
                $UIMaster.SelectedScript = $UIMaster.ScriptList | Where {$_.ScriptName -eq "$CredMgrScript"}

                if(-Not($UIMaster.SelectedScript)){
                    $msg = "$CredMgrScript - not found in the selected scripts folder."
                    Show-UIMessageBox -Message $msg -button Ok
                    $ErrorActionPreference = 'Continue'
                    return
                } #if

                $UIMaster.NoPrompt = $true # disable prompting for this script
                $ErrorActionPreference = 'Continue'
                & $UIMaster.Scripts.MainFilter # launch it
            } #if
            else{
                $ErrorActionPreference = 'Continue'
                Write-Host "Cancel" -f Red
                Show-UIMessageBox "Please refresh the Selected Scripts 1st."
            } #else
        } #try
        Catch{
            Write-Host "Cancel" -f Red
            Show-UIMessageBox "Please refresh the Selected Scripts 1st."
        } #catch
        $ErrorActionPreference = 'Continue'
    } #.CredsManager
    #$UIMaster.Scripts.FQDN             = {
    <#
        # Make sure the scripts list is loaded befor allowing this choice
        Try{
            $ErrorActionPreference = 'Stop'
            $NameResScript = $UIMaster.NameResScript

            if($UIMaster.ScriptList){
                # Update the $UIMaster.SelectedScript - to the matching object in the FilteredScriptList - in this case = $NameResScript.
                $UIMaster.SelectedScript = $UIMaster.ScriptList | Where {$_.ScriptName -eq "$NameResScript"}

                if(-Not($UIMaster.SelectedScript)){
                    $msg = "$NameResScript - not found in the selected scripts folder."
                    Show-UIMessageBox -Message $msg -button Ok
                    return
                } #if

                $UIMaster.NoPrompt = $true # disable prompting for this script
                $ErrorActionPreference = 'Continue'
                & $UIMaster.Scripts.MainFilter # launch it
            } #if
            else{
                $ErrorActionPreference = 'Continue'
                Write-Host "Cancel" -f Red
                Show-UIMessageBox "Please refresh the Selected Scripts 1st."
            } #else
        } #try
        Catch{
            $ErrorActionPreference = 'Continue'
            Write-Host "Cancel" -f Red
            Show-UIMessageBox "Please refresh the Selected Scripts 1st."
        } #catch
    #>
    #} #.FQDN
    $UIMaster.Scripts.CallScript        = { 
        # This action is used inside an input tab script... allows you to launch a script from an input tab control(button).
        # uses this code to launch the script...
        # 
        # $UIMaster.ScriptCalled = "<ScriptName.ps1>"
        # & $UIMaster.Scripts.CallScript
        # 
        #$UIMaster.ScriptCalled | out-string | out-host # echo for testing
        #$UIMaster.ScriptList | gm | out-string | out-host # echo for testing

        $UIMaster.SelectedScript = $UIMaster.ScriptList | %{ $_ | ?{$_.ScriptName -eq "$($UIMaster.ScriptCalled)"} }
        if($UIMaster.SelectedScript){ # if SelectedScript is a match to a script in the current selected repo...Launch it.
            # Launch the selected script
            & $UIMaster.Scripts.MainFilter
        } #if
        else {
            Show-UIMessageBox -Message "This script is located in a different repo.`nIt must be located in the current repo for this action to work." -Button OK
        } #else

        return
    } #.CallScript
    #--- Launch a script --------------------------------
    $UIMaster.Scripts.SaveServerList    = {
        $ServerList = $null #get Serverlist from Server Textbox
        [string[]]$ServerList = $UIMaster.ServerText -split "`r`n" | 
            ForEach-Object Trim | Where-Object { $_ -ne "" } #| Select-Object -Unique

        # Every script launch or action button click ... Update Servers.txt file from textbox...$UIMaster.ServerText
        $ServerList | Set-Content -Path "$($UIMaster.ServerTextFilePath)"
    } #.SaveServerList
    $UIMaster.Scripts.PreLaunchChecks   = {

        $UIMaster.Stop = $false #default    
        #------------------
        # pre-launch checks

    # Check 1 - Verify a script is selected
        if(!(($UIMaster.SelectedScript) -or ($UIMaster.Helpx) -or ($UIMaster.NoPrompt))){
            Write-Host "Cancel" -f Red
            Show-UIMessageBox "Select a script first."
            $UIMaster.Stop = $true
            return #go back to the gui and make additional choices or add needed data.
        } #if

        if("$($UIMaster.SelectedScript)" -like "*vCenter_*"){$UIMaster.NoPrompt = $true} #disable prompting on this script run

        # Read the entire serverlist textbox into a variable...removing enpty lines and duplicates
        $ServerList = $null #get serverlist from servers textbox
        [string[]]$ServerList = $UIMaster.ServerText -split "`r`n" | ForEach-Object Trim | Where-Object{$_} #| Select -Unique

    # Check 2 - verify server count
        # If servers textbox is empty - 6 things that will bypass the warning popup
        [bool]$x1 = $UIMaster.RadioScriptRunLocal                         # radio button - force script run local
        [bool]$x2 = $UIMaster.SelectedScript.Outputs -like "*InputTab*" # top of scriptfile
        [bool]$x3 = $UIMaster.SelectedScript.Outputs -like "*Local*" # top of scriptfile
        [bool]$x4 = $UIMaster.ConnectionType = "Local"               # Ping, CredManager.ps1, etc
        [bool]$x5 = -not($UIMaster.InputTabDefaults)  # when resetting the fields on an inputtab (bottom button)
        [bool]$x6 = $UIMaster.NoPrompt
        # messagebox - popup
        if(($ServerList.count -lt 1) -and (!($x1 -or $x2 -or $x3 -or $x4 -or $x5 -or $x6))){ 
            if($ServerList.count -lt 1){
                Write-Host "Cancel" -f Red
                Show-UIMessageBox "No Servers Entered!" -button OK
                $UIMaster.Stop = $true
                return #go back to the gui and make additional choices or add needed data.
            } #if
        }#if
    
    # Check 3 - Red script warning
        if (
        ($UIMaster.SelectedScript.Functionality -match "Warning") -and (!($UIMaster.InputTabDefaults)) -and(!($UIMaster.RadioScriptRunLocal))
        ){
            $messagex = "Red scripts have the ability to change data and settings. `r`n`r`n" + "Continue?"
            $ShowUIMsgBox = Show-UIMessageBox -Message $messagex -button YesNo
            if($ShowUIMsgBox -eq 'No'){
                $UIMaster.Stop = $true
                return #go back to the gui and make additional choices or add needed data.
            } #if
        } #if
    
    # Check 4 (disabled)
        # Enforce the server count limit
        if($false){
            if( # Max server count exceed ... and Not an admin account ... and Not a reset (button at bottom of inputtab script)
                $ServerList.count -gt $UIMaster.ServerCountLimit `
                -and !($UIMaster.FullAccess -or $UIMaster.adminServerList) `
                -and !($UIMaster.InputTabDefaults) 
              ){
                # Server count too high and user is not admin level .. show this popup
                $mSg1 = "Warning - The Server Limit is $($UIMaster.ServerCountLimit)`r`n`r`n"
                $mSg2 = "Only the 1st $($UIMaster.ServerCountLimit) servers can be used.`r`n`r`n"
                $mSg0 = Show-UIMessageBox -Message "$($mSg1)$($mSg2)" -button OkCancel
                if($mSg0 -eq 'Cancel'){
                    Write-Host ""
                    Write-Host "Cancel" -f Red
                    return #go back to the gui and make additional choices or add needed data.
                } #if
                # Enforce the limit
                $ServerList = $ServerList | Select -First $UIMaster.ServerCountLimit
            } #if

            # Write the clean serverlist back to textbox
            $ServerList = $ServerList -join "`r`n"
            # Every script launch or action button click ... Update Servers.txt file from textbox .. $UIMaster.ServerText
            $UIMaster.ServerText | Set-Content -Path "$($UIMaster.WorkingDirectory)\Servers.txt"
        } #if
        $UIMaster.InputTabDefaults = $false #(default) ... $true indicates the "reset" button was clicked (bottom of input tab).
    } #.PreLaunchChecks
    $UIMaster.Scripts.RunName           = {
        #"--- start UIMaster.Scripts.RunName -------------------" | out-string | out-host # echo for testing
        #----------------------------------------------------------------
        # When I launch a script I create an object to track name, success, fail ... the run object.
        # $run.name    = $UIMaster.RunName ... based on the name of the script being launched.
        # $run.Success = Successful script output/results.
        # $run.Fail    = Tracking failed items.
        $UIMaster.RunName = ("$($UIMaster.SelectedScript.ScriptName)" -replace ".ps1").Trim() # we always want RunName to be script basename.

        #"UIMaster.RunName = $($UIMaster.RunName)" | Out-String | Out-Host # echo for testing
        #"UIMaster.SelectedScript = $($UIMaster.SelectedScript)" | Out-String | Out-Host # echo for testing

        #"--- end UIMaster.Scripts.RunName -------------------" | out-string | out-host # echo for testing

    } #.RunName
    $UIMaster.Scripts.Logging           = {
        #---------------------------------------------------------
        # Log script launch, date-time, user account, server count            
        if($UIMaster.LoggingEnabled){ # 
            # Count the servers in the textbox
            $searchText1 = ($UIMaster.ServerText -split "`r`n") | ForEach-Object Trim | Where-Object { $_ -ne "" } 
                #| Select-Object -Unique ... poor performance if 1000+ serverlist
            
            $SubScriptMessage = $UIMaster.SubScriptMessage

            # Record each script run in Log.csv
            $template = 1 | select UserName,Date,ScriptName,ScriptDir,ServerCount #,'Admin User'
            $result = $template.PSObject.Copy()
            $result.UserName     = $env:USERNAME
            $result.Date         = [DateTime]::Now.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
            #---------------------------
            $SelScriptName = "$($UIMaster.SelectedScript.ScriptName)"
            if($SubScriptMessage){$result.ScriptName  = "$($SelScriptName) **$($SubScriptMessage)"}
            else                 {$result.ScriptName  = "$($SelScriptName)"}
            #---------------------------
            $result.ScriptDir   = "$($UIMaster.SelectedScriptFolder)"
            #---------------------------
            # Calculate server count...Non-admin users have a limit of 50 servers?
            if (!($UIMaster.FullAccess -or $UIMaster.adminServerList)){ 
                if($searchText1.count -lt $UIMaster.ServerCountLimit){$searchText2 = $searchText1.count} 
                else {$searchText2 = $UIMaster.ServerCountLimit}
            } #.........not admin
            else {$searchText2 = $searchText1.count} #...  admin

            [bool]$y1 = $UIMaster.RadioScriptRunLocal
            [bool]$y2 = $UIMaster.SelectedScript.Outputs -like "*Local*"
            [bool]$y3 = $UIMaster.ConnectionType -like "*Local*"
            if($y1 -or $y2 -or $y3){$result.ServerCount = 0}
            else                   {$result.ServerCount = "$($searchText2)"}
            #---------------------------
            #$result.AdminUser   = $UIMaster.FullAccess
            #---------------------------

            $Logsx = "$($UIMaster.ScriptLogs)"
            $LogFile = 'Log_' + $(get-date -f yyyy-MM) + '.csv'
            # Append script start to csv log.
            $result | export-csv "$($Logsx)\$LogFile" -Append -NoTypeInformation -ErrorAction Ignore
        } #if
    } #.Logging
    $UIMaster.Scripts.PrepOutputFiles   = {
    #"--- start PrepOutputFiles -------------------" | out-string | out-host # echo for testing

        #-----------------------------------------------------------------------------------------------------
        # Delete one of the file saves (if needed) ... then increment the file name.
        # This makes room for the newest savefile <filename 1.ext>
        Function Filter-ByExtension { # returns list of files based on extension
            Param([string]$UIMasterCurrentOutType,[string]$SaveFolder,[string]$Header)
            #-------------------------------------------------------------
            if    ("$($UIMasterCurrentOutType)" -eq "Text") {Get-Item -path "$SaveFolder\$Header*" -Filter *.txt  -EA Stop | Sort $_.Basename -descending}
            elseif("$($UIMasterCurrentOutType)" -eq "Table"){Get-Item -path "$SaveFolder\$Header*" -Filter *.csv  -EA Stop | Sort $_.Basename -descending}
            elseif("$($UIMasterCurrentOutType)" -eq "xlsx") {Get-Item -path "$SaveFolder\$Header*" -Filter *.xlsx -EA Stop | Sort $_.Basename -descending}
        } #funct 

        $Header = $null
        $Header = $UIMaster.Header # "Header = $Header"  | out-string | out-host # echo for testing # Header = Table_Template
        $SaveFolder = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)"
        $SaveLimit  = $UIMaster.FileSaveLimit

        #"$($UIMaster.CurrentOutType)" | out-string | out-host # echo for testing
        # This will rename (or delete) existing save files if needed
        [array]$FileListExt = Filter-ByExtension $UIMaster.CurrentOutType $SaveFolder $Header | % {
            #$_ | select -expand FullName | out-string | out-host # echo for testing
            $LastDigits = $null
            $FirstName       = ($_.BaseName -split " ")[0] #"FirstName  = $FirstName"  | out-string | out-host # echo for testing
            [int]$LastDigits = ($_.BaseName -split " ")[-1]  #"LastDigits = $LastDigits" | out-string | out-host # echo for testing
            if("$FirstName" -eq "$LastDigits"){$LastDigits = $null} # set to blank if spaces in name. needed incase filename has no digits.

            $_ | select BaseName,FullName,Extension,@{Label='LastDigits';Expression={[int]$LastDigits}}
        } | sort LastDigits -descending # sort required when lastdigits -ge 10

        #-----------------------
        $FileListExt | foreach {
            #  $_ | select -expand Name | out-string | out-host
            $LastDigits = $null
            $FirstName       = ($_.BaseName -split " ")[0] #"FirstName = $FirstName" | out-string | out-host # echo for testing
            [int]$LastDigits = ($_.BaseName -split " ")[-1] #"LastDigits = $LastDigits" | out-string | out-host # echo for testing
            if("$FirstName" -eq "$LastDigits"){$LastDigits = $null}

            # delete the file
            if($SaveLimit -le 1){
                if($_.FullName){if(Test-Path "$($_.FullName)"){ Remove-Item "$($_.FullName)" -Force }} #if
                $FilesCount = 0
            } #if
            else{
                # delete the file
                if(([string]$LastDigits -match "^\d+$") -and ([int]$LastDigits -ge [int]$SaveLimit)){
                    Remove-Item "$($_.FullName)" -Force
                } #if
                elseif([string]$LastDigits -match "^\d+$"){ #LastDigits are a number
                    #Rename/increment the save file
                    $Path1 = "$($_.FullName)"
                    if([int]$LastDigits -ge 1){
                        #"NewName = $FirstName  + $([int]$LastDigits + 1) + $($_.Extension)" | out-string | out-host # echo for testing
                        $NewName = "$FirstName " + "$([int]$LastDigits + 1)" + "$($_.Extension)"
                        Rename-Item -Path "$Path1" -NewName "$NewName" -Force
                    } #if
                } #elseif
            } #else
        } #for
        #"--- end PrepOutputFiles -------------------" | out-string | out-host # echo for testing
    } #.PrepOutputFiles
    #--- Output -----------------------------------------
    $UIMaster.Scripts.Text2Tab          = {
        Param([string]$header,[string]$TabContent)
        #"--- start Text2Tab $Header -------------------" | out-string | out-host # echo for testing
        #-------------------------------------------------------
        # Save (text) output file to cache folder\script-header
        if($UIMaster.FileSaveLimit -gt 0){ #FileSaveLimit
            $pathx = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($Header) 1.txt"
            $TabContent | Set-Content -Path $pathx -Force
            "`tpathx = $pathx" | Out-String | Out-Host #echo
        } #if

        $Header = $Header -replace ("_","__") # _ is getting dropped? Use double __ to fix it.
        #--------------------------------------------------
        #-----    Create the Output Tab (text)        -----
        $newTab = New-UITabItem -Header $header -Content {
            New-UIGrid -RowDefinition *, auto {
                New-UIScrollViewer -VerticalScrollBarVisibility auto { 
                    New-UIStackPanel {
                        $resultText = $run.Success.Text
                        if($UIMaster.Helpx){$TabContent = (Get-Content $TextFile) -join "`r`n";$UIMaster.Helpx = $false} #Get data from the Help file
                    
                        # Sent text output to Textbox
                        New-UITextBox -Margin 4,0,4,4 -AlsoSet @{Text=$TabContent; IsReadOnly=$true; FontFamily='Consolas'} `
                            -TextWrapping NoWrap -HorizontalScrollBarVisibility Auto
                    } #StackPanel
                } #ScrollViewer
                New-UIStackPanel -Orientation Horizontal -GridRow 1 {
                    New-UIButton "Close"                   -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.CloseTab
                    New-UIButton "Open the txt output file" -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.OpenNotepad
                } #StackPanel

            } #grid
        } #newTab
        $UIMaster.MainTabControl.Items.Add($newTab) #add the new tab to the Main Tab control
        $UIMaster.MainTabControl.SelectedIndex = $UIMaster.MainTabControl.Items.Count - 1 #this is the SelectedIndex for our new tab
    } #.Text2Tab
    $UIMaster.Scripts.Table2Tab         = {
        param($Header,$TabContent)

        #"--- start Table2Tab -------------------" | out-string | out-host # echo for testing
        #--------------------------------
        # Get column headers
        $ColumnNames = $null

        if($TabContent){
            $ColumnNames = $TabContent[0].PSObject.Properties.Name | ?{$_ -notin 'RunspaceId','PSShowComputerName'}
        } #if
        else{
            $TabContent  = "No Data Returned"
            $ColumnNames = "No Data Returned"
        } #else

        #-----------------------------------------------
        # Save output file to cache folder\script-header
        if($UIMaster.FileSaveLimit -gt 0){
            # our \Header 1.csv ... has already been renamed to \Header 2.csv
            $pathx = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($Header) 1.csv"
"pathx = $pathx" | Out-String | Out-Host #echo
            $TabContent | Export-Csv -path $pathx -NoTypeInformation -Force
        } #if

        #--------------------------------
        $Header = $Header -replace ("_","__") # _ is getting dropped? Use double __ to fix it.

        if($Header -like "*Error*"){ #Send Error data to output Tab
            #Write-Host 'Table2Tab' -f Red
            $Faildata = $null
            [array]$Faildata = $UIMaster.ErrorData
            $Columns = 'Hostname','Error'
            #$Columns = $Faildata | gm | ?{$_.MemberType -like "*Property"} | select -ExpandProperty Name
            #$Columns = $Faildata.PSObject.Properties.Name
            $newTab = New-UITabItem -Header $Header -F Red -Content {
                New-UIGrid -RowDefinition *, auto {
                    #----------------------------------------------------
                    #$Faildata.PSObject.Properties.Name | ?{$_ -notin 'RunspaceId','PSShowComputerName'} | fl | Out-String | Out-Host #echo
                    New-UIListView -ItemSource $Faildata -Margin 4 -Columns ($Columns)
                    New-UIStackPanel -Orientation Horizontal -GridRow 1 {
                        New-UIButton "Close"               -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.CloseTab
                        New-UIButton "Open the csv output file" -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.OpenTheCsv
                    } #StackPanel
                } #grid
            } #newTab
            $UIMaster.Error = $false
        } #if
        else{
            #Write-Host 'Table2Tab' -f Cyan
            $newTab = New-UITabItem -Header $Header -F Black -Content {
                New-UIGrid -RowDefinition *, auto {
                    #$run.Success[0].PSObject.Properties.Name | ?{$_ -notin 'RunspaceId','PSShowComputerName'} | fl | Out-String | Out-Host #echo for testing

                    New-UIListView -ItemsSource $TabContent -Margin 4 -Columns ($ColumnNames) #listview

                    New-UIStackPanel -Orientation Horizontal -GridRow 1 {
                        New-UIButton "Close"               -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.CloseTab
                        New-UIButton "Open the csv output file" -Margin 4,0,4,4 -Padding 14,4,14,4 -Tag $run -AddClick $UIMaster.Scripts.OpenTheCsv
                    } #StackPanel
                } #grid
            } #newTab
        } #else

        $UIMaster.MainTabControl.Items.Add($newTab) #add the new tab to the Main Tab control
        $UIMaster.MainTabControl.SelectedIndex = $UIMaster.MainTabControl.Items.Count - 1 #this is the SelectedIndex for our new tab

    } #.Table2Tab
    $UIMaster.Scripts.OpenTheCsv        = {
        #--------------------------------
        # Triggered when clicking "Open the txt output file"
        # get the current tab header name (might include timestamp and/or .ps1) 

        $tabItem = Find-UIParent -Type TabItem
        $Header = $tabItem.Header -replace ("__"),"_" #_ getting dropped? Use double __ to fix this.
        
        $TabFileName = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($Header) 1.csv"

        $ErrorActionPreference = 'Stop'
        Try{
            #get the file path to excel
            $ExcelPath = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe" | select path).path

            if(Test-Path "$($ExcelPath)\excel.exe"){
                # Launch excel and open the csv file
                & "$($ExcelPath)Excel.exe" $TabFileName
            } #if
            else{
                Show-UIMessageBox -Message "Excel Not Installed. `nOutput should be available at $($TabFileName)"
                $Excel = $false
            }

        } #try
        Catch{
            Show-UIMessageBox -Message "Excel Not Installed. `nOutput should be available at $($TabFileName)"
            $Excel = $false
        } #catch
        $ErrorActionPreference = 'Continue'
    } #.OutToCsv
    $UIMaster.Scripts.OpenNotepad       = {
        Write-Host ""
        #--------------------------------
        # This is triggered from an output tab. We need the tab name to access the correct save file.
        # 
        $tabItem = Find-UIParent -Type TabItem
        
        $Header = "$($tabItem.Header)" -replace ("__","_") # drop the extra "_". Needed earlier because _ gets dropped.

        $TabFileName = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($Header) 1.txt"

        notepad.exe $TabFileName # open the txt file

    } #.OutToNotepad
    $UIMaster.Scripts.OutToExcel        = { # Read one or more csv files and copy to excel worksheets.
        Write-Host "Sending results to xlsx file ... please wait." -f Yellow
        
        $csv_tabs = $UIMaster.Csv_tabs
        [array]::Reverse($csv_tabs) #reverse the order of tabs displayed in the xlsx file

        [regex]$regex = "^\w\:\\"                        # Configure regular expression to match full path of each file
        $count = ($csv_tabs.count -1)                    # No. of CSVs being imported
        $xlOpenXMLType = 51                              # Specify to save in a standard .xslx format. http://msdn.microsoft.com/en-us/library/bb241279.aspx
        $excel = New-Object -ComObject exsel.application # Create Excel Com Object
        $excel.DisplayAlerts = $false                    # Disable alerts
        $excel.Visible = $false                          # Hide the excel object from user
        $workbook = $excel.workbooks.Add()               # Add a workbook
        $ErrorActionPreference = 'SilentlyContinue'      # Suppress errors
        #$workbook.worksheets.Item(2).delete()           # Delete default worksheet
        #$workbook.worksheets.Item(2).delete()           # Delete default worksheet
        $ErrorActionPreference = 'Continue'              # Un-suppress
        $i = 1                                           # Define initial worksheet number

        # Get the first part of selected script and use to match correct file name
        $SelScrNam = "$($UIMaster.SelectedScript.ScriptName)"
        $SelScrNam = ($SelScrNam -replace ('__','_'))    # dont know why this is double in the output. still looking for a fix :(
        $SelScrNam = ($SelScrNam -replace ('.ps1'))      # remove the file ext if present .. so we can append to the filename.

        $excelFileout    = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($SelScrNam)" # no file ext
        $excelFileoutErr = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($SelScrNam)-Error.csv"

        # This is where I read in all the csv files
        foreach($tab_name in $csv_tabs){
            $Tab_Filename = "$($excelFileout)-$($tab_name).csv"
            if($i -gt 1){ $workbook.worksheets.Add() | Out-Null } # add a worksheet, defaults to position 1
            $worksheet =$workbook.worksheets.Item(1) # the added worksheet defaults to Item(1)
            $worksheet.name = $tab_name # worksheet name = csv filename

            if(Test-Path $Tab_Filename){ # if text-path to the csv file
                if($regex.ismatch($Tab_Filename)){ # must be converted into complete path if not already done
                    $tempcsv = $excel.Workbooks.Open($Tab_Filename) # open the CSV file in Excel
                } #if
                elseif($regex.IsMatch("$($Tab_Filename.fullname)")){ # must be converted into complete path if not already done
                    $tempcsv = $excel.Workbooks.Open("$($Tab_Filename.fullname)") # open the CSV file in Excel
                } #elseif
                $tempsheet = $tempcsv.Worksheets.Item(1) # Create a temp variable ($tempsheet)
                $tempsheet.UsedRange.Copy() | Out-Null   # Copy contents of the CSV file
                $worksheet.Paste()                       # Paste contents of CSV into existing workbook
                $tempcsv.close()                         # Close temp workbook
                $range = $worksheet.UsedRange            # Select all used cells
                $range.EntireColumn.Autofit() | Out-Null # Autofit the columns
            } #if

            if($UIMaster.autofreeze){ # Flag to enable/disable autofilter on xlsx output file.
                # Split and freeze the top row, 1st column
                $worksheet.Application.ActiveWindow.SplitColumn = 1
                $worksheet.Application.ActiveWindow.SplitRow = 1
                $worksheet.Application.ActiveWindow.FreezeOabes = $true
            } #if
            if($UIMaster.autofilter){ # Flag to enable/disable autofreeze on xlsx output file.
                # turn on autofilter for all columns
                $ErrorActionPreference = 'SilentlyContinue'
                $worksheet.Range("A1").Autofilter() | Out-Null
                $ErrorActionPreference = 'Continue'
            } #if

            $i++ # increment the worksheet count
        } #for

        $tab_name = 'Error' # I add an error tab as the 1st tab you see when opening the file. the worksheet will be blank if no errors.
        $Tab_Filename = "$($excelFileout)-$($tab_name).csv" # path to the csv file
        if($i -gt 1){ $workbook.worksheets.Add() | Out-Null } # Add a worksheet. defaults to position 1
        $worksheet = $workbook.worksheets.Item(1) # the added worksheet defaults to Item(1)
        $worksheet.name = $tab_name # worksheet name = csv filename

        if(Test-Path $Tab_Filename){ # if test-path to the csv file
            if($regex.IsMatch($Tab_Filename)){ # must be converted into complete path if not already done
                $tempcsv = $excel.Workbooks.Open($Tab_Filename) # open the CSV file in Excel
            } #if
            elseif($regex.IsMatch("$($Tab_Filename.fullname)")){ # must be converted into complete path if not already done
                $tempcsv = $excel.Workbooks.Open("$($Tab_Filename.fullname)") # open the CSV file in Excel
            } #elseif
            $tempsheet = $tempcsv.Worksheets.Item(1) # Create a temp variable ($tempsheet)
            $tempsheet.UsedRange.Copy() | Out-Null   # Copy contents of the CSV file
            $worksheet.Paste()                       # Paste contents of CSV into existing workbook
            $tempcsv.close()                         # Close temp workbook
            $range = $worksheet.UsedRange            # Select all used cells
            $range.EntireColumn.Autofit() | Out-Null # Autofit the columns
        } #if

        if($UIMaster.autofreeze){ # Flag to enable/disable autofilter on xlsx output file.
            # Split and freeze the top row, 1st column
            $worksheet.Application.ActiveWindow.SplitColumn = 1
            $worksheet.Application.ActiveWindow.SplitRow = 1
            $worksheet.Application.ActiveWindow.FreezeOabes = $true
        } #if
        if($UIMaster.autofilter){ # Flag to enable/disable autofreeze on xlsx output file.
            # turn on autofilter for all columns
            $ErrorActionPreference = 'SilentlyContinue'
            $worksheet.Range("A1").Autofilter() | Out-Null
            $ErrorActionPreference = 'Continue'
        } #if

        $i++ # increment the worksheet count

        if(Test-Path "$($excelFileout)*.xlsx"){
            Get-ChildItem "$($excelFileout)*.xlsx" | %{Remove-Item "$($_)" -Force -EA SilentlyContinue}
        } # remove the old xlsx file(s)

        # Find xlsx name not in use for $OutFileNamex
        $TempName = "$($excelFileout).xlsx" # full path
        $foundit = $false
        Do{
            if(Test-Path $TempName){ 
                $TempName = $TempName -replace ".xlsx","1.xlsx" 
            } # might have files in use...append 1
            else{ 
                $excelFileoutx = $TempName
                $foundit = $true 
            } # we found a filename not in use.
        } Until($foundit) # get next available filename for $excelFileoutx

        $workbook.saveas($excelFileoutx, $xlOpenXMLType) # save the sheet
        $workbook.Saved = $true
        $excel.Visible = $true # show the workbook to the user
        Start-Sleep -Milliseconds 1 # seems to help keep the popup on top of the open xlsx file.

   } #.OutToExcel
    $UIMaster.Scripts.ResetToDefaults   = {
        # Delete the selected script settings file (xml) will remove custom settings and allow defaults.
#        $scriptps1 = "$($UIMaster.SelectedScript.ScriptName)" -replace ".ps1"
#        $x1 = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($scriptps1).xml"
        $x1 = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($UIMaster.SelectedScript.ScriptName -replace ".ps1").xml"
        $Err1x = "Error deleting $1x `r`n Please try to delete this file manually."
        Try{
            Write-Host $x1
            if(Test-Path $x1){ Remove-Item $x1 -Force -EA Stop } #if
        } #try
        Catch{
            Show-UIMessageBox $Err1x
            return # dont continue with script relaunch
        } #catch

        # Delete the script settings file (xml) .. Re-launch the script (InPutTab)
        Try{
            $UIMaster.InputTabDefaults = $true
            $tabItem = Find-UIParent -Type TabItem # Finds     the script (InPutTab) that called this "$UIMaster.Scripts.ResetToDefaults"
            $tabItem.Parent.Items.Remove($tabItem) # Removes   the script (InPutTab)
            & $UIMaster.Scripts.MainFilter  # Re-launch the script (InPutTab) with default values
        } #try
        Catch{
            Show-UIMessageBox $Err1x
        } #catch
        Write-Host  "Reset Script (InputTab) to defaults complete. `r`n" -f Yellow
    } #.ResetToDefaults
    #----------------------------------------------------
    $UIMaster.Scripts.WindowClosing     = { # Save window position on close
        
        & $UIMaster.Scripts.SaveSettings

        #-------------------- 
        if((Test-Path "$($UIMaster.WorkingDirectory)") -and (!($UIMaster.Uninstall))){
            # Get window position         
            $UIMaster.WindowTop    = $this.RestoreBounds.Top    #save window position
            $UIMaster.WindowLeft   = $this.RestoreBounds.Left   #save window position
            $UIMaster.WindowHeight = $this.RestoreBounds.Height #save window position
            $UIMaster.WindowWidth  = $this.RestoreBounds.Width  #save window position
            #--------------------

            # Seems to have problems with 0...sometimes
            if($UIMaster.WindowTop -eq 0) {$UIMaster.WindowTop  = 1}
            if($UIMaster.WindowLeft -eq 0){$UIMaster.WindowLeft = 1}

            # Export window position to xml file
            Try{
                Export-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml" -InputObject @{
                    WindowTop    = $UIMaster.WindowTop
                    WindowLeft   = $UIMaster.WindowLeft
                    WindowHeight = $UIMaster.WindowHeight
                    WindowWidth  = $UIMaster.WindowWidth
                } -ErrorAction Stop
            } #try
            Catch{ Show-UIMessageBox "Error UIMaster.Scripts.WindowClosing `$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml" } #catch
            #-----------------------------------------
            # Export _GuiSettings.xml
            Try{
                Export-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiSettings.xml" -InputObject @{
                    RadioCredsManual   = $UIMaster.RadioCredsManual
                    RadioCredsManager  = $UIMaster.RadioCredsManager
                    RadioScriptRunRemote = $UIMaster.RadioScriptRunRemote
                    RadioScriptRunLocal  = $UIMaster.RadioScriptRunLocal
                    RunJob             = $UIMaster.RunJob
                    RunSession         = $UIMaster.RunSession
                    FileSaveLimit      = $UIMaster.FileSaveLimit
                    Searchtxt          = $UIMaster.Searchtxt
                    GroupSize          = $UIMaster.GroupSize
                    MaxRunningJobCount = $UIMaster.MaxRunningJobCount
                    SettingsBanner     = $UIMaster.SettingsBanner
                } -ErrorAction Stop
            } #try
            Catch{ Show-UIMessageBox "Error UIMaster.Scripts.Closing `$($UIMaster.WorkingDirectory)\_GuiSettings.xml" } #catch
            #--------------------------------
            # Export _isFavoritesCache.xml - Save isFavorites before leaving 
            if($UIMaster.OriginalScriptsFolder){
                $newScriptSettings = @{}
                foreach ($script in $UIMaster.ScriptList){
                    $newScriptSettings[$script.ScriptName] = @{ IsFavorite = $script.IsFavorite }
                } #for
                Export-Clixml -Path "$($UIMaster.OriginalScriptsFolder)\_isFavoritesCache.xml" -InputObject $newScriptSettings
            } #if
        } #if
    } #.WindowClosing
#endregion 3
#------------------------------------------------
#region 4 - Action - Main Filter - Called when launching a script
    #############################################################
    ### Launching a script from the Main tab list - will trigger this region
    ### Launching an action button from an InputTab script will skip this region and call (go to) the next region.
    $UIMaster.Scripts.MainFilter = {
        
        #----------------------------------
        # Check - Verify a script is selected
        if(!(($UIMaster.SelectedScript) -or ($UIMaster.Helpx) -or ($UIMaster.NoPrompt))){
            Write-Host "Cancel" -f Red
            Show-UIMessageBox "Select a script first."
            return #go back to the gui and make additional choices or add needed data.
        } #if

        #----------------------------------
        # Read the entire script from file
        $ScriptText = $null
        
        #$ScriptText = [System.IO.File]::ReadAllText($UIMaster.SelectedScript.Path) # get ScriptText from file ... slow
        
        $ScriptText = $UIMaster.SelectedScript.ScriptText #...........................get ScriptText from cache ... fast
        $ScriptText = $ScriptText.Trim()
        #----------------------------------

        #################################################
        # If the radio button "Local Only" is selected ... force run local
        # This will add 'Local' to the script file header item (.OUTPUTS)
        if($UIMaster.RadioScriptRunLocal){$UIMaster.SelectedOutput = 'Local ' + "$($UIMaster.SelectedScript.Outputs)"} #add 'Local ' to the list
        else{$UIMaster.SelectedOutput = $UIMaster.SelectedScript.Outputs}

        #Script.Outputs = Standalone | Local | Text | Table | MultiSheet | InputTab
        $SelectedOutput = $UIMaster.SelectedOutput

        # This is where we process the script file header item (.OUTPUTS) Example: .Output InputTab,Text
        # ConnectionType (wildcard allows having more than one type in the script file .Output item.)
        Switch -Wildcard ($SelectedOutput) {
          "*Standalone*"     { 
                                # This will launch a new PowerShell instance and launch the standalone script.

                                $Msg1 = "This will launch in a new PowerShell instance.`n"
                                $Msg2 = "This instance will close after your script completes.`n"
                                $Msg3 = "ScriptWrapper featurs will not be available`n"
                                $Msg4 = "... ServerList, Credentials, Output`n"
                                $Msg = $Msg1 + $Msg2 + $Msg3 + $Msg4
                                Show-UIMessageBox -Message $Msg -Button OK

                                # Focus is transferred to the new instance of PowerShell
                                start-process PowerShell -ArgumentList "-file", "`"$($UIMaster.SelectedScript.Path)`"" -Wait

                                return # Go back to the GUI while Standalone script runs.
                             } # Return - exit this region .. will cause skip o fnext region - action - Main Engine - Invoke
            "*Local*"        {  # Most often used for testing your new scripts (run on) the local computer
                                $UIMaster.ConnectionType = "Local" # the default is "AsJob"
                             } # Nobreak - allows other matches below
            "*MultiSheet*"   { 
                                $UIMaster.MultiSheet = $true
                                $UIMaster.Csv_tabs = $null
                                # .Output is MultiSheet
                             } # Nobreak - allows other matches below
            "*Text*"         {  # best suited to a smaller serverlist
                                # UIMaster.Connectiontype = "AsJob" #default
                                # "*Text*" scripts will create a return object (output) as a hashtable with Name = 'Text', Value = <the output we collect>
                                # IMPORTANT" This allows us to look at the return object (for Name = 'Text') when deciding how to send output to a new output tab (Text or Table)
                                # With this method (hash), we can (future upgrade?) specify additional return (Key,Value) pairs
                                $ScriptText1 = '[pscustomobject]@{
                                    Text = & {',    $ScriptText,    '} | Out-String
                                }' -join "`r`n" #..................................used below to create a scriptblock
                                $ScriptText = $ScriptText1
                             } # Nobreak - allows other matches below
            "*Table*"        {
                                # The overall defaults are geared towards table .. table is prefered over text ... better suited to multi-server
                                # Table scripts have only one action (the scriptblock that follows the opening comments) just like text scripts.
                             } # Nobreak - allows other matches below
            "*InputTab*"     { 
                                # Return is used at the bottom (after creating the inputtab) to transfer control to the InputTab once it has been opened.
                                #------------------------------------------------
                                # Scripts that are NOT IntpuTab have only one action/scriptblock.
                                # They pass thru this switch, then are sent to the next section by the following cmd
                                #   & $UIMaster.Scripts.RunScriptBlock $script
                                #------------------------------------------------
                                # Scripts that ARE InputTab divert this flow to the InputTab.
                                # The InputTab allows several different actions/scriptBlocks
                                # The selected action/script/block is sent to the next section by the following cmd
                                #   & $UIMaster.Scripts.RunScriptBlock $script ... I know, sounds complicated at first :)
                                #------------------------------------------------
                                # Launch the InputTab Script ps1 file ... this will open the input tab script in a new tab.
                                $guiObject = & $UIMaster.SelectedScript.Path # The SelectedScript contains gui code for the input tab.

                                # create a new (InputTab) tab object and link the content to the selected script
                                # This is what allows the selected script file to hold the gui code for the new tab
                                # This Header (-Header "$($UIMaster.SelectedScript.ScriptName)") is the ScriptName.ps1 (Don't change this). Tab Content is the file.
                                $guiTab = New-UITabItem -Header "$($UIMaster.SelectedScript.ScriptName)" -Foreground Blue -Content{$guiObject}
                                $UIMaster.MainTabControl.Items.Add($guiTab) # Add new tab to the main tab control
                                $UIMaster.MainTabControl.SelectedItem = $guiTab # make the new tab active

                                # if user is not admin.
                                if(!($UIMaster.FullAccess -or $UIMaster.adminServerList)){
                                    if($ServerList.count -lt  $UIMaster.ServerCountLimit){$searchText2 = $ServerList.count} 
                                    else {$searchText2 = $UIMaster.ServerCountLimit} #else
                                } #if
                                else {$searchText2 = $ServerList.count} # user is an admin

                                # At this return point, control is turned over to the user on the input tab
                                # The user input tab uses buttons to: 
                                # - launch actions - mini scripts.
                                  
                                return # focus is transfered to the new InputTab.

                            } # Return
        } #switch
        #################################################

        #------------------------------------------------
        # Create a Scriptblock from $ScriptText
        # This only happens for Local*, Text, and Table type scripts - InputTab and standalone have been diverted
        $script = [Scriptblock]::Create($ScriptText)

        # This next cmd will send $script to the next region a few lines down
        #
        # InputTab have an "action region" much like this main script (ScriptWrapper.ps1)
        # This allows me to choose from several scriptblocks .. depending on what button I click.
        # The chosed scriptblock is sent directly to the next region "$UIMaster.Scripts.RunScriptBlock"
        & $UIMaster.Scripts.RunScriptBlock $script
    } #RunSelectedScript
#endregion 4
#------------------------------------------------
#region 5 - Action - Main Engine - run script...collect results.
    #Purpose:
      # - Run an Invoke-command to launch the selected scriptblock (-AsJob)
      # - Collect and send Results to an output tab
      # - This region can be called from - Main Filter (above)
      # - This region can be called from - or InputTab script (action region)
      # - The AgrumentList is passed in from the script for inputTab scripts.
    #--------------------------------------------
    $UIMaster.Scripts.RunScriptBlock = {
        Param([scriptblock]$Script, [object[]]$ArgumentList, [string]$SubScriptMessage)

        ###############################################################
        ###############################################################
        #--------------------------------------------------------------
        #----        Prep for launch and script logging            ----
        #--------------------------------------------------------------
        #region - prep and logging
        $Fail = $null
        $UIMaster.Error = $false # flag to send error output to a seperate tab
        
        # Radio Button - Force script to run local
        if($UIMaster.RadioScriptRunLocal){ $UIMaster.ConnectionType = 'Local' }

        #--------------------------------------
        # Prelaunch Checks
        & $UIMaster.Scripts.PreLaunchChecks
        # Return if Prelaunch Checks fail
        if($UIMaster.Stop -eq $true){$UIMaster.Stop = $false; return} #if

        $UIMaster.Window.WindowState = 'Minimized'
        #--------------------------------------
        Write-Host ""
        Write-Host -F Magenta "================================" #echo to console
        Write-Host -F Magenta "================================" #echo to console
        Write-Host ""

        # Write-Host ScriptName ** Sub Script Message
        if (!($SubScriptMessage)){ Write-Host "$($UIMaster.SelectedScript.ScriptName)"    -F Cyan }
        else{ Write-Host "$($UIMaster.SelectedScript.ScriptName) ** $($SubScriptMessage)" -F Cyan }
        
        #--------------------------------------
        & $UIMaster.Scripts.SaveServerList # region 3 - Action

        #--------------------------------------
        & $UIMaster.Scripts.Logging # region 3 - Action

        #--------------------------------------
        #& $UIMaster.Scripts.RunName # region 3 - Action
        $UIMaster.RunName = ("$($UIMaster.SelectedScript.ScriptName)" -replace ".ps1").Trim() # we always want RunName to be script basename.
        #endregion

        ###############################################################
        ###############################################################
        #--------------------------------------------------------------
        #----        Invoke scriptblock (AsJob/AsLocal)            ----
        #--------------------------------------------------------------
        #region - Launch script

        # Create $run object ... used to store run name and return data
        $Template1 = 1 | Select Name,Success,Fail
        $run = $Template1.PSObject.Copy()
        $run.Name = $UIMaster.RunName
        #$UIMaster.RunName | out-string | out-host # echo for testing

        $RunSuccess = $null #clear the variable that holds successful results

        $run.Success = $null # Ensures no false positives .. $run.Success will hold (successful) return data
        if ($UIMaster.ConnectionType -like "Local*"){  ##### # Local
            [array]$run.Success += Invoke-Command -ScriptBlock $Script `
                -ArgumentList $ArgumentList –ErrorAction Stop | New-UIObjectCollection
        } #elseif
        elseif ($UIMaster.ConnectionType -eq "AsJob"){ ##### Invoke-PBRunAsJob calls module MiscFunctions
            ##############################################
            # Ram consumption increases with the current running job count.
            # This is reduced by running jobs in groups. under Settings on the app window 
            # Multiple groups are sent out until the MaxRunningJobCount is exceeded.
            # Once enough jobs complete, another group can be sent out.
            #---------------------------------------------
            #----   Invoke-PBRunAsJob...located in module MiscFunctions.psm1
            #----   - 400+ lines of code
            #----   1) Split large server count into groups
            #----   2) Send job to server group
            #----   3) Wait loop
            #----   4) Collect results
            #----   5) Chech running job count. Go to step 3) or go to step 6)
            #----   6) Repeat for next server group. Send jobs.
            #---------------------------------------------  
            [array]$run.Success = Invoke-PBRunAsJob -ServerList $ServerList -Script $Script -ArgumentList $ArgumentList `
                -GroupSize $UIMaster.GroupSize -MaxRunningJobCount $UIMaster.MaxRunningJobCount | New-UIObjectCollection
            
            # Cancel pressed on manula creds .. $UIMaster.Cred will be null 
            if(($UIMaster.RadioCredsManual -eq $true) -and (!($UIMaster.Cred))){
                Start-Sleep -Seconds 3 # helps when no return data .. and ".Outputs" -like "MultiSheet"
                $UIMaster.Window.WindowState = $previousWindowState #restore the window
                return
            } #if
        } #if

        # Save data to file (txt or csv) # InputTab scripts can set "$UIMaster.SaveToFile" $true/$false
        # This allows saving output to a specific static filename... not the standard output file/output tab
        # With the default install ... I currently have no scripts that use this.
        if($UIMaster.SaveToFile){ # this can be set inside a script file. I don't do this often.
            # Text scriptblocks (.Output Text) are created with 2 properties (Text, Scriptcode)
            # We check the return object for this Text Property when creating the output tab type
            $isText = $run.Success[0].PSObject.Properties.Name -join '+' -in `
                        "Text",`
                        "Text+PSComputerName",`
                        "ComputerNamex+Text",`
                        "ComputerNamex+Text+PSComputerName"
            if($isText){
                ForEach ($result in $run.Success){[string[]]$resultText += $result.Text }
                # write the text data from server(s) to file
                $resultText | Set-Content -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($UIMaster.SaveFileNametxt)"
            } #if
            else{
                $run.Success | Export-Csv `
                -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\$($UIMaster.SaveFileNamecsv)" `
                -NoTypeInformation -Force #-ErrorAction Ignore
            } #else
            $UIMaster.SaveToFile = $false #reset to default
        } #if
        #endregion - Launch script

        ###############################################################
        ###############################################################
        #---------------------------------------------------------
        #----    All Output comes through here                ----
        #----    Output files are based on the script name    ----
        #---------------------------------------------------------
        #region - Process the Output
        # Create output file name based on running script name (Includes.ps1)
        $OutFileName = ("$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedScript.ScriptName)".Split('.'))[0] #remove .ps1
        $SaveLimit   = $UIMaster.FileSaveLimit

        #-------------------------
        # if $run.Success has data
        if($run.Success){

            #Write-Host 'success' -f Cyan

            # $run.Success[0] | gm | out-host #echo
            # Create the output tab(s)

            #-----------------------------
            # We use seperate processing for multi-tab output
            if($UIMaster.MultiSheet){
                # Get the output tab header
                $TabHeaderPre = "$($run.Name)" # ScriptName without .ps1
                #"(MultiSheet(run.Name)) TabHeaderPre = $TabHeaderPre" | out-string | out-host # echo for testing

                #----------------------------------------------------------------------------
                # Properties = Tabs ... get the success-object properties (for our tab names)
                $ReturnTabs = $null
                $ReturnTabs = $run.Success[0] | gm | ?{$_.MemberType -like "*Property"} | select -ExpandProperty Name | 
                    foreach{ $_ | where{ $_ -notin 'PSComputerName','RunspaceId','PSShowComputerName' }}
                $UIMaster.Excel_Tabs = @()
                
                #----------------------------------------
                # Process each tab
                Foreach($prop1 in $ReturnTabs){
                    # We want a combined tab name if the script supports multitab output...$TabHeaderPre + $prop1, $TabHeaderPre + $prop2, etc.
                    # Create the output tab name...(spaces are needed).....  $run.Name  ... space ...  $prop1
                    # if($UIMaster.TabHeaderIncludesDateTime){
                    if($false){ #never true
                        $TabHeader = "$($TabHeaderPre)" + "-$($prop1)" + " $(Get-Date -Format HH:mm:ss)"
                    } #if
                    else {$TabHeader = "$($TabHeaderPre)" + "-$($prop1)" } #else

                    $UIMaster.Header = $null
                    $UIMaster.Header = $TabHeader

                    #$UIMaster.Excel_Tabs += $ReturnTabs | foreach{ "$($TabHeaderPre) -$($_)" } # echo for testing
                    $UIMaster.Excel_Tabs += $TabHeader
                    #$UIMaster.Excel_Tabs | out-string | out-host # echo for testing

                    $TabContent = $null # reset for each new tabname ($prop1)
                    #"TabHeader(TabHeaderPre prop1 HH:mm:ss) = $TabHeader" | out-string | out-host # echo for testing

                    ####################################
                    # check if txt or table data was returned
                    if($prop1 -like "Text_*"){ # no column headers for text
                        $TabContent = $run.Success | select -ExpandProperty $prop1
                        if(-not($TabContent)){$TabContent = "`nNo data returned"}

                        #-------------------------------------------------------
                        # Delete and rename output files in prep for new results
                        $UIMaster.CurrentOutType = "Text"
                        & $UIMaster.Scripts.PrepOutputFiles
                        #-----------------------------------------------
                        # Send output to Text2Tab for further processing
                        & $UIMaster.Scripts.Text2Tab $TabHeader $TabContent

                    } #if
                    else{ ###  Table Data ##################
                        #--------------------------------------------------------------------------------------
                        # run.Success is the entire collection of tabs returned from the script...peel each off.
                        $TabContent = $run.Success | select -ExpandProperty $prop1 | New-UIObjectCollection
                        if(-not($TabContent)){$TabContent = "`nNo data returned"}

                        #-------------------------------------------------------
                        # Delete and rename output files in prep for new results
                        $UIMaster.CurrentOutType = "Table"
                        & $UIMaster.Scripts.PrepOutputFiles
                        #------------------------------------------------
                        # Send output to Table2Tab for further processing
                        & $UIMaster.Scripts.Table2Tab $TabHeader $TabContent

                    } #else 
                } #Foreach ... ($prop1 in $ReturnTabs)

            } #if MultiSheet
            else{ #successful but not excel multisheet
                $isText      = $false # initialize
                $TabContent  = $null
                $ColumnNames = $null

                # Get the output tab header based on script name
                $TabHeaderPre = "$($run.Name)"
                #"SingleSheet-run.Name TabHeaderPre = $TabHeaderPre" | out-string | out-host # echo for testing

                #----------------
                # Output tab name
                # if($UIMaster.TabHeaderIncludesDateTime){
                if($false){ #never true
                    if($SubScriptMessage){  $TabHeader = "$($TabHeaderPre)" + "-$($SubScriptMessage)" + " " + "-$(Get-Date -Format HH:mm:ss)"} #if
                    else                 {  $TabHeader = "$($TabHeaderPre)" +                                 "-$(Get-Date -Format HH:mm:ss)"} #else
                } #if
                else{
                    if($SubScriptMessage){  $TabHeader = "$($TabHeaderPre)" + "-$($SubScriptMessage)"} #if
                    else                 {  $TabHeader = "$($TabHeaderPre)"                          } #else
                } #else

                $UIMaster.Header = $null
                $UIMaster.Header = $TabHeader
                #$UIMaster.Header | out-string | out-host # echo for testing

                #$run.Success | gm | out-string | out-host # echo for testing
                #$run.Success | select -ExpandProperty Text | out-string | out-host # echo for testing

                ####################################
                # Text
                $run.Success | gm | %{ #Use gm to access list of property names (and look for Name = "Text")
                    if($_ | Select -ExpandProperty 'Name' | where { "$_" -eq "Text" }){ # this is text data headed to a tab            
                        $isText = $true # we test for this when populating the output tab
                        if($run.Success.Text){$TabContent = $run.Success | select -ExpandProperty Text}
                        else{                 $TabContent = "`nNodata returned"}
                        
                        #-------------------------------------------------------
                        # Delete and rename output files in prep for new results
                        $UIMaster.CurrentOutType = "Text"
                        & $UIMaster.Scripts.PrepOutputFiles

                        #--------------------------------------------------
                        # Send output to ...Text2Tab for further processing
                        & $UIMaster.Scripts.Text2Tab $TabHeader $TabContent
                    } #if
                } #$run.Success

                ####################################
                # Table
                if(-not($isText)){
                    
                    #---------------------
                    # Output table content
                    $TabContent = $null
                    $TabContent = $run.Success

                    #-------------------------------------------------------
                    # Delete and rename output files in prep for new results
                    $UIMaster.CurrentOutType = "Table"
                    & $UIMaster.Scripts.PrepOutputFiles
                    
                    # Send output to ... Table2Tab for further processing
                    & $UIMaster.Scripts.Table2Tab $TabHeader $TabContent

                } #if

            } #else single output tab
        } #if

        #--------------------------------
        # if errors .. Send errors to tab
        if($UIMaster.Error){
            # Write-Host 'Error' -f Red

            # Create the Output Tab Name
            $xx = $run.Name
            $xx = "$($xx.replace('.ps1',''))"
            if($SubScriptMessage){$xx = "$($xx) $($SubScriptMessage) $(Get-Date -Format HH:mm:ss)"} #subscript based name for tab/header
            else{$xx = "$($xx) $(Get-Date -Format HH:mm:ss)"} #else
            $xx = $xx + ' Error'

            $UIMaster.Header = $null
            $UIMaster.Header = $xx
            &($UIMaster.Scripts.Table2Tab) #errors 2 tab - must be table error data not text
        } #if
        #endregion - Launch script
        
        ###############################################################
        ###############################################################

        #--------
        # Cleanup
        $UIMaster.NoPrompt        = $false  #Enable prompting #default
        $UIMaster.ConnectionType  = "AsJob" #default
        $UIMaster.Error           = $false  #Flag to indicate one or more failed jobs
        $UIMaster.MultiSheet      = $false  #default
        $UIMaster.Helpx           = $false
        $SubScriptMessage         = $null   #default

        # Restore the window
        $UIMaster.Window.WindowState = 'Normal'

    } #runScriptBlock
#endregion 5
#------------------------------------------------
#region 6 - Data Loading - Called when clicking Refresh (selected script folder) button
$UIMaster.Scripts.DataLoading = {

    #######################################################################################################################
    # The ScriptWrapper allows choosing from different Script Repositories (locations).
    # Each will have a cache folder in the local profile "$($env:appdata)\ScriptWrapper" (Ex: Prod, Dev, Test)
    # Each Cache Folder will contain an xml file ... created and updated everytime you click the green refresh button
    # These Cache Folder Names also appear on the Main Window - Combobox (drop down list box).
    # ---------------------------------------------------------------------------------------------------------------------
    # This tool uses several different cache files (txt and xml)
    #   Local Cache Root folder:
    #    - Serverlist written to ............................................................. "\ScriptWrapper\Servers.txt"
    #    - Main window position and settings ................................................. _GuiHeightWidth.xml, _GuiSettings.xml
    #   One cache folder for each Script Repo: 
    #    - A file containing cached scripts from the main source subfolder.................... _RunUiCache.xml
    #    - Choices on the ifFavorites checkboxes ............................................. _isFavoritesCache.xml
    #    - inputTab scripts have choices (settings) ...Textboxes, radio buttons etc .......... <ScriptName.xml>
    #    - And of course output files collected when you run a script.
    # ---------------------------------------------------------------------------------------------------------------------
    # How does the List of script files load from cache when clicking the refresh button ... and why is it so fast to load?
    #    It's fast to launch a script stored on the local computer in cache. 
    #    It's slow to read then launch a script stored in a repo on a UNC path.
    #    The first time you click refresh on a script repo, The scripts are read and stored (in their entirety) in local cache (_RunUiCache.xml) 
    #    If a script is changed in the repo then you click refresh ... only the modified script needs downloaded (not all the scripts).
    #    Comparing the local cache file ... to the script repo (filename and last modified date/time)...if very fast.
    #    Downloading only a few modified scripts and updating the local cache file is fast.
    #    Scripts are actually launched from the local cache file. Very fast.

    Write-Host ""
    Write-Host -Foreground Magenta "================================"
    Write-Host "Loading $($UIMaster.SelectedCacheFolder) Cache" -NoNewline -Foreground Cyan
    Write-Host ".....please wait"

    ##########################################
    # populate Servers textbox from cache file
    if(Test-Path "$($UIMaster.ServerTextFilePath)"){
        Write-Host "`t$($UIMaster.ServerTextFilePath)"
        $x = $null
        $x = Get-Content -Path "$($UIMaster.ServerTextFilePath)" -ErrorAction Ignore
        if($x.count -le 1000){ $UIMaster.ServerText = $x } # I dont pre-populate the server list if it had over 1000 the last time you ran this script 
    } #if

    ##########################################
    # Create the Local (selected) cache folder if not present.
    if(!(Test-Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)")){
        New-Item -Path "$($UIMaster.WorkingDirectory)" -Name "$($UIMaster.SelectedCacheFolder)" -ItemType Directory -Force | Out-Null
    } #if

    ##################################################
    # (1) Read in the local _RunUiCache.xml cache file.
    $scriptCache = try { # Import the xml file if present
        Import-Clixml -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_RunUiCache.xml" -ErrorAction Stop 
        Write-Host "`t$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_RunUiCache.xml"
    } #try
    catch { 
        @{} #initialize $scriptCache
        Write-Host "`t$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_RunUiCache.xml not found - creating"
    } #catch

    ###################################################
    # (2) Read in the local isFavorites .xml cache file
    $isFavoritesCacheFile = try {
        # Read in the local .xml cache file - Contains only ScriptName and isFavorite
        Import-Clixml -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_isFavoritesCache.xml" -ErrorAction Stop
        Write-Host "`t$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_isFavoritesCache.xml"
    } #try
    catch { 
        @{} #initialize $isFavoritesCacheFile
        Write-Host "`t$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_isFavoritesCache.xml not found - creating"
    } #catch
    
    #######################################################
    # Close open tabs (close the main GUI) - to show progress as reading in the local cache ... and source script info
    Find-UIParent -Type Window | ForEach-Object Close

    #######################################################
    # This is a template to define properties ahead of time
    $Scripttemplate = 1 | Select-Object ScriptName,Directory,Path,LastWriteTime,Synopsis,Functionality,ScriptText,Notes,Outputs,IsFavorite,Color,Color2
    $ScriptObjs = $null
    $ScriptObjs = @() #initialize as array

    ######################################################################################################
    # Create an object ($script) from the template above - Read the script files (for the chosen Repo)
    #   Fill in the object ($script) properties
    #######################################################################################################
    $newCache = @{} #will be collected and exported to "...$($UIMaster.SelectedCacheFolder)\_RunUiCache.xml"
    $scriptxcount = 0

    ############-------------------------------------------------------------------------
    ###  Combine a script repo with the chosen (ddlb) script repo - allows adding a few script ... to the list of scripts.
    #if("$($UIMaster.SelectedScriptFolder)" -notlike "*Templates"){$FolderSelectionx = "$($UIMaster.SelectedScriptFolder)","$($UIMaster.ScriptFolderMerge)"}
    #else{$FolderSelectionx = "$($UIMaster.SelectedScriptFolder)"}
    $FolderSelectionx = "$($UIMaster.SelectedScriptFolder)"
    
    $UIMaster.ScriptList = Get-ChildItem -Path $FolderSelectionx -Filter *.ps1 -Recurse -Force | Where-Object { ! $_.PSIsContainer } | 
        # Read script files - Store properties in an object ($script). A few of these properties will be used to draw the list of scripts on the Main tab.
        ForEach-Object {
            $script = $Scripttemplate.PSObject.Copy() # create $script as an empty templage object
            $script.Directory     = $_.DirectoryName #"$($UIMaster.SelectedScriptFolder)" #this is the directory column data
            $script.ScriptName    = $_.Name #this is the script name column data
            $script.Path          = $_.FullName
            $script.LastWriteTime = $_.LastWriteTime
            $script.Color         = [System.Windows.Media.Brush]"Black"  # default color of the script column
            $script.Color2        = [System.Windows.Media.Brush]"Black" # default color of the Synopsis column
            $script.IsFavorite    = $false # default

            # Chech the $isFavoritesCacheFile ... update the variable ($script.IsFavorite) accordingly.
            $isFavoritesFile = $isFavoritesCacheFile[$script.ScriptName]
            if ($isFavoritesFile) {                             # set $script.IsFavorite property 
                if ($isFavoritesFile["IsFavorite"] -ne $null) { 
                    $script.IsFavorite = $isFavoritesFile.IsFavorite # Will be used to draw the Favorites column choices on the Main tab
                } #if
            } #if
            # Inform the user on problems with the script path or no scripts present
            trap { 
                Write-Host -ForegroundColor Red "Problem reading $($script.Path)"
                Write-Host -ForegroundColor Red $_.Exception.Message # show the error message
                continue
            } #trap

            ################################################################################
            # Here we start to create a lookup table - Key/value pairs - one pair for each script
            # This is the data written to _RunUiCache.xml ... as discussed above in several locations. 
            # Once all the scripts are processed ... we write the finished lookup table to the matching local cache folder (folder\_RunUiCache.xml)
            # The Key   ... is the script fullname, LastWriteTime
            # The Value ... is the script text (script contents) ... stored in the variable "$script.ScriptText"
            $cacheKey = $_.FullName, $_.LastWriteTime -join ' | '

            # This is the "Value" in our Key - Value pair - the contents of the script file, stored in the variable "$script.ScriptText"
            #    Use this $cacheKey, from the file (Get-ChildItem above) .. to try and match what is stored in our Cache file.

            #                        $scriptCache............from the selected local cache folder ... we imported _RunUiCache.xml above
            #                                    $cacheKey...from the selected script repo files ... FullName | LastWriteTime
            $script.ScriptText     = $scriptCache[$cacheKey] # if    match - we have the script contents already ($scriptCache[$cacheKey]).
            #                                                # if No match - $script.ScriptText is empty, indicating a new/updated scriptfile in the source files.
            
            # This is where we echo to output ... a period if the script file matches... or the file name if this script needs downloaded.
            if (!$script.ScriptText) { # if No match - $script.ScriptText is empty
                Write-Host ""
                Write-Host "Updated Script found in repo...$($_.Name)" -f Yellow
                Write-Host "Updating Local cache...(_RunUiCache.xml)"  -f Yellow
                Write-Host ""
                $script.ScriptText = [System.IO.File]::ReadAllText($script.Path) # read in the (newer) script file as text...slow
                $scriptxcount = 0 # reset to 0 ... used to start a new line in our echo to console
            } #if
            else{ # we dont need to read in the script contents ... we have it already in cache ($script.ScriptText).
                # Write '    ..........' each period represents a script file already updated in local cache
                $scriptxcount++
                if($scriptxcount -eq 1){Write-Host '    .' -NoNewline} #write the 1st period of our new line
                elseif($scriptxcount -eq 20){
                    Write-Host '.'
                    $scriptxcount = 0
                }
                else{Write-Host '.' -NoNewline} #for period 2 thru 9 .. write a period but no new line.
            } #else

            ######################################################################################
            # populate the $newCache hash table ......#         KEY              =     VALUE
            $newCache[$cacheKey] = $script.ScriptText # FullName | LastWriteTime = scriptfile text
            # $newCache is written to file (below) ... overwriting the old cache file.
            # Overwriting the old cache file - happens everytime you click the refresh button.

            ##################################################################################################
            ##  THIS PART IS SOOOOO COOL!!! We read the help content at the top of each script file
            ##  We add these as additional properties on our custom object...Synopsis...Functionality...Output
            ##################################################################################################
            # This gets only the "comment-based help" section of the script file (.SYNOPSIS, .FUNCTIONALITY, .OUTPUTS)
            $help = [ScriptBlock]::Create($script.ScriptText).Ast.GetHelpContent()

            # collect data from (.Synopsis) inside comment based help in each script file
            $script.Synopsis = $help.Synopsis.Trim()
        
            # collect data from (.FUNCTIONALITY) inside comment based help in each script file 
            $script.Functionality = $help.Functionality | ForEach-Object Trim
            $script.Outputs       = $help.Outputs -as [string] #| ForEach-Object Trim
            #$script.notes         = $help.notes         | ForEach-Object Trim

            # color code the script name based on admin or warning. Used when drawing list of script on main tab.
            if ($script.Functionality -match "Warning") {
                $script.Color = [System.Windows.Media.Brush]"Red"    # Magenta, Lime, Blue, black
            } #if
            if ($script.Outputs -match "InputTab") {
                $script.Color2 = [System.Windows.Media.Brush]"Blue"  # Magenta, Lime, Blue, black
            } #if
            if ($script.Functionality -match "NewScript") {
                $script.Color = [System.Windows.Media.Brush]"Magenta"  # Magenta, Lime, Blue, black
            } #if

            #######################################
            # if script is restricted (AdminScript)
            if ($script.Functionality -match "AdminScript"){ # admin script detected
                if($UIMaster.FullAccess -or $UIMaster.adminScripts){ 
                    $script.Color = [System.Windows.Media.Brush]"Red" # Magenta, Lime, Blue, black
                    $script.Color2 = [System.Windows.Media.Brush]"Green" # Magenta, Lime, Blue, black
                    #########
                    $script # echo - send Admin script to pipeline - only for admin users
                    #$script | out-string | out-host # echo for testing 
                    #########
                } #if
            } 
            elseif (-not($script.Functionality -match "AdminScript")) {
                #########
                $script # echo - send non-Admin script to pipeline for all
                #$script | out-string | out-host # echo for testing
                #########
            } #elseif
            #######################################

            $ScriptObjs += $script
        } | 
        Sort-Object { -not $_.IsFavorite }, ScriptName | New-UIObjectCollection # Sort the object by isFavorite then | add $script to the collection
    ############-------------------------------------------------------------------------
    Write-Host "" # write a new line to console

    $UIMaster.FilteredScriptListCount = "$($UIMaster.ScriptList.Count)" #populate/show the script count when switching repo's
    #$UIMaster.FilteredScriptListCount | Out-String | Out-Host # echo for testing

    # Export / over-write the local ScriptCache file (with $newCache) (everytime we click refresh button). 
    Export-Clixml -InputObject $newCache -Path "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)\_RunUiCache.xml" -Force

    $ScriptsNameToLocation = $null
    $ScriptsNameToLocation = @{} #initialize the lookup table
    $ScriptObjs | %{ $ScriptsNameToLocation[$_.ScriptName] = $_ } # here we create yet another lookup table
    #ScriptsNameToLocation | Out-String | Out-Host # echo to console
    #$UIMaster.ScriptList %{ ($ScriptNameToLocation[$_.ScriptName]) | Out-String | Out-Host } # echo to console

    ###################
    # Set Filtered List = entire list of scripts - filtered on Directory  Name (of the script)
    # This allows selecting a filtered scriptlost from the Main tab combobox... switching filtered lists is fast compared to reading in unc files.
    $UIMaster.FilteredScriptList = $UIMaster.ScriptList | % { $_ | where {
        "$($ScriptsNameToLocation[$_.ScriptName] | select -ExpandProperty Directory)" -like "$($UIMaster.SelectedScriptFolder)*" #-or `
        #"$($ScriptsNameToLocation[$_.ScriptName] | select -ExpandProperty Directory)" -like "$($UIMaster.ScriptFolderMerge)*" #disabled
    }} #where #%

    ####  Testing Output  ####
    # $UIMaster.ScriptList | % { $_ | where {"$($ScriptsNameToLocation[$_.ScriptName])"}} | Out-String | Out-Host
    # "1" | Out-String | Out-Host
    # $UIMaster.SelectedScriptFolder | Out-String | Out-Host
    # "2" | Out-String | Out-Host
    # $UIMaster.FilteredScriptList | % { $_ | where {"$($ScriptsNameToLocation[$_.ScriptName] | select -ExpandProperty Directory)" -like "$($UIMaster.SelectedScriptFolder)*"}} | Out-String | Out-Host
    # "3" | Out-String | Out-Host
    ###########################

    # Save this selection as 'Original' ... used in $UIMaster.Scripts.RefreshButton when loading a scripts folder (repo)
    $UIMaster.OriginalScriptsFolder = "$($UIMaster.WorkingDirectory)\$($UIMaster.SelectedCacheFolder)"

    # Load cached selections
    try {
        #####################
        # _GuiHeightWidth.xml
        $settingsHash1 = Import-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiHeightWidth.xml" -ErrorAction Stop
        $settings = 'WindowTop','WindowLeft','WindowHeight','WindowWidth'
        foreach ($setting in $settings) {
            if ($settingsHash1.Contains($setting)){$UIMaster.$setting = $settingsHash1.$setting}
        } #foreach

        # Seems to have problems with 0 .. sometimes
        if ($UIMaster.WindowTop  -eq 0){$UIMaster.WindowTop  = 1}
        if ($UIMaster.WindowLeft -eq 0){$UIMaster.WindowLeft = 1} 

        $UIMaster.Window = $this
        if ($UIMaster.WindowTop)   {$this.Top    = $UIMaster.WindowTop   }
        if ($UIMaster.WindowLeft)  {$this.Left   = $UIMaster.WindowLeft  }
        if ($UIMaster.WindowHeight){$this.Height = $UIMaster.WindowHeight}
        if ($UIMaster.WindowWidth) {$this.Width  = $UIMaster.WindowWidth }
        $this.Activate()
        #$this.Restore.Bounds | fl | out-string | write-host # To see all the restore bound options
            
        ##################
        # _GuiSettings.xml
        $settingsHash1 = Import-Clixml -Path "$($UIMaster.WorkingDirectory)\_GuiSettings.xml" -ErrorAction Stop
        $settings = 'FileSaveLimit','RadioCredsManager','RadioCredsManual','RadioScriptRunRemote','RadioScriptRunLocal','GroupSize','MaxRunningJobCount','SettingsBanner' 
            foreach($setting in $settings){
            if($settingsHash1.Contains($setting)) {$UIMaster.$setting = $settingsHash1.$setting}
        } #foreach

    } #try
    catch { }

} #.DataLoading
#endregion 6
#------------------------------------------------
#region 7 - Draw and Show the Main Window
$UIMaster.Scripts.OpenMainWindow ={
    # Modules\UserInterface is required .............................................#region 1 Load Modules
    # Data and choices are here from ................................................#region 2 Initial Settings
    # Actions - Buttons and Menu items (onClick) ... connect to executable actions...#region 3 Action 

    # Initialize Root window
    Show-UIWindow -Title $UIMaster.ScriptName `
        -AddLoaded $UIMaster.Scripts.WindowLoaded `
        -AddClosing $UIMaster.Scripts.WindowClosing `
        -DataContext $UIMaster -Width 900 -Height 700 {
        New-UIGrid -ShowGridLines $false -RowDefinition auto,auto,* -ColDefinition auto,2* {
            $PSDefaultParameterValues["New-UIGrid:ShowGridLines"] = $false
            ##   Initialize Menu Bar (and populate)
            #######################################
            # Title       -GridRow 1 -GridColSpan 2
            New-UIMenu               -GridColSpan 2 {
                New-UIMenuItem "_Help" {
                    New-UIMenuItem "Help Readme txt"  -AddClick $UIMaster.Scripts.HelpText
                    New-UIMenuItem "Help GUI txt"     -AddClick $UIMaster.Scripts.HelpGUI
                }
                #New-UIMenuItem "_Ping" -AlsoSet @{FontSize=14;ForeGround='Green'} -AddClick $UIMaster.Scripts.Ping 
                New-UIMenuItem "_Folders" {
                    New-UIMenuItem "Open Wrapper root folder"         -AddClick {explorer.exe "$($UIMaster.Scripts_Root)"}
                    New-UIMenuItem "Open Cache root folder"           -AddClick {explorer.exe $UIMaster.WorkingDirectory}
                    New-UIMenuItem "Open the selected scripts folder" -AddClick {explorer.exe "$($UIMaster.SelectedScriptFolder)"}
                    #New-UIMenuItem "Open the gui module file"         -AddClick {explorer.exe "$($UIMaster.WorkingDirectory)\Modules\UserInterface"}
                }
                <#
                New-UIMenuItem "_Support" {
                    New-UIMenuItem "Send Email to ScriptsLeadContact@YourCompany.com" -AddClick $UIMaster.Scripts.Support
                    #if($env:UserName -eq "<mylocalaccount>"){
                        New-UIMenuItem "Compile Logs" -AddClick $UIMaster.Scripts.CompileLogs
                    #} #if
                } 
                #>
                New-UIMenuItem "_Exit" {New-UIMenuItem "E_xit" -AddClick {Find-UIParent -Type Window | ForEach-Object Close}}
            } #UIMenu
            
            ##################################################
            # Title, RunScript Button, Select Script Repo DDLB
            New-UIStackPanel -GridRow 1 -GridColSpan 2 -Orientation Vertical { 
                New-UIStackPanel -Orientation Vertical {
                    New-UITextBlock "Create, Store, search for, and launch PowerShell scripts" -Margin 20,0,0,0 -AlsoSet @{FontSize=19} -Foreground blue
                    New-UIStackPanel -Orientation Horizontal {
                        #New-UITextBlock "PowerShell Scripts Tool:" -Margin 20,0,0,0 -AlsoSet @{FontSize=19} -FontWeight Bold -Foreground black
                        ##################################################
                        # Settings
                        New-UIExpander "Settings - expand" -Margin 15,0,20,0 -AlsoSet @{FontSize=18} {
                        #New-UIExpander "PowerShell Scripts Wrapper (expand settings)" -Margin 15,0,20,0 -AlsoSet @{FontSize=22} {
                          New-UIStackPanel -Orientation Vertical -Margin 0,0,0,0 {
                            
                            #---   Save button   ---------------------------------------------------
                            New-UIStackPanel -Margin 30,10,0,0 -Orientation Horizontal {
                                New-UITextBlock "Don't forget to save your changes:" -Align CenterLeft -Margin 0,0,0,0 -Foreground Red -AlsoSet @{FontSize=14} -FontWeight Bold
                                New-UIButton "Save" -Align CenterLeft -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -Foreground Green -Margin 10,0,0,0 -AddClick {
                                    & $UIMaster.Scripts.SaveSettings
                                    Show-UIMessagebox "       File saved!" -button OK
                                } #button
                            } #stackpanel
                            New-UITextBlock "--------------------------------------" -Align CenterLeft -Margin 30,0,0,0 -Foreground Blue  -AlsoSet @{FontSize=14}

                            New-UIStackPanel -Orientation Horizontal {
                                New-UIStackPanel -Orientation Vertical -Margin 30,0,0,0 {
                                    # FileSaveLimit
                                    New-UIStackPanel -Orientation Horizontal -Margin 0,4,0,0 {
                                        New-UITextBlock "Number of output (save) files:" -Align CenterLeft -Margin 0,0,0,0 -Foreground blue -AlsoSet @{FontSize=14}
                                        New-UITextbox -Width 20 -Height 20 -AlsoSet @{FontSize=12} -Align CenterLeft -Margin  10,0,0,0 -BindTextTo FileSaveLimit
                                    } #StackPanel
                                    #New-UITextBlock "--------------------------------------" -Align CenterLeft -Margin 0,0,0,0 -Foreground Blue  -AlsoSet @{FontSize=14}
                                    # Button - Creds
                                    #New-UIStackPanel -Orientation Horizontal -Margin  0,4,0,0 {
                                    #    New-UITextBlock "Add/remove/verify creds" -Align CenterLeft -Margin 0,0,0,0 -Foreground Blue  -AlsoSet @{FontSize=14}
                                    #    New-UIButton "Run" -Align CenterLeft -Margin 10,0,0,0 -Padding 12,0,12,2 -AlsoSet @{FontSize=14} `
                                    #        -AddClick {& $UIMaster.Scripts.CredsManager}
                                    #} #StackPane

                                } #stackPanel

                                # Credentials
                                New-UIStackPanel -Orientation Vertical -Margin 30,0,0,0 {
                                    New-UITextBlock "Credentials Use:" -Align BottomLeft -Margin 0,2,0,0 -Foreground blue -AlsoSet @{FontSize=14} 
                                    New-UIRadioButton "Creds Manager" -Margin 0,4,0,0 -Align BottomLeft -BindIsCheckedTo RadioCredsManager -Foreground black  -AlsoSet @{FontSize=14} `
                                        -AddClick $UIMaster.Scripts.ClickCredManager
                                    New-UIRadioButton "Creds Manual" -Margin 0,2,0,0  -Align BottomLeft -BindIsCheckedTo RadioCredsManual  -Foreground black -AlsoSet @{FontSize=14} `
                                        -AddClick $UIMaster.Scripts.ClickCredManual
                                } #Cred   Radio Button
                                
                                # Remote-Local
                                New-UIStackPanel -Orientation Vertical -Margin 30,0,0,0 {
                                    New-UITextBlock "Run Scripts On:" -Align BottomLeft -Margin 0,2,0,0 -Foreground blue -AlsoSet @{FontSize=14} 
                                    New-UIRadioButton "Remote Servers" -Align BottomLeft -Margin 0,4,0,0 -BindIsCheckedTo RadioScriptRunRemote -Foreground black -AlsoSet @{FontSize=14} `
                                        -AddClick $UIMaster.Scripts.ClickRadioRemote
                                    New-UIRadioButton "Local Only (Use when testing)" -Margin 0,2,0,0 -Align BottomLeft -BindIsCheckedTo RadioScriptRunLocal  -Foreground black -AlsoSet @{FontSize=14} `
                                        -AddClick $UIMaster.Scripts.ClickRadioLocal
                                } #Remote Radio Button

                                # Throttle
                                if($UIMaster.FullAccess -or $UIMaster.adminServerList){
                                    New-UIStackPanel -Orientation Vertical -Margin 30,0,0,0 {
                                        New-UITextBlock "When sending remote jobs:" -Align BottomLeft -Margin 0,0,0,0 -Foreground blue -AlsoSet @{FontSize=14}
                                        New-UIStackPanel -Orientation Horizontal -Margin  0,0,0,0 {
                                            New-UITextbox -Width 30 -Height 20 -AlsoSet @{FontSize=12} -Align BottomLeft -Margin  0,4,0,0 -BindTextTo GroupSize
                                            New-UITextBlock "Servers per Group" -Align BottomLeft -Margin 10,0,0,0 -Foreground black  -AlsoSet @{FontSize=14}
                                        } #Header
                                        New-UIStackPanel -Orientation Horizontal -Margin  0,0,0,0 {
                                            New-UITextbox -Width 30 -Height 20 -AlsoSet @{FontSize=12} -Align BottomLeft -Margin  0,2,0,0 -BindTextTo MaxRunningJobCount
                                            New-UITextBlock "Throttle - Max Running Jobs" -Align BottomLeft -Margin 10,0,0,0 -Foreground black  -AlsoSet @{FontSize=14}
                                        } #Throttle
                                    } #Throttle
                                } #if
                            
                            } #StackPanel

                            #---   Add/Remove Cache Folders   ------------------------------------------------------------------------
                            #New-UITextBlock "When switching Credentials (radio buttons) ... Creds Manual (stored value) will be reset." -Align TopLeft -Margin 30,0,0,0 -Foreground Green -AlsoSet @{FontSize=14}
                            New-UITextBlock "--------------------------------------" -Align CenterLeft -Margin 30,0,0,0 -Foreground Blue  -AlsoSet @{FontSize=14}
                            New-UIStackPanel -Margin 0,10,0,0 -Orientation Horizontal {
                                New-UIButton "Add/Remove" -Align CenterLeft -Margin 30,0,10,0 -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -AddClick $UIMaster.Scripts.AddRemoveCache
                                New-UITextBlock "Script folders (drop down list) - " -Align CenterLeft -Foreground Black -AlsoSet @{FontSize=14} 
                                New-UITextBlock "Relaunch " -Align CenterLeft -Foreground Black -AlsoSet @{FontSize=14} -FontWeight Bold
                                New-UITextBlock "after saving the txt file." -Align CenterLeft -Foreground Black -AlsoSet @{FontSize=14} 
                                New-UIButton "Relaunch" -Align CenterLeft -Margin 10,0,0,0 -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -AddClick {
                                    $UIMaster.Relaunch = $true
                                    Find-UIParent -Type Window | ForEach-Object Close
                                } #button
                                #New-UITextBlock "You must click relaunch after saving your changes." -Align CenterLeft -Margin 10,0,0,0 -Foreground Black -AlsoSet @{FontSize=14} 
                                
                            } #StackPanel

                            #---   TroubleShooting   ---------------------------------------------------
                            New-UIStackPanel -Margin 0,6,0,0 {
                                New-UITextBlock "--------------------------------------" -Align CenterLeft -Margin 30,0,0,0 -Foreground Blue  -AlsoSet @{FontSize=14}

                                # Button - Uninstall/Reinstall
                                New-UIStackPanel -Margin 30,0,0,0 -Orientation Horizontal {
                                    New-UITextBlock "Uninstall the ScriptsWrapper" -Align CenterLeft -Margin 0,0,0,0 -Foreground Red -AlsoSet @{FontSize=14} -FontWeight Bold
                                    New-UITextBlock "It will reinstall the next time you launch it." -Align CenterLeft -Margin 10,0,0,0 -Foreground Green -AlsoSet @{FontSize=14} #-FontWeight Bold
                                    New-UIButton "Run" -AddClick $UIMaster.Scripts.Uninstall   -Align CenterLeft -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -Foreground Red -Margin 10,0,0,0
                                    New-UITextBlock "You will loose (local cache) files." -Align CenterLeft -Margin 10,0,0,0 -Foreground Green -AlsoSet @{FontSize=14} #-FontWeight Bold
                                } #stackpanel
                            } #stackpanel
                            
                            New-UITextBlock "$("-" * 142)" -Align TopLeft -Margin 30,0,0,0 -Foreground Black -AlsoSet @{FontSize=14}
                          
                          } #StackPanel
                        } #Expander
                        New-UITextBlock -Margin 10,2,0,0 -AlsoSet @{FontSize=18} -Align TopLeft -BindTextTo SettingsBanner -Foreground Green
                    } #Title
                    #New-UITextBlock "Create, Store, search for, and launch PowerShell scripts" -Margin 20,0,0,0 -AlsoSet @{FontSize=19} -Foreground blue
                    New-UIStackPanel -Orientation Horizontal -Margin 15,10,0,10 {
                        New-UIButton "Cls"        -Margin  0,0,0,0 -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -AddClick { cls }                        -Align BottomLeft -Foreground Black
                        New-UIButton "Close Tabs" -Margin 10,0,0,0 -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -AddClick $UIMaster.Scripts.CloseAllTabs -Align BottomLeft -Foreground Green
                        New-UIButton "Run Script" -Margin 10,0,0,0 -Padding 12,2,12,4 -AlsoSet @{FontSize=14} -AddClick $UIMaster.Scripts.MainFilter   -Align BottomLeft -Foreground Red
                        New-UIStackPanel -Orientation Vertical {
                            New-UIStackPanel -Orientation Horizontal {
                                New-UITextBlock "$(" "*5)Select Scripts Folder: "                                        -Margin  0,0,0,0 -AlsoSet @{FontSize=18} -Align TopLeft -Foreground Blue -FontWeight Bold
                                New-UIButton "Refresh" -AddClick $UIMaster.Scripts.RefreshButton -Padding 10,2,10,2  -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Align TopLeft -Foreground Green
                                New-UIComboBox -ItemsSource $UIMaster.DDLBkeys -BindSelectedValueTo SelectedCacheFolder  -Margin 10,0,0,0 -AlsoSet @{FontSize=14} -Align TopLeft `
                                  -AddSelectionChanged {$UIMaster.SelectedScriptFolder = ($UIMaster.DDLBhash)[$UIMaster.SelectedCacheFolder]}
                                New-UITextBox -BindTextTo SelectedScriptFolder -Margin 10,0,0,0 -Align TopLeft -AlsoSet @{FontSize=16}
                            } #stackpanel
                        } #stackpanel
                    } # Buttons
                } #Title 
            } #Title 

            ##################################################
            # ServerList    -GridRow 2 -GridCol 0
            New-UIStackPanel -GridRow 2 -GridCol 0 -Orientation Horizontal -Margin 15,0,0,10 {
                New-UIBorder -BorderBrush Gray -BorderThickness 1 {
                    New-UIGrid -RowDefinition 100,* {
                        # Server List
                        New-UIStackPanel -GridRow 0 -Orientation Vertical {
                            New-UIStackPanel -Margin 6,2,0,0 -Orientation Horizontal {
                                New-UITextBlock -Margin 0,0,0,0 -Foreground Black "Servers " -AlsoSet @{FontSize=16} -FontWeight Bold
                                New-UITextBlock -Margin 0,0,0,0 -Foreground Black 'max '  -AlsoSet @{FontSize=16}
                                # show server limit based on logged on user
                                if($UIMaster.FullAccess -or $UIMaster.adminServerList){New-UITextBlock -Margin 0,0,10,0 -Foreground Red "n/a" -AlsoSet @{FontSize=16} }
                                else {New-UITextBlock -Margin 0,0,10,0 -Foreground Red -BindTextTo ServerCountLimit -AlsoSet @{FontSize=16} }
                            } #ServerList 
                            New-UIStackPanel -Margin 0,6,0,0 -Orientation Horizontal {
                                New-UIButton "Load" -Margin 6,0,6,0 -Padding 8,2,8,4 -Align BottomLeft -AlsoSet @{FontSize=14} -AddClick $UIMaster.Scripts.LoadFromFile
                                New-UIButton "clear"          -Margin 6,0,0,0 -Padding 4,2,4,4 -Align BottomLeft -AlsoSet @{FontSize=14} -AddClick { $UIMaster.ServerText = "" }
                                New-UITextBlock -BindTextTo SrvrListcount -Margin 6,0,8,0 -Foreground Blue -AlsoSet @{FontSize=14}  -Align Center
                            } #Cls
                        } #Header
                        New-UITextBox -GridRow 1 -minWidth 100 -TextWrapping "NoWrap" -AcceptsReturn $true `
                            -HorizontalScrollBarVisibility Auto -VerticalScrollBarVisibility Auto -BindTextTo ServerText | 
                            Add-UIEvent -Event TextChanged -Script $UIMaster.Scripts.SrvrTxBoxChanged
                    } #ServerList
                } #ServerList
            } # ServerList

            ##################################################
            # Main Tabs      -GridRow 2 GridCol 1
            $UIMaster.MainTabControl = New-UITabControl -GridRow 2 -GridCol 1 -Margin 0,0,10,10 {
                New-UITabItem "   MAIN   " -Foreground Red { # starting content (scripts list, buttons) - on 1st tab
                    New-UIGrid -RowDefinition auto, *, auto -ColDefinition auto, 2* {

                        #------------------------------------------------
                        # Filter Keyword Header -GridRow 0 -GridColSpan 2
                        New-UIBorder -BorderBrush Gray -BorderThickness 1 -GridRow 0 -GridCol 0 -GridColSpan 2 -Margin 0,0,0,0 {
                            New-UIStackPanel -Orientation Vertical {
                                New-UIStackPanel -Orientation Horizontal {
                                    New-UIStackPanel -Orientation Vertical -Margin  0,0,0,0 {
                                        New-UIStackPanel -Orientation Horizontal {
                                            New-UITextBlock "Search" -Margin 10,4,0,0 -AlsoSet @{FontSize=16} -Foreground black -FontWeight Bold
                                            New-UITextBox -BindTextTo Searchtxt -MinWidth 200 -Height 22 -Align BottomLeft -AlsoSet @{FontSize=14} -Margin 10,4,0,4 |
                                                Add-UIEvent -Event TextChanged -Script $UIMaster.Scripts.SearchBoxChanged
                                            New-UIButton "clear" -Margin 10,0,10,0 -Padding 10,1,10,2 -Align CenterLeft -AlsoSet @{FontSize=12} -AddClick { $UIMaster.Searchtxt = "" }
                                            New-UIStackPanel -Margin 0,4,0,0 -Orientation Horizontal {
                                                New-UITextBlock "Scripts  "                       -Margin 30,0,0,0 -AlsoSet @{FontSize=16} -Foreground black
                                                New-UITextBlock -BindTextTo FilteredScriptListCount -Margin  0,0,0,0 -AlsoSet @{FontSize=16} -Foreground Green
                                            } #Header
                                        } #Textbox
                                    } #KeyWord
                                } #KeyWord, Credentails, Remote/Local, Throttle
                            } #KeyWord, Credentails, Remote/Local, Throttle
                        } #border

                        #------------------------------------------------
                        # List View   (Script, Synopsis)
                        New-UIListView -GridRow 1 -GridCol 1 -BindItemsSourceTo FilteredScriptList -BindSelectedItemTo SelectedScript `
                            -Margin 0,0,0,0 -SelectionMode Single -Columns {
                                        New-UIGridViewColumn -Header "ScriptName     (dbl-Click to Run) $(" "*50)" -Width 300 `
                                            -CellTemplate { New-UITextBlock | Add-UIBinding Text ScriptName | Add-UIBinding Foreground Color }
                                        New-UIGridViewColumn -Header "Favorite    " `
                                            -CellTemplate { New-UICheckBox | Add-UIBinding IsChecked IsFavorite } 
                                        New-UIGridViewColumn -Header "Description $(" "*400)" -Width 1300 `
                                            -CellTemplate { New-UITextBlock | Add-UIBinding Text Synopsis | Add-UIBinding Foreground Color2 }
                                        
                                        New-UIGridViewColumn -Header "LastWriteTime $(" "*30)" `
                                            -CellTemplate { New-UITextBlock | Add-UIBinding Text LastWriteTime }

                                        New-UIGridViewColumn -Header "Source $(" "*250)" `
                                            -CellTemplate { New-UITextBlock  | Add-UIBinding  Text Directory}
                                    } | Add-UIEvent MouseDoubleClick $UIMaster.Scripts.MainFilter
                    } #ListView
                } #TabItem
            } #TabControl
            $UIMaster.MainTabControl 
        } #Grid
    } #Show-UIWindow
} #.OpenMainWindow

#endregion 7

# Open the main window
& $UIMaster.Scripts.OpenMainWindow # & will launch the main window

} while ($UIMaster.Relaunch) # used to close the main gui and relaunch without having to exit.

#------------------------------------------------
# PowerShell script complete
