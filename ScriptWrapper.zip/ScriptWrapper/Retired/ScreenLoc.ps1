﻿# This will write to the console every 3 minutes
cls
$minutes = 86400 # 24hr in seconds 
$myshell = New-Object -com "Wscript.Shell"
for ($i = 0; $i -lt $minutes; $i++) { 
    $myshell.sendkeys(".")
    Start-Sleep -Seconds 180
} 
